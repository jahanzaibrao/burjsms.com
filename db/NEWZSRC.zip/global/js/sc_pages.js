/**
SMPPCUBE Official PAGES JS functions file
Please DO NOT remove or modify any code unless you really know what you're doing.
**/


$(document).on("ready",function(){    
    
//1. Admin dashboard
    if(curpage=='admin_dashboard'){
        
        
            
        
//date range picker

        //top sales
        $('#topsalesdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'right',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#topsalesdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload sales figures
			  $.ajax({
		type: 'GET',
		url: app_url+'getLatestOrders/'+$('#topsalesdp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
			$("#topsalesctr").fadeOut(function(){
                $(this).html(mydata.str).fadeIn(function(){
                    if(mydata.more==1 && mydata.rows==4){
                    $("#more_sales").removeClass('hidden').attr('data-custom','4,4').html(SCTEXT('Show More')+' ...');
                    }else{
                        $("#more_sales").addClass('hidden');
                    }
                });
            });
        }
		});
            
        });
        //Set the initial state of the picker label
         $('#topsalesdp span').html(Date.today().add({
            days: -6
        }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
		
		//----------------//
	
        
        //sales v push
        $('#salesvpushdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#salesvpushdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//plot the sales vs SMS graph 
            $('#smsvpushgraph').html('<img style="margin:0 40%;" src="<?php echo Doo::conf()->APP_URL ?>global/img/ajax_loader.gif" alt="">');
            $.ajax({
                type:'GET',
                url: app_url+'getSalesSmsChart/'+$('#salesvpushdp span').html(),
                success: function(res){
                var mydata = JSON.parse(res);
                // sms push v sales graph
            var salesdata = [];
            var i = 1;
                for (saleselem in mydata.sales) {
                   salesdata.push([i,parseInt(mydata.sales[saleselem])]);
                    i++;
                }
            var smsdata = [];
            var j = 1;
                for (smselem in mydata.sms) {
                   smsdata.push([j,parseInt(mydata.sms[smselem])]);
                    j++;
                }
                 //plot the graph
              $.plot("#smsvpushgraph", [{
                                           data: smsdata,
                                           color: '#ffa000',
                                           label: "SMS Push",
                                           lines: { show: true, lineWidth: 6, fill:true },
                                           curvedLines: { apply: false }
                                       },
                                     {
                                         data: salesdata,
                                         color: 'hsl(206,81%,49%)',
                                         label: "Sales",
                                         lines: { show: true, lineWidth: 6, fill:false },
                                         curvedLines: { apply: false }
                                     }
                                    ],
								{
									series: {stack: 1,lines: { show: true }},
                                    
									xaxis: {
										show: true,
                                        tickDecimals: 0,
										font: { size: 12, lineHeight: 10, style: 'normal', weight: '100',family: 'lato', variant: 'small-caps', color: '#a2a0a0' }
									},
									yaxis: {
										show: true,
                                        tickDecimals: 0,
										font: { size: 12, lineHeight: 10, style: 'normal', weight: '100',family: 'lato', variant: 'small-caps', color: '#a2a0a0' }
									},
									grid: { color: '#a2a0a0', hoverable: true, margin: 8, labelMargin: 8, borderWidth: 0, backgroundColor: '#fff' },
									tooltip: true,
									tooltipOpts: { content: 'Day: %x, SMS: %y',  defaultTheme: false }
								}
                
            );//end plot     
            }
                                           
                                       
                                           
            })
			
        });
        //Set the initial state of the picker label
         $('#salesvpushdp span').html(Date.today().add({
            days: -6
        }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
		
		//----------------//
		
		
    //sms sales n push data
        $('#smsactdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'right',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#smsactdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload sales figures
			  $.ajax({
		type: 'GET',
		url: app_url+'getSmsActivity/'+$('#smsactdp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
            $str = '<ul class="list-group"><li class="list-group-item"><span class="badge badge-primary">'+mydata.sales+'</span>'+SCTEXT('Total SMS Sold')+'</li><li class="list-group-item"><span class="badge badge-info">'+mydata.sent+'</span>'+SCTEXT('Total SMS Sent')+'</li><li class="list-group-item"><span class="badge badge-success">'+mydata.delivered+'</span>'+SCTEXT('SMS Delivered')+'</li><li class="list-group-item"><span class="badge badge-warning">'+mydata.used+'</span>'+SCTEXT('Credits Used')+'</li><li class="list-group-item"><span class="badge badge-danger">'+mydata.refunds+'</span>'+SCTEXT('Credits Refunded')+'</li></ul>';
            $("#smsactctr").fadeOut(function(){$(this).html($str).fadeIn();})
        }
		});
            
        });
        //Set the initial state of the picker label
         $('#smsactdp span').html(Date.today().add({
            days: -6
        }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
		
		//----------------//
	
        
    //top consumers    
         $('#topcldp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'right',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#topcldp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload sms figures
                     $.ajax({
                type: 'GET',
                url: app_url+'getTopConsumers/'+$('#topcldp span').html(),
                success: function(res){
                    var mydata = JSON.parse(res);
                    $("#topclctr").fadeOut(function(){
                        $(this).html(mydata.str).fadeIn(function(){
                            if(mydata.more==1 && mydata.rows==4){
                            $("#more_topcl").removeClass('hidden').attr('data-custom','4,4').html(SCTEXT('Show More')+' ...');
                            }else{
                                 $("#more_topcl").addClass('hidden');
                            }
                        });
                    });
                }
                });
            
        });
        //Set the initial state of the picker label
         $('#topcldp span').html(Date.today().add({
            days: -6
        }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
		
		//----------------//
        
        
        
    //top resellers    
         $('#toprsdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'right',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#toprsdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload sms figures
                     $.ajax({
                type: 'GET',
                url: app_url+'getTopResellers/'+$('#toprsdp span').html(),
                success: function(res){
                    var mydata = JSON.parse(res);
                    $("#toprsctr").fadeOut(function(){
                        $(this).html(mydata.str).fadeIn(function(){
                            if(mydata.more==1 && mydata.rows==4){
                            $("#more_toprs").removeClass('hidden').attr('data-custom','4,4').html(SCTEXT('Show More')+' ...');
                            }else{
                                 $("#more_toprs").addClass('hidden');
                            }
                        });
                    });
                }
                });
            
        });
        //Set the initial state of the picker label
         $('#toprsdp span').html(Date.today().add({
            days: -6
        }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
		
		//----------------//        
        
        
        
    //route traffic    
         $('#rtrfdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'right',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#rtrfdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload sms figures
                         $.ajax({
                type: 'GET',
                url: app_url+'getRouteTraffic/'+$('#rtrfdp span').html(),
                success: function(res){
                    var mydata = JSON.parse(res);
                    $("#rtrfctr").fadeOut(function(){
                        $(this).html(mydata.str).fadeIn();
                    });
                }
                });   
            
        });
        //Set the initial state of the picker label
         $('#rtrfdp span').html(Date.today().add({
            days: -6
        }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
		
		//----------------//      
        
    
    //load sales stats
    $.ajax({
        type: 'GET',
        url: app_url+'getAdminDashStats',
        success: function(res){
            var mydata = JSON.parse(res);
            $sales_this_week = mydata.sales_this_week || 0;
            $sales_this_month = mydata.sales_this_month || 0;
            $sales_seven_days = mydata.sales_seven_days || 0;
            $sms_this_week = mydata.sms_this_week || 0;
            $sms_this_month = mydata.sms_this_month || 0;
            $sms_seven_days = mydata.sms_seven_days || 0;
            $total_sms_seven_days = mydata.total_sms_data_last_seven || 0;
            
            $('#weekly_sales_ctr').html(mydata.total_weekly_sales);
            $('#monthly_sales_ctr').html(mydata.total_monthly_sales);
            $('#weekly_sms_ctr').html(mydata.total_weekly_sms);
            $('#monthly_sms_ctr').html(mydata.total_monthly_sms);
            
            //weekly small chart
            var arr = [];
                for (elem in $sales_this_week) {
                   arr.push($sales_this_week[elem]);
                }
            var s_arr = [];
                for (s_elem in $sms_this_week) {
                   s_arr.push($sms_this_week[s_elem]);
                }
           $("#ws_sp_chart").sparkline(arr,{type: 'bar', barColor: '#ffffff', barWidth: 3, barSpacing: 2});
            $("#wm_sp_chart").sparkline(s_arr,{type: 'bar', barColor: '#ffffff', barWidth: 3, barSpacing: 2});
           //monthly small chart
             var arr2 = [];
                for (elem2 in $sales_this_month) {
                   arr2.push($sales_this_month[elem2]);
                }
            var s_arr2 = [];
                for (s_elem2 in $sms_this_month) {
                   s_arr2.push($sms_this_month[s_elem2]);
                }
            $("#ms_sp_chart").sparkline(arr2,{type: 'bar', barColor: '#ffffff', barWidth: 2, barSpacing: 1.5});
            $("#mm_sp_chart").sparkline(s_arr2,{type: 'bar', barColor: '#ffffff', barWidth: 2, barSpacing: 1.5});
            
            // sms push v sales graph
            var salesdata = [];
            var i = 1;
                for (saleselem in $sales_seven_days) {
                   salesdata.push([i,parseInt($sales_seven_days[saleselem])]);
                    i++;
                }
            var smsdata = [];
            var j = 1;
                for (smselem in $sms_seven_days) {
                   smsdata.push([j,parseInt($sms_seven_days[smselem].sent)]);
                    j++;
                }
            
          $.plot("#smsvpushgraph", [{
                                           data: smsdata,
                                           color: '#ffa000',
                                           label: "SMS Push",
                                           lines: { show: true, lineWidth: 6, fill:true },
                                           curvedLines: { apply: false }
                                       },
                                     {
                                         data: salesdata,
                                         color: 'hsl(206,81%,49%)',
                                         label: "Sales",
                                         lines: { show: true, lineWidth: 6, fill:false },
                                         curvedLines: { apply: false }
                                     }
                                    ],
								{
									series: {stack: 1,lines: { show: true }},
                                    
									xaxis: {
										show: true,
                                        tickDecimals: 0,
										font: { size: 12, lineHeight: 10, style: 'normal', weight: '100',family: 'lato', variant: 'small-caps', color: '#a2a0a0' }
									},
									yaxis: {
										show: true,
                                        tickDecimals: 0,
										font: { size: 12, lineHeight: 10, style: 'normal', weight: '100',family: 'lato', variant: 'small-caps', color: '#a2a0a0' }
									},
									grid: { color: '#a2a0a0', hoverable: true, margin: 8, labelMargin: 8, borderWidth: 0, backgroundColor: '#fff' },
									tooltip: true,
									tooltipOpts: { content: 'Day: %x, SMS: %y',  defaultTheme: false }
								}
                
            );
            
            // sms and sales activity
            var totalsales = 0;
            for($date in $sales_seven_days){
                totalsales+=parseInt($sales_seven_days[$date]);
            }
            var str = `<ul class="list-group"><li class="list-group-item"><span class="badge badge-primary">${totalsales}</span>${SCTEXT('Total SMS Sold')}</li><li class="list-group-item"><span class="badge badge-info">${mydata.total_sms_data_last_seven.sent || 0}</span>${SCTEXT('Total SMS Sent')}</li><li class="list-group-item"><span class="badge badge-success">${mydata.total_sms_data_last_seven.delivered || 0}</span>${SCTEXT('SMS Delivered')}</li><li class="list-group-item"><span class="badge badge-warning">${mydata.total_sms_data_last_seven.used || 0}</span>${SCTEXT('Credits Used')}</li><li class="list-group-item"><span class="badge badge-danger">${mydata.total_sms_data_last_seven.refunds || 0}</span>${SCTEXT('Credits Refunded')}</li></ul>`;
            
            $("#smsactctr").fadeOut(function(){$(this).html(str).fadeIn();})
            
        }
    });
    

// top orders
        $.ajax({
		type: 'GET',
		url: app_url+'getLatestOrders/'+$('#topsalesdp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
			$("#topsalesctr").fadeOut(function(){
                $(this).html(mydata.str).fadeIn(function(){
                    if(mydata.more==1 && mydata.rows==4){
                    $("#more_sales").removeClass('hidden').attr('data-custom','4,4');
                    }else{
                         $("#more_sales").addClass('hidden');
                    }
                });
            });
        }
		});
// show more sales
        $('#more_sales').on("click",function(){
            $limit = $(this).attr('data-custom');
            if($limit!='0,4'){
                //check to make sure all data isnnot loaded
            $(this).attr('disabled','disabled').html(SCTEXT('loading')+'....');
            $.ajax({
                type: 'GET',
                url: app_url+'getLatestOrders/'+$('#topsalesdp span').html()+'/'+$limit,
                success: function(res){
                    var mydata = JSON.parse(res);
                    if(mydata.more==1){
                    $("#topsalesctr").append(mydata.str);
                    $('#topsalesctr').animate({
                        scrollTop: $('#topsalesctr').prop("scrollHeight")}, 500, function(){
                        $('#more_sales').html(SCTEXT('Show More')+' ...').attr({"disabled":false,"data-custom":mydata.limit});
                    });
                       
                    }else{
                        
                        $('#more_sales').html(SCTEXT('All loaded')).attr({"disabled":false,"data-custom":mydata.limit}); 
                    }
                }
            });
            }
        })        


// system stats
        
          $.ajax({
		type: 'GET',
		url: app_url+'getSystemStats',
		success: function(res){
            var mydata = JSON.parse(res);
			 $ststr = `<ul class="list-group"><li class="list-group-item"><span class="badge badge-primary">${mydata.smpp || 0}</span>${SCTEXT('Total SMPP Connections')}</li><li class="list-group-item"><span class="badge badge-info">${mydata.routes ||0}</span>${SCTEXT('Total Routes')}</li><li class="list-group-item"><span class="badge badge-success">${mydata.users || 0}</span>${SCTEXT('Total users')}</li><li class="list-group-item"><span class="badge badge-warning">${mydata.sms ||0}</span>${SCTEXT('Total SMS Sent')}</li><li class="list-group-item"><span class="badge badge-danger">${mydata.scheduled || 0}</span>${SCTEXT('Total SMS Scheduled')}</li></ul>`;
            $("#systemstatctr").fadeOut(function(){$(this).html($ststr).fadeIn();})
        }
		});

        
// top consumers
        
        $.ajax({
		type: 'GET',
		url: app_url+'getTopConsumers/'+$('#topcldp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
			$("#topclctr").fadeOut(function(){
                $(this).html(mydata.str).fadeIn(function(){
                    if(mydata.more==1 && mydata.rows==4){
                    $("#more_topcl").removeClass('hidden').attr('data-custom','4,4');
                    }else{
                         $("#more_topcl").addClass('hidden');
                    }
                });
            });
        }
		});
// show more top consumers
        $('#more_topcl').on("click",function(){
            $cllimit = $(this).attr('data-custom');
            if($cllimit!='0,4'){
                //check to make sure all data isnnot loaded
            $(this).attr('disabled','disabled').html(SCTEXT('loading')+'....');
            $.ajax({
                type: 'GET',
                url: app_url+'getTopConsumers/'+$('#topcldp span').html()+'/'+$cllimit,
                success: function(res){
                    var mydata = JSON.parse(res);
                    if(mydata.more==1){
                    $("#topclctr").append(mydata.str);
                    $('#topclctr').animate({
                        scrollTop: $('#topclctr').prop("scrollHeight")}, 500, function(){
                        $('#more_topcl').html(SCTEXT('Show More')+' ...').attr({"disabled":false,"data-custom":mydata.limit});
                    });
                       
                    }else{
                        
                        $('#more_topcl').html(SCTEXT('All loaded')).attr({"disabled":false,"data-custom":mydata.limit}); 
                    }
                }
            });
            }
        })   
        
        
        
// top resellers
        
        $.ajax({
		type: 'GET',
		url: app_url+'getTopResellers/'+$('#toprsdp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
			$("#toprsctr").fadeOut(function(){
                $(this).html(mydata.str).fadeIn(function(){
                    if(mydata.more==1 && mydata.rows==4){
                    $("#more_toprs").removeClass('hidden').attr('data-custom','4,4');
                    }else{
                         $("#more_toprs").addClass('hidden');
                    }
                });
            });
        }
		});
// show more top resellers
        $('#more_toprs').on("click",function(){
            $rslimit = $(this).attr('data-custom');
            if($rslimit!='0,4'){
                //check to make sure all data isnnot loaded
            $(this).attr('disabled','disabled').html(SCTEXT('loading')+'....');
            $.ajax({
                type: 'GET',
                url: app_url+'getTopResellers/'+$('#toprsdp span').html()+'/'+$rslimit,
                success: function(res){
                    var mydata = JSON.parse(res);
                    if(mydata.more==1){
                    $("#toprsctr").append(mydata.str);
                    $('#toprsctr').animate({
                        scrollTop: $('#toprsctr').prop("scrollHeight")}, 500, function(){
                        $('#more_toprs').html(SCTEXT('Show More')+' ...').attr({"disabled":false,"data-custom":mydata.limit});
                    });
                       
                    }else{
                        
                        $('#more_toprs').html(SCTEXT('All loaded')).attr({"disabled":false,"data-custom":mydata.limit}); 
                    }
                }
            });
            }
        })   
                

// route-wise sms traffic
        
         $.ajax({
		type: 'GET',
		url: app_url+'getRouteTraffic/'+$('#rtrfdp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
			$("#rtrfctr").fadeOut(function(){
                $(this).html(mydata.str).fadeIn();
            });
        }
		});
      
            
        
        
        
    
}

//End Admin Dashboard

    
//2. Manage smpp
    if(curpage=='manage_smpp'){
        
        $(document).on("click",".remove_smpp",function(){
            var rid = $(this).attr('data-rid');
            
                bootbox.confirm({
                    message: SCTEXT("This will remove the SMPP from Kannel. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete smpp
                            window.location = app_url+'deleteSmpp/'+rid;
                        }
                    }
            });
        })
		
    }
//3. Add Smpp
    if(curpage=='add_smpp' || curpage=='edit_smpp'){
        $("#save_changes").click(function(){
			if($("#smpp_title").val()=='' || $("#provider").val()=='' || $("#smsc_id").val()=='' || !isPositiveInteger($("#total_sessions").val()) || $("#smpp_host").val()=='' || $("#smpp_port").val()=='' || $("#smpp_uid").val()=='' || $("#smpp_pass").val()=='')
				{   
					bootbox.alert(SCTEXT('Some error occurred. Please fill all the fields with appropriate values'));
                    return;
					
				}else{
                    
                    if(curpage=='edit_smpp'){
                        var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving SMPP and restarting SMSC. Less than a minute remaining')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });
                        dialog.init(function(){
                                    $("#stbar").animate({width:"100%"},12000)
                                    setTimeout(function(){
                                        $("#edit_smpp_form").attr('action',app_url+'saveSmpp');
                                        $("#edit_smpp_form").submit();
                                    }, 500);
                                });
                    }else{
                        var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Adding SMPP to Kannel')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                         dialog.init(function(){
                                    $("#stbar").animate({width:"100%"},3000)
                                    setTimeout(function(){
                                        $("#add_smpp_form").attr('action',app_url+'saveSmpp');
                                        $("#add_smpp_form").submit();
                                    }, 500);
                                });
                    }
                    
                   
				
				}
				
			});
			
			$("#bk").click(function(){
				window.location = app_url+'manageSmpp';
			});
		
            $("#tx_no,#rx_no,#trx_no").on("click keyup focus blur change",function(){
                calcTotalSessions();
            });
                    
            
    }

    
// 4. manage blacklist db
    if(curpage=='manage_bl_db'){
         $(document).on("click",".remove_bldb",function(){
            var tid = $(this).attr('data-tid');
            
                bootbox.confirm({
                    message: SCTEXT("This will delete the table and all the data. This cannot be undone. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete bldb
                            window.location = app_url+'deleteBlacklistDb/'+tid;
                        }
                    }
            });
        })
    }
    
    
    
// 5. add blacklist db
    if(curpage=='add_bl_db' || curpage=='edit_bl_db'){
        
        $("#save_changes").click(function(){
            //validate 
            if($("#tname").val()=='' || $("#mcol").val()==''){
                bootbox.alert(SCTEXT('Table name & mobile column cannot be blank.'));
                return;
            }
            if(/^[a-zA-Z0-9-_]*$/.test($("#tname").val()) == false) {
                bootbox.alert(SCTEXT('Table name contains illegal characters.'));
                return;
            }
            if(/^[a-zA-Z0-9-_]*$/.test($("#mcol").val()) == false) {
                bootbox.alert(SCTEXT('Mobile Column name contains illegal characters.'));
                return;
            }
            //submit
            if(curpage=='edit_bl_db'){
                var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes in Database')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
            dialog.init(function(){
                    $("#stbar").animate({width:"100%"},800)
                    setTimeout(function(){
                        $("#edit_bldb_form").attr('action',app_url+'saveBlacklistDb');
                        $("#edit_bldb_form").submit();
                        }, 300);
                    });
            }else{
               var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Adding Database')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
            dialog.init(function(){
                    $("#stbar").animate({width:"100%"},800)
                    setTimeout(function(){
                        $("#add_bldb_form").attr('action',app_url+'saveBlacklistDb');
                        $("#add_bldb_form").submit();
                        }, 300);
                    }); 
            }
            
        });
        
        $("#bk").click(function(){
				window.location = app_url+'manageBlacklists';
			});
    }
    
    
    if(curpage=='upload_bl_db'){
        $("#bk").click(function(){
				window.location = app_url+'manageBlacklists';
			});
        $("#save_changes").click(function(){
            //check if table selected
            if($("#seltbl").val()==0){
                bootbox.alert(SCTEXT('Please select a table to import data.'));
                return;
            }
            //check if any files is uploaded
            if($(".uploadedFile").length==0){
                bootbox.alert(SCTEXT('Please upload at least one file.'));
                return;
            }
            //check if any upload is in progress
            if($("#uprocess").val()==1){
                bootbox.alert(SCTEXT('File upload is in progress. Kindly wait for upload to finish or Cancel Upload & proceed.'));
                return;
            }
            //submit
            var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Adding Upload Task')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
            dialog.init(function(){
                    $("#stbar").animate({width:"100%"},300)
                    setTimeout(function(){
                        $("#upload_bldb_form").attr('action',app_url+'addUploadTask');
                        $("#upload_bldb_form").submit();
                        }, 100);
                    }); 
        })
    }
    
    
    if(curpage=='view_bl_db'){
        //taskinfo close
        $('body').on("click",".closeDS",function(){
				$(".taskinfo").popover("hide");
		});
        //cancel import
        $('body').on("click",'.cancel-import',function(){
            var taskid = $(this).attr("data-taskid");
            bootbox.confirm({
                    message: SCTEXT("This will delete the current task and uploaded file. If some of the data is already imported it will not be deleted. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete task
                            window.location = app_url+'deleteImportTask/'+taskid;
                        }
                    }
            });
        });
        //lookup number
        $("#lookupbtn").click(function(){
            var btn = $(this);
            btn.attr("disabled","disabled").html(SCTEXT('Searching')+'...').css("cursor","progress");
            //validate
            var mobile = $("#mobile_no").val();
            if(!isPositiveInteger(mobile) || mobile.length < 7 || mobile.length > 15){
                bootbox.alert(SCTEXT('Invalid mobile number format. Enter mobile number with no space and without plus (+) sign.'));
                btn.attr("disabled",false).html('<i class="fa fa-search fa-lg"></i>&nbsp; '+SCTEXT('Search')).css("cursor","pointer");
                return;
            }
            $.ajax({
                url: app_url+'numberLookupBlDb',
                data:{
                    mobile: mobile,
                    tinfo: $("#tinfo").val()
                },
                success: function(res){
                 var mydata = JSON.parse(res);
                    btn.attr("disabled",false).html('<i class="fa fa-search fa-lg"></i>&nbsp; '+SCTEXT('Search')).css("cursor","pointer");
                    if(mydata.result==0){
                        //not found
                        $("#lookup_result").html('<li class="text-center list-group-item list-group-item-danger">- '+SCTEXT('No Records Found')+' -</li>');
                    }else{
                        //found
                        var str = `<li class="list-group-item list-group-item-info"><div class="input-group"><span class="input-group-addon text-success"><i class="fa fa-lg fa-check-circle"></i>&nbsp;${SCTEXT('Found')}</span><input id="lookup_res_txt" type="text" class="form-control text-center" readonly="readonly" value="${mobile}" /><span class="input-group-btn"><button id="del_lookup_res" data-mid="${mydata.id}" class="btn btn-danger" type="button"><i class="fa fa-trash fa-lg"></i></button></span></div></li>`;
                        
                        $("#lookup_result").html(str);
                    }
                }
            });
            
        });
        
        //delete lookup number
        $(document).on("click","#del_lookup_res",function(){
            var mid = $(this).attr("data-mid");
            var btn = $(this);
            
            bootbox.confirm({
                    message: SCTEXT("This will delete the mobile number from database. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                           btn.attr("disabled","disabled").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>').css("cursor","progress");
                            $.ajax({
                                url: app_url+'deleteNdncNumber/'+mid,
                                data: {tinfo: $("#tinfo").val()},
                                success: function(res){
                                    $("#lookup_result").html('<li class="text-center list-group-item list-group-item-success"><i class="fa fa-lg fa-inverse fa-check-circle"></i>&nbsp;'+SCTEXT('Record Deleted')+'</li>').fadeIn(500).delay(2000).fadeOut(500, function(){
                                        $(this).html('').fadeIn(100);
                                        $("#mobile_no").val('');
                                    });
                                }
                            });
                        }
                    }
            });
            
            
        });
        //empty table
        $("#empty_tbl").click(function(){
           var tid = $(this).attr("data-tid");
            var btn = $(this);
            btn.attr("disabled","disabled").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>&nbsp; '+SCTEXT('Deleting All Data')+'..').css("cursor","progress");
            bootbox.confirm({
                    message: SCTEXT("This will delete all the data from the table. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        btn.attr("disabled",false).html(SCTEXT('Empty the Table')+' (TRUNCATE)').css("cursor","pointer");
                        if(result){
                            //delete task
                            $.ajax({
                                    url: app_url+'bldbActions',
                                    method: 'post',
                                    data: {
                                        tinfo: $("#tinfo").val(),
                                        mode: 'empty'
                                    },
                                    success: function(res){
                                        bootbox.alert('<i class="fa fa-lg text-success fa-check-circle"></i>&nbsp;'+res);
                                       }
                                });
                        }
                    }
            });
           
        });
        
        //optimize table
        
        $("#opt_tbl").click(function(){
           var tid = $(this).attr("data-tid");
            var btn = $(this);
            btn.attr("disabled","disabled").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>&nbsp; '+SCTEXT('Optimizing Table')+'..').css("cursor","progress");
            bootbox.confirm({
                    message: SCTEXT("Optimization process will take a long time for large database. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        btn.attr("disabled",false).html(SCTEXT('Rebuild Index')+' (OPTIMIZE) ').css("cursor","pointer");
                        if(result){
                            //delete task
                            $.ajax({
                                    url: app_url+'bldbActions',
                                    method: 'post',
                                    data: {
                                        tinfo: $("#tinfo").val(),
                                        mode: 'optimize'
                                    },
                                    success: function(res){
                                        bootbox.alert('<i class="fa fa-lg text-success fa-check-circle"></i>&nbsp;'+res);
                                       }
                                });
                        }
                    }
            });
           
        });
    }
    
    if(curpage=='manual_add_bldb'){
        //submit form
        $("#save_changes").click(function(){
            var dialog = bootbox.dialog({
                closeButton: false,
                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Importing data')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
            });   
            dialog.init(function(){
                $("#stbar").animate({width:"100%"},800)
                setTimeout(function(){
                    $("#manadd_form").attr('action',app_url+'saveManualInsertBlDb');
                    $("#manadd_form").submit();
                    }, 300);
                });
        })
        //cancel
        $("#bk").click(function(){
            window.location = app_url+'manageBlacklists';
        });
    }

    if(curpage=='manual_del_bldb'){
        //submit form
        $("#save_changes").click(function(){
            var dialog = bootbox.dialog({
                closeButton: false,
                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('This can take longer for large data. Please wait')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
            });   
            dialog.init(function(){
                $("#stbar").animate({width:"100%"},800)
                setTimeout(function(){
                    $("#mandel_form").attr('action',app_url+'saveManualDelBlDb');
                    $("#mandel_form").submit();
                    }, 300);
                });
        })
        //cancel
        $("#bk").click(function(){
            window.location = app_url+'manageBlacklists';
        });
    }
    
//6. Manage credit count rules
    if(curpage=='manage_ccrules'){
        //taskinfo close
        $('body').on("click",".closeDS",function(){
				$(".ruleinfo").popover("hide");
		});
        //delete rule
        $(document).on("click",".remove_ccr",function(){
            var rid = $(this).attr("data-rid");
            bootbox.confirm({
                    message: SCTEXT("This will delete the credit rule. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location = app_url+'delCountRule/'+rid;
                            }
                        }
                    }); 
        });
        
    }

//7. Add CC Rule
    if(curpage=='add_ccrule' || curpage=='edit_ccrule'){
        //auto write range and rate
        $(".rangeto").on("keyup",function(){
            var elem = $(this);
            var parelem = elem.parent().parent().parent().next();
            var ratelem = elem.parent().next().find("span.label");
            
            parelem.find(".bg-white").val( parseInt(elem.val()==''||isNaN(elem.val())?0:elem.val())+1);
            ratelem.html(parseInt(parseInt(elem.val()==''||isNaN(elem.val())?0:elem.val())/parseInt(elem.attr("data-count")))+' chars/sms');
        });
        
        $(".nextStep").on("click",function(){
            var curstep = $(this).attr('data-step');
            if(curstep=='1'){
                //validate step 1
                if($("#ccrname").val()==''){
                    bootbox.alert(SCTEXT('Please enter a name for this credit count rule.'));
                    return;
                }
                var haserr = 0;
                $("#step-1-form").find(".rangeto").each(function(){
                   var elem = $(this);
                    if(elem.val()==''||isNaN(elem.val())){
                        elem.addClass("error-input");
                        haserr++;
                    }else{
                        elem.removeClass("error-input");
                    }
                });
                
                if(haserr>0){
                    bootbox.alert(SCTEXT('Please enter correct values in all the fields'));
                    haserr=0;
                    return;
                }else{
                    //move to step 2
                    $("#step-1-form").hide("slide", { direction: "left" }, 500,function(){
                        $(".step-1").removeClass("active");
                        $(".step-2").addClass("active");
                        $("#step-2-form").removeClass("hidden").show("slide", { direction: "right" }, 400);
                    })
                }
            }
            
             if(curstep=='2'){
                //validate step 2
                var haserr2 = 0; 
                $("#step-2-form").find(".rangeto").each(function(){
                   var elem = $(this); 
                    if(elem.val()==''||isNaN(elem.val())){
                        elem.addClass("error-input");
                        haserr2++;
                    }else{
                        elem.removeClass("error-input");
                    }
                });
                
                if(haserr2>0){
                    bootbox.alert(SCTEXT('Please enter correct values in all the fields'));
                    haserr2=0;
                    return;
                }else{
                    //move to step 3
                    $("#step-2-form").hide("slide", { direction: "left" }, 500,function(){
                        $(".step-2").removeClass("active");
                        $(".step-3").addClass("active");
                        $("#step-3-form").removeClass("hidden").show("slide", { direction: "right" }, 400);
                    })
                }
            }
            
            if(curstep=='3'){
                //validate step 3
                var haserr3 = 0; 
                $("#step-3-form").find(".input-sm").each(function(){
                   var elem = $(this); 
                    if(elem.val()==''||isNaN(elem.val())){
                        elem.addClass("error-input");
                        haserr3++;
                    }else{
                        elem.removeClass("error-input");
                    }
                });
                
                if(haserr3>0){
                    bootbox.alert('Please enter correct values in all the fields');
                    haserr3=0;
                    return;
                }else{
                    //submit the form
                    var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Adding Credit count rule')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#add_rule_form").attr('action',app_url+'saveCountRule');
                                $("#add_rule_form").submit();
                                }, 100);
                            }); 
                }
            }
            
            
        });
        
       $(".prevStep").on("click",function(){
           if($(this).attr("data-step")=='2'){
               $("#step-2-form").hide("slide", { direction: "right" }, 400,function(){
                        $(".step-2").removeClass("active");
                        $(".step-1").addClass("active");
                        $("#step-1-form").removeClass("hidden").show("slide", { direction: "left" }, 400);
                    })
           }
           if($(this).attr("data-step")=='3'){
               $("#step-3-form").hide("slide", { direction: "right" }, 400,function(){
                        $(".step-3").removeClass("active");
                        $(".step-2").addClass("active");
                        $("#step-2-form").removeClass("hidden").show("slide", { direction: "left" }, 400);
                    })
           }
           
           
       });
        
        //--
        $("#bk").click(function(){
            window.location = app_url+'manageCountRules';
        })
    }
  
    
//8. Manage Countries
    
    if(curpage=='edit_country'){
        //set timezone
        $("#timezone option").each(function(){
					if( $(this).val()==$("#curtz").val()){
					$(this).attr('selected','selected');	
					}
					});
        $("#timezone").trigger("change.select2");
        //submit
        $("#save_changes").click(function(){
           //validate
            if($("#ccname").val()==''){
                bootbox.alert(SCTEXT('Country name cannot be blank.'));
                return;
            }
            if($("#cpre").val()==''){
                bootbox.alert(SCTEXT('Calling prefix cannot be blank.'));
                return;
            }
            if($("#cvl").val()==''){
                bootbox.alert(SCTEXT('Valid mobile number lengths cannot be blank. Enter at least two values:<br>1. Mobile Number length with country prefix<br>2. Mobile Number length without country prefix'));
                return;
            }
            
            var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Changes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},200)
                            setTimeout(function(){
                                $("#edit_ctry_form").attr('action',app_url+'saveCountry');
                                $("#edit_ctry_form").submit();
                                }, 150);
                            }); 
        });
        //--
        $("#bk").click(function(){
             window.location = app_url+'manageCountries';
        })
    }

    
    if(curpage=='upload_prefix'){
        //submit the form
        $("#save_changes").click(function(){
            if($("#country").val()=='0'){
                bootbox.alert(SCTEXT("Please select the country for which the prefixes are being uploaded."));
                return;
            }
            if($(".uploadedFile").length==0){
                bootbox.alert(SCTEXT("Please upload a file with prefixes and operator data."));
                return;
            }
            //if alls good
            var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Importing prefixes & operator data')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#upload_ocpr_form").attr('action',app_url+'importPrefixes');
                                $("#upload_ocpr_form").submit();
                                }, 150);
                            }); 
        });
        
        $("#bk").click(function(){
             window.location = app_url+'manageCountries';
        });
        
        
    }
    
    if(curpage=='view_prefix'){
        //delete prefix
        
        //delete prefixes
        $(document).on("click",".delprefix",function(){
            var pid = $(this).attr('data-pid');
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this prefix?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location = app_url+'deleteOP/'+pid+'/'+$("#cid").val();
                            }
                        }
                    }); 
        });
        
        
    }
    
    if(curpage=='edit_prefix'){
        
        $("#msel").on("change", function(){
            let nw = $("#msel option:selected").attr('data-nw');
            let rg = $("#msel option:selected").attr('data-rg');
            $("#operator").val(nw);
            $("#circle").val(rg);
        })

        //submit the form
        $("#save_changes").click(function(){
            if($("#prefix").val()==''){
                bootbox.alert(SCTEXT("Prefix cannot be blank. Please enter mobile prefix"));
                return;
            }
            if($("#operator").val()==''){
                bootbox.alert(SCTEXT("Operator cannot be blank. Please enter operator associated with the mobile prefix"));
                return;
            }
            
            //if alls good
            var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving prefixes & operator data')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},100)
                            setTimeout(function(){
                                $("#edit_pre_form").attr('action',app_url+'saveOP');
                                $("#edit_pre_form").submit();
                                }, 90);
                            }); 
        });
        //---
        $("#bk").click(function(){
             window.location = app_url+'viewAllOP/'+$("#cid").val();
        });
        
        
    }
    
    
//9. Manage Routes
    if(curpage=='manage_routes'){
        //toggle status
        $(document).on("change",".togstatus",function(){
           var rid = $(this).attr('data-rid');
            var rstatus = 1;
           if($(this).is(':checked')){rstatus=0;}
           $.ajax({
                url: app_url+'changeRouteStatus',
               method: 'post',
               data: {rid: rid, status: rstatus},
                success: function(res){
                    bootbox.alert(res);
                }
            })
        });
        
        //delete route
        $(document).on("click",".remove_route",function(){
           var rid = $(this).attr('data-rid');
             bootbox.confirm({
                    message: "<h4><i class='fa fa-lg fa-info-circle text-danger'></i> "+SCTEXT('Caution')+" !! </h4>"+SCTEXT('This route may be assigned to users with SMS balance associated with this route. If you delete this route, they will get refund of the equal amount of SMS left in their accounts. Are you sure you want to proceed?'),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location = app_url+'deleteRoute/'+rid;
                            }
                        }
                    }); 
        });
    }
    
    if(curpage=='add_route' || curpage=='edit_route'){
        //add timezone
        $("#cov").change(function(){
            if($("#cov option:selected").val()==0){
                $("#pfx-toggle").addClass('disabledBox');
            }else{
                $("#pfx-toggle").removeClass('disabledBox')
            }
            var tz = $("#cov option:selected").attr('data-tz');
            $("#acttz").val(tz);
        });
        //toggle active time panel
        $(".acttype").click(function(){
            var aval = $(this).val();
            if(aval==1){
                $("#spectime").fadeIn();
            }else{
                $("#spectime").fadeOut();
            }
        });
        //submit form
        $("#save_changes").click(function(){
            if($("#rt_title").val()==''){
                bootbox.alert(SCTEXT('Please enter a title for this route'));
                return;
            }
            if($("#prismpp").val()==0){
                bootbox.alert(SCTEXT('Please select a primary SMPP for this route'));
                return;
            }
            if($("#defsid").val()==''){
                bootbox.alert(SCTEXT('A default sender is required'));
                return;
            }
            
            //all good
            
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving SMS route in the system')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#add_route_form").attr('action',app_url+'saveRoute');
                                $("#add_route_form").submit();
                                }, 150);
                            }); 
            
        });
        //--
        $("#bk").click(function(){
             window.location = app_url+'manageRoutes';
        });
    }
    
    if(curpage=='route_dlrcodes'){
        //add new row
        $("#add_new_code").click(function(){
			$newrow = $("#newrowstr").val();
			//check if empty table
			if($(".empty_table").length>0){
				$("#codes_ctnr").html($newrow);
			}else{
			//table already has rows append new row	
			$("#codes_ctnr").append($newrow);
			}
			
			});
        //remove row
        $('body').on("click",".rmv",function(){
			$(this).parent().parent().remove();
			});
        //submit changes
        $("#save_changes").click(function(){
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving DLR codes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#add_dlrcode_form").attr('action',app_url+'saveRouteDlrCodes');
                                $("#add_dlrcode_form").submit();
                                }, 150);
                            }); 
            
        });
        //--
        $("#bk").click(function(){
             window.location = app_url+'manageRoutes';
        });
    }
    
    
//10. Manage Refund rules
    
    if(curpage=='add_rrule' || curpage=='edit_rrule'){
        //submit
        $("#save_changes").click(function(){
            if($("#rname").val()==''){
                bootbox.alert(SCTEXT('Rule name cannot be blank'));
                return;
            }
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Refund Rule')}. . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#add_rrule_form").attr('action',app_url+'saveRefundRule');
                                $("#add_rrule_form").submit();
                                }, 150);
                            }); 
            
        });
        //back
        $("#bk").click(function(){
             window.location = app_url+'refundRules';
        });
    }
    

//11. Kannel Monitor
    
    if(curpage=='kannel_mon'){
        
        if($('html').scrollTop() != 0)
       $('html, body').animate({ scrollTop: 0 }, 'fast');
        
        
        //reload page
        $(".reloadPg").click(function(){
            $(this).find(".fa").addClass("fa-spin");
            window.location.reload(false);
        });
        //kannel actions
        $(".kmon-action").click(function(){
           var action = $(this).attr('data-act');
                bootbox.prompt({
                    title: SCTEXT("Please enter Kannel administration password"),
                    inputType: 'password',
                    callback: function (pass) {
                        
                        if(pass){
                           var dialog = bootbox.dialog({
                                    message: `<p class="text-center"><i class="fa fa-large fa-spin fa-circle-o-notch"></i>&nbsp;&nbsp;${SCTEXT('Please wait')} . . .</p>`,
                                    size: 'small',
                                    closeButton: false
                                });
                        //send password and perform action
                            $.ajax({
                                    url: app_url+'kannelActions',
                                    method: 'post',
                                    data:{
                                        action: action,
                                        kpass: pass
                                    },
                                    success: function(res){
                                        location.reload();
                                    }
                                });
                        }
                        
                             
                        
                    }
                });    
        });
        
        //stop smsc
        $(".stop-smsc").click(function(){
            var smscid = $(this).attr('data-smsc');
            bootbox.prompt({
                    title: SCTEXT("Please enter Kannel administration password"),
                    inputType: 'password',
                    callback: function (pass) {
                        if(pass){
                           var dialog = bootbox.dialog({
                                    message: `<p class="text-center"><i class="fa fa-large fa-spin fa-circle-o-notch"></i>&nbsp;&nbsp;${SCTEXT('Please wait')} . . .</p>`,
                                    size: 'small',
                                    closeButton: false
                                });
                        //send password and perform action
                            $.ajax({
                                    url: app_url+'kannelActions',
                                    method: 'post',
                                    data:{
                                        action: 'stop-smsc',
                                        smsc: smscid,
                                        kpass: pass
                                    },
                                    success: function(res){
                                        location.reload();
                                    }
                                });
                        }
                    }
                });  
            
        });
        //start smsc
        $(".start-smsc").click(function(){
            var smscid = $(this).attr('data-smsc');
            bootbox.prompt({
                    title: SCTEXT("Please enter Kannel administration password"),
                    inputType: 'password',
                    callback: function (pass) {
                        if(pass){
                           var dialog = bootbox.dialog({
                                    message: `<p class="text-center"><i class="fa fa-large fa-spin fa-circle-o-notch"></i>&nbsp;&nbsp;${SCTEXT('Please wait')} . . .</p>`,
                                    size: 'small',
                                    closeButton: false
                                });
                        //send password and perform action
                            $.ajax({
                                    url: app_url+'kannelActions',
                                    method: 'post',
                                    data:{
                                        action: 'start-smsc',
                                        smsc: smscid,
                                        kpass: pass
                                    },
                                    success: function(res){
                                        location.reload();
                                    }
                                });
                        }
                    }
                });  
            
        })
    }
    
    
//12. Announcements
    if(curpage=='manage_annc'){
        //set status
        $(document).on("change",'.togstatus', function(){
            var val=0;
				if($(this).is(':checked')){
					
					val = '1';
				}
				var aid = $(this).val();
				$.ajax({
					method:'post',
					url: app_url+'setAnnouncementState',
					data: {value:val,aid:aid}
					});
				});
        //--
    }

    if(curpage=='add_annc' || curpage=='edit_annc'){
        //save 
        $("#save_changes").click(function(){
           if($("#dtxt").val==''){
               bootbox.alert(SCTEXT('Please enter the message to broadcast.'));
               return;
           }
           if($("#dfor").val==0){
               bootbox.alert(SCTEXT('Please select the users who will see this announcement.'));
               return;
           }
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Announcement')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#annfrm").attr('action',app_url+'saveAnnouncement');
                                $("#annfrm").submit();
                                }, 150);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'announcements';
        });
    }

//13. Manage SMS plans
    if(curpage=='manage_smsplans'){
        $(document).on("click",".del-plan",function(){
            var pid = $(this).attr('data-pid');
            var ucnt = $(this).attr('data-ucount');
            bootbox.confirm({
                    message: SCTEXT("There may be some user accounts associated with this plan. Are you sure you want to delete this plan?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location=app_url+'delSmsPlan/'+pid;
                            }
                        }
                    }); 
            
        });
    }
    
    if(curpage=='add_smsplan' || curpage=='edit_smsplan'){
        
        $("#pt1, #pt2").click(function(){
           if($(this).val()==1){
               $("#volbox").addClass("hidden");
               $("#volftbox").addClass("hidden");
               $("#subbox").removeClass("hidden");
               $("#subftbox").removeClass("hidden");
           } else{
               $("#subbox").addClass("hidden");
               $("#subftbox").addClass("hidden");
               $("#volbox").removeClass("hidden");
               $("#volftbox").removeClass("hidden");
           }
        });
        
        //populate table based on route selection
        
        
        $("#proutes").on("select2:select",function(e){
            var rval = e.params.data.id;
            var rtxt = e.params.data.text;
            //add a column for this route
            $("#splan-vol thead tr").append('<th id="rhcol'+rval+'">'+rtxt+'</th>');
            var ctr = 0;
            $("#splan-vol tbody tr").each(function(){
                $(this).append('<td class="tdcol'+rval+'" data-colname="'+rtxt+'"><div class="input-group"><span class="input-group-addon"> '+app_currency+' </span><input type="text" class="form-control input-small-sc input-sm" name="price['+ctr+']['+rval+']" placeholder="e.g. 0.05" value="" /><span class="input-group-addon">/sms</span></div></td>');
                ctr++;
            });
            
            
            //add a block for this route
            $(".poptrt").each(function(){
                var id = $(this).parent().parent().parent().attr("id");
                $(this).append('<div class="rtblock'+rval+'"><div class="text-white text-center label-info">'+rtxt+'</div><div class="rtopts"><div class="control-label">'+SCTEXT('SMS Credits')+':</div> <div class="input-group"><input type="text" class="form-control" name="poptcredits['+id+']['+rval+']" placeholder="e.g. 1000"/><span class="input-group-addon"> SMS</span></div><div class="control-label">'+SCTEXT('Additional Purchases')+':</div><div class="input-group"><span class="input-group-addon">'+app_currency+'</span><input type="text" class="form-control" name="poptaddrate['+id+']['+rval+']" placeholder="e.g. 0.05"/><span class="input-group-addon">per sms</span></div></div></div>');
            });
        });
        
        $("#proutes").on("select2:unselect",function(e){
            var rval = e.params.data.id;
            var rtxt = e.params.data.text;
            //remove the column for this route
            $("#splan-vol thead tr").find($("th#rhcol"+rval)).remove();
            $("#splan-vol tbody tr").each(function(){
                $(this).find($('td.tdcol'+rval)).remove();

            });
            
            
            //remove the block for this route
            $(".poptrt").each(function(){
                $(this).find(".rtblock"+rval).remove();
            });
        });
        
        $("#add_subplan").click(function(){
            //get id n generate new id
            var newid = parseInt($(this).attr('data-oid'))+1;
            $(this).attr("data-oid",newid);
            if($("#plan_id").length>0){
               var idn = 'P'+$("#plan_id").val()+'-SU-POPT-'+newid;
               }else{
               var idn = 'SU-POPT-'+newid;
               }
            var str = '<div id="'+idn+'" class="col-md-3 planopts"><input type="hidden" name="subopts[]" value="'+idn+'" /><a href="javascript:void(0);" class="plan-remove" data-oid="'+newid+'"><i class="fa fa-3x text-danger fa-minus-circle"></i> </a><div class="panel panel-info"><div class="panel-heading"><input type="text" data-oid="'+newid+'" class="poptnametxt form-control" placeholder="'+SCTEXT('enter plan option name e.g. PRO')+'" name="poptname['+idn+']" /></div><div class="panel-body"><div class="popt-item"><select class="form-control" data-plugin="select2" data-placeholder="'+SCTEXT('choose payment cycle')+'.." name="poptcycle['+idn+']"><option></option><option value="m">'+SCTEXT('Monthly')+'</option><option value="y">'+SCTEXT('Yearly')+'</option></select></div><div class="popt-item"><div class="input-group"><span class="input-group-addon">'+app_currency+'</span><input type="text" class="form-control" name="poptrate['+idn+']" placeholder="'+SCTEXT('enter subscription Fee e.g. 150')+'"/></div></div><div class="popt-item poptrt">';
            
            //add boxes for routes
            $("#proutes :selected").each(function(){
                var rval = $(this).val();
                var rtxt = $(this).text();
                str += '<div class="rtblock'+rval+'"><div class="text-white text-center label-info">'+rtxt+'</div><div class="rtopts"><div class="control-label">'+SCTEXT('SMS Credits')+':</div> <div class="input-group"><input type="text" class="form-control" name="poptcredits['+idn+']['+rval+']" placeholder="e.g. 1000"/><span class="input-group-addon"> SMS</span></div><div class="control-label">'+SCTEXT('Additional Purchases')+':</div><div class="input-group"><span class="input-group-addon">'+app_currency+'</span><input type="text" class="form-control" name="poptaddrate['+idn+']['+rval+']" placeholder="e.g. 0.05"/><span class="input-group-addon">per sms</span></div></div></div>';
            });
            
            str +='</div><div class="popt-item"><textarea name="poptdesc['+idn+']" class="form-control" placeholder="'+SCTEXT('enter a small description e.g. list some features etc.')+'"></textarea></div><div class="popt-item"><select class="form-control" data-plugin="select2" data-placeholder="'+SCTEXT('choose opt-in method')+'.." name="poptsel['+idn+']"><option></option><option value="0">'+SCTEXT('Payment & Sign Up')+'</option><option value="1">'+SCTEXT('Contact form')+'</option> </select></div></div></div></div>';
            
           $("#subbox").append(str); 
            
            $("#subbox").find("select").each(function(){
                var ph = $(this).attr('data-placeholder');
                $(this).select2({placeholder: ph});
            });
            
            $('html,body').animate({
                scrollTop: $('#'+idn).offset().top-100},
                'slow');
            //add boxes for features
            var ftstr = '<div id="FT-SU-POPT-'+newid+'" class="panel panel-info"><div class="panel-heading">- PLAN</div><div class="panel-body"><div class="clearfix"><div class="col-md-4 splanft-item"><div class="widget"><header class="widget-header"><h4 class="widget-title">'+SCTEXT('Allowed SMS Types')+'</h4></header><hr class="widget-separator"><div class="widget-body"><div class="m-b-xs m-r-xl"><input data-size="small" name="sftperm['+idn+'][flash]" type="checkbox" data-switchery data-color="#35b8e0" checked="checked"><label>Flash</label></div><div class="m-b-xs m-r-xl"><input data-size="small" name="sftperm['+idn+'][wap]" type="checkbox" data-switchery data-color="#35b8e0" checked="checked"> <label>WAP-Push</label></div><div class="m-b-xs m-r-xl"><input data-size="small" name="sftperm['+idn+'][vcard]" type="checkbox" data-switchery data-color="#35b8e0" checked="checked"><label>VCard</label></div><div class="m-b-xs m-r-xl"><input data-size="small" name="sftperm['+idn+'][unicode]" type="checkbox" data-switchery data-color="#35b8e0" checked="checked"><label>Unicode</label></div><div class="m-b-xs m-r-xl"><input data-size="small" name="sftperm['+idn+'][per]" type="checkbox" data-switchery data-color="#35b8e0" checked="checked"><label>Personalised SMS</label></div></div></div></div><div class="col-md-4 splanft-item"><div class="widget"><header class="widget-header"><h4 class="widget-title">'+SCTEXT('Allowed API access')+'</h4></header><hr class="widget-separator"><div class="widget-body"><div class="m-b-xs m-r-xl"><input data-size="small" name="sftperm['+idn+'][hapi]" type="checkbox" data-switchery data-color="#ff5b5b" checked="checked"><label>HTTP API</label></div><div class="m-b-xs m-r-xl"><input data-size="small" name="sftperm['+idn+'][xapi]" type="checkbox" data-switchery data-color="#ff5b5b" checked="checked"><label>XML API</label></div></div></div></div><div class="col-md-4 splanft-item"><div class="widget"><header class="widget-header"><h4 class="widget-title">'+SCTEXT('Allowed Refunds')+'</h4></header><hr class="widget-separator"><div class="widget-body">';
            
            $("#reftypebox").find('input').each(function(){
                var refid = $(this).attr("data-refid");
                var ref = $(this).attr("data-ref");
                ftstr +='<div class="m-b-xs m-r-xl"><input data-size="small" name="sftperm['+idn+'][ref]['+refid+']" type="checkbox" data-switchery data-color="#10c469" checked="checked"><label>'+ref+'</label></div>';
            });
            
        
            ftstr +='</div></div></div></div></div></div>';
            $("#subftbox").append(ftstr);
            
            
            $('#FT-SU-POPT-'+newid).find("input").each(function(){
                var color = $(this).attr('data-color');
                var size = $(this).attr('data-size');
               var switchery = new Switchery(this, {color: color, size: size, jackColor: '#ffffff'}); 
            });
            
            //end of add subs plan option
            
        });
        
        $(document).on("click",".plan-remove",function(){
            var ele = $(this);
            bootbox.confirm({
                    message: SCTEXT("You will lose the data associated with this plan option. Are you sure you want to delete?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            ele.parent().remove();
                            var oid = ele.attr("data-oid");
                            $("#FT-SU-POPT-"+oid).remove();
                            }
                        }
                    }); 
            
        });
        
        //plan name should appear on feature selection boxes
        $(document).on("keyup",".poptnametxt",function(){
            var oid = $(this).attr("data-oid");
            var str = $(this).val();
            
            $("#FT-SU-POPT-"+oid).find(".panel-heading").text(str+' - PLAN');
        })
        
        
        
        $(document).on("keyup",".rangeto",function(){
            var elem = $(this);
            var parelem = elem.parent().parent().parent().next();
            parelem.find(".bg-white").val( parseInt(elem.val()==''||isNaN(elem.val())?0:elem.val())+1);
        });
        
        //next steps
        $(".nextStep").on("click",function(){
            var curstep = $(this).attr('data-step');
            if(curstep=='1'){
                
                //validate step 1
                if($("#pname").val()==''){
                    bootbox.alert(SCTEXT('Please enter a name for this SMS Plan.'));
                    return;
                }
                
                if($("#proutes").val()==null){
                    bootbox.alert(SCTEXT('Please choose at least one Route.'));
                    return;
                }
                
                
                    //move to step 2
                    $("#step-1-form").hide("slide", { direction: "left" }, 500,function(){
                        $(".step-1").removeClass("active");
                        $(".step-2").addClass("active");
                        $("#step-2-form").removeClass("hidden").show("slide", { direction: "right" }, 400);
                    })
                
            }
            
             if(curstep=='2'){
                //validate step 2
                var haserr2 = 0; 
                 if($('input[name=ptype]:checked', '#add_splan_form').val()==0){
                   /* $("#step-2-form").find(".rangeto").each(function(){
                       var elem = $(this); 
                        if(elem.val()==''||isNaN(elem.val())){
                            elem.addClass("error-input");
                            haserr2++;
                        }else{
                            elem.removeClass("error-input");
                        }
                    });*/
                }else{
                    
                }
                
                
                if(haserr2>0){
                    bootbox.alert(SCTEXT('Please enter correct values in all the fields'));
                    haserr2=0;
                    return;
                }else{
                    //move to step 3
                    $("#step-2-form").hide("slide", { direction: "left" }, 500,function(){
                        $(".step-2").removeClass("active");
                        $(".step-3").addClass("active");
                        $("#step-3-form").removeClass("hidden").show("slide", { direction: "right" }, 400);
                    })
                }
            }
            
            if(curstep=='3'){
                //validate step 3
                
                    //submit the form
                    var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving SMS Plan')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#add_splan_form").attr('action',app_url+'saveSmsPlan');
                                $("#add_splan_form").submit();
                                }, 100);
                            }); 
                
            }
            
            
        });
        
        //prev steps
        $(".prevStep").on("click",function(){
           if($(this).attr("data-step")=='2'){
               $("#step-2-form").hide("slide", { direction: "right" }, 400,function(){
                        $(".step-2").removeClass("active");
                        $(".step-1").addClass("active");
                        $("#step-1-form").removeClass("hidden").show("slide", { direction: "left" }, 400);
                    })
           }
           if($(this).attr("data-step")=='3'){
               $("#step-3-form").hide("slide", { direction: "right" }, 400,function(){
                        $(".step-3").removeClass("active");
                        $(".step-2").addClass("active");
                        $("#step-2-form").removeClass("hidden").show("slide", { direction: "left" }, 400);
                    })
           }
           
           
       });
        
        //--
        $("#bk").click(function(){
            window.location = app_url+'manageSmsPlans';
        })
    }
    
    
//14. Manage staff n team    
    if(curpage=='manage_teams'){
        $(document).on("click",".del_team",function(){
            var tid = $(this).attr('data-tid');
            bootbox.confirm({
                    message: SCTEXT('Are you sure you want to delete this team?'),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location=app_url+'delStaffTeam/'+tid;
                            }
                        }
                    }); 
            
        });
    }
    
    if(curpage=='add_team' || curpage=='edit_team'){
         $("input.toggle").change(function(){
             var box = $(this).attr("data-group")+'_roles';
             var eid = $(this).attr('id');
             var status = $('#'+eid+':checked').length;
             
             if(status==0){
                 //uncheck all
                 $("#"+box).find("input[type=checkbox]").each(function(){
                     $(this).prop('checked',false);
                 });
             }else{
                 //check all
                 $("#"+box).find("input[type=checkbox]").each(function(){
                     $(this).prop('checked',true);
                 })
             } 
         });
        
        //save 
        $("#save_changes").click(function(){
           if($("#tname").val()==''){
               bootbox.alert(SCTEXT('Please enter the team name.'));
               return;
           }
           
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Staff Team')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#team_form").attr('action',app_url+'saveStaffTeam');
                                $("#team_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageStaffTeams';
        });

            
    }
    
    if(curpage=='manage_staff'){
        $(document).on("click",".del_staff",function(){
            var uid = $(this).attr('data-uid');
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this staff member?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                             window.location=app_url+'delStaff/'+uid;
                            }
                        }
                    }); 
            
        });
    }
    
    if(curpage=='add_staff'){
        var erremail = 0;
        var errloginid = 0;
        var errphone = 0;
        var errpass = 0;
        var emsg = '';
        
        //submit form
        $("#save_changes").click(function(){
            //validate
           if($("#sname").val()==''){
               bootbox.alert(SCTEXT('Please enter the staff member name.'));
               return;
           }
           
            if($("#semail").val()=='' || $("#sphn").val()=='' || $("#slogin").val()=='' || $("#spass").val()==''){
                bootbox.alert(SCTEXT('Please enter values in all the fields.'));
               return;
            }
            
            if(erremail==1 || errloginid==1 || errphone==1 || errpass==1){
                if(emsg==''){
                    bootbox.alert(SCTEXT('Some errors are found with your entry. Please rectify before submitting the form.'));
                }else{
                    bootbox.alert(emsg);
                }
                
                return;
            }
            
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Staff Member')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#staff_form").attr('action',app_url+'saveStaff');
                                $("#staff_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageStaff';
        });
        
        //match passwords
        $("#spass, #spass2").on("keyup blur",function(){
            var mode = $(this).attr('data-strength');
            var val = $(this).val();
            
            if(mode=='weak'){
                //length
                if(val.length < 6){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                }
            }
            
            if(mode=='average'){
                //length
                if(val.length < 8){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                    //alphabet letter
                    if(!/[a-zA-Z]/.test(val)){
                        errpass = 1;
                        $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one alphabet letter.'));
                    }else{
                        errpass = 0;
                        $("#pass-err").text('');
                        //numeric
                        if(!/[0-9]/.test(val)){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                        }
                        
                    }
                    
                }
            }
            
            if(mode=='strong'){
                //length
                if(val.length < 8){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                    //uppercase alphabet
                    if(!/[A-Z]/.test(val)){
                        errpass = 1;
                        $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one uppercase letter.'));
                    }else{
                        errpass = 0;
                        $("#pass-err").text('');
                        //numeric
                        if(!/[0-9]/.test(val)){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                            //special characters
                            if(!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(val)){
                                errpass = 1;
                                $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one special character.'));
                            }else{
                                errpass = 0;
                                $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                            }
                        }
                        
                    }
                    
                }
                
                    
            }
            if(errpass==0){
                //if everything is good match both passwords
                if($('#spass').val()!=$('#spass2').val()){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Passwords do not match each other. Please re-type your password'));
                }else{
                    errpass = 0;
                    $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                }
            }
        });
        
        //validate login id
        $("#slogin").on("keyup blur",function(){
            var lid = $(this).val();
            $("#v-login").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>');
            if(lid.indexOf(' ') >= 0 || lid.length<5){
                $("#v-login").html('<i class="fa fa-lg fa-times text-danger"></i>');
                errloginid=1;
                emsg = SCTEXT('Invalid login ID. Must be at least 5 characters without spaces.');
            }else{
                $("#v-login").html('<i class="fa fa-lg fa-check text-success"></i>');
                errloginid=0;
                emsg = '';
                //verify
                $.ajax({
                url: app_url+'checkAvailability',
                method: 'post',
                async: false,    
                data: {mode: 'login', value: lid},
                success: function(res){
                        if(res=='FALSE'){
                            $("#v-login").html('<i class="fa fa-lg fa-times text-danger"></i>');
                            errloginid=1;
                            emsg = SCTEXT('Login ID already exist. Please enter a different login ID.');
                        }else{
                            $("#v-login").html('<i class="fa fa-lg fa-check text-success"></i>');
                            errloginid=0;
                            emsg = '';
                            
                        }
                    }
                });
            }
            
        });
        //validate email
        $("#semail").on("keyup blur",function(){
            var email = $(this).val();
            $("#v-email").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>');
            if(!echeck(email)){
                $("#v-email").html('<i class="fa fa-lg fa-times text-danger"></i>');
                erremail=1;
                emsg = SCTEXT('Invalid Email ID');
            }else{
                $("#v-email").html('<i class="fa fa-lg fa-check text-success"></i>');
                erremail=0;
                emsg = '';
                //verify
                $.ajax({
                url: app_url+'checkAvailability',
                method: 'post',
                async: false,
                data: {mode: 'email', value: email},
                success: function(res){
                        if(res=='FALSE'){
                            $("#v-email").html('<i class="fa fa-lg fa-times text-danger"></i>');
                            erremail=1;
                            emsg = SCTEXT('Email ID already exist. Please enter a different email ID.');
                        }else{
                            $("#v-email").html('<i class="fa fa-lg fa-check text-success"></i>');
                            erremail=0;
                            emsg = '';
                            
                        }
                    }
                });
            }
            
        });
        //validate phone
        $("#sphn").on("keyup blur",function(){
            var phn = $(this).val();
            $("#v-phn").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>');
            if(!isValidPhone(phn)){
                $("#v-phn").html('<i class="fa fa-lg fa-times text-danger"></i>');
                errphone=1;
                emsg = SCTEXT('Invalid Phone number entered.');
            }else{
                $("#v-phn").html('<i class="fa fa-lg fa-check text-success"></i>');
                errphone=0;
                emsg = '';
                //verify
                $.ajax({
                url: app_url+'checkAvailability',
                method: 'post',
                async: false,
                data: {mode: 'mobile', value: phn},
                success: function(res){
                        if(res=='FALSE'){
                            $("#v-phn").html('<i class="fa fa-lg fa-times text-danger"></i>');
                            errphone=1;
                            emsg = SCTEXT('Phone number already exist. Please enter a different phone number.');
                        }else{
                            $("#v-phn").html('<i class="fa fa-lg fa-check text-success"></i>');
                            errphone=0;
                            emsg = '';
                            
                        }
                    }
                });
            }
            
        });
        
        
    }
    
    
    if(curpage=='view_staff'){
        var errpass = 1;
        
        //change team
        $("#changeTeam").click(function(){
           var uid = $(this).attr('data-uid');
            var tid = $("#team").val();
            $(this).attr('disabled','disabled').css("cursor","progress");
               $.ajax({
                  url: app_url+'changeTeam',
                   method: 'post',
                   data: {user: uid, team: tid},
                   success: function(){
                       window.location.reload();
                   }
               });
        });
        //change rights
         $("#save_changes").click(function(){
               
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Staff Rights')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#staff_form").attr('action',app_url+'saveStaffRights');
                                $("#staff_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageStaff';
        });
        
        //delete staff
        $("#delStaff").click(function(){
           var uid = $(this).attr('data-uid');
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this staff member?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location=app_url+'delStaff/'+uid;
                            }
                        }
                    }); 
        });
        //reset password
        $("#resetPass").click(function(){
            $("#resetPassBox").modal();
        });
        $(document).on("click","#resetPassSubmit",function(){
           if(errpass!=1){
               //no errors
               var pass1 = $("#spass").val();
               var pass2 = $("#spass2").val();
               var uid = $("#staff_uid").val();
               $(this).attr('disabled','disabled').css("cursor","progress");
               $.ajax({
                  url: app_url+'passwordReset',
                   method: 'post',
                   data: {user: uid, cat: 'staff', pass1: pass1, pass2: pass2},
                   success: function(){
                       window.location.reload();
                   }
               });
           } 
        });
        //match passwords
        $(document).on("keyup blur","#spass, #spass2",function(){
            var mode = $(this).attr('data-strength');
            var val = $(this).val();
            
            if(mode=='weak'){
                //length
                if(val.length < 6){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                }
            }
            
            if(mode=='average'){
                //length
                if(val.length < 8){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                    //alphabet letter
                    if(!/[a-zA-Z]/.test(val)){
                        errpass = 1;
                        $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one alphabet letter.'));
                    }else{
                        errpass = 0;
                        $("#pass-err").text('');
                        //numeric
                        if(!/[0-9]/.test(val)){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                        }
                        
                    }
                    
                }
            }
            
            if(mode=='strong'){
                //length
                if(val.length < 8){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                    //uppercase alphabet
                    if(!/[A-Z]/.test(val)){
                        errpass = 1;
                        $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one uppercase letter.'));
                    }else{
                        errpass = 0;
                        $("#pass-err").text('');
                        //numeric
                        if(!/[0-9]/.test(val)){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                            //special characters
                            if(!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(val)){
                                errpass = 1;
                                $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one special character.'));
                            }else{
                                errpass = 0;
                                $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                            }
                        }
                        
                    }
                    
                }
                
                    
            }
            if(errpass==0){
                //if everything is good match both passwords
                if($('#spass').val()!=$('#spass2').val()){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Passwords do not match each other. Please re-type your password'));
                }else{
                    errpass = 0;
                    $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                }
            }
        });
        
        
        //toggle checkall
        $("input.toggle").change(function(){
             var box = $(this).attr("data-group")+'_roles';
             var eid = $(this).attr('id');
             var status = $('#'+eid+':checked').length;
             
             if(status==0){
                 //uncheck all
                 $("#"+box).find("input[type=checkbox]").each(function(){
                     $(this).prop('checked',false);
                 });
             }else{
                 //check all
                 $("#"+box).find("input[type=checkbox]").each(function(){
                     $(this).prop('checked',true);
                 })
             } 
         });
    }
    
    
// 15. manage users
    
    if(curpage=='manage_users'){
        //filter for all users or admin downline only
        if($("#usrfilter").length>0){
            $("#usrfilter").on("change",function(){
                var flag = $("#usrfilter option:selected").val();
                $('#t-usrlist').dataTable().api().ajax.url(app_url+"getAllUsers?flag="+flag).load();
            })
        }
    }
    
    if(curpage=='add_user'){
        let mccmncflag = 0;
        var erremail = 0;
        var errloginid = 0;
        var errphone = 0;
        var errpass = 0;
        var emsg = '';
        var errcredits = 0; //error flag so resellers cannot allot more credits than balance

        //based on billing type selection, perform tasks
        if($("#acctype").length>0){
            $("#acctype").on("change", function(){
                let accounttype = $(this).val();
                
                $("#acctypeinfo").text($("#acctype option:selected").attr('data-info'));
                if(accounttype=='1'){
                    //show mccmnc based plan options
                    $("#ucat").html(`<option value="client">${SCTEXT('Client Account')}</option>`).trigger('change.select2');
                    $("#creditbox").hide('fade',function(){
                        $("#currencybox").show();
                    })
                    mccmncflag = 1;
                }else{
                    //show credit based billing options
                    $("#ucat").html(`<option value="client">${SCTEXT('Client Account')}</option><option value="reseller">${SCTEXT('Reseller Account')}</option>`).trigger('change.select2');
                    $("#currencybox").hide('fade',function(){
                        $("#creditbox").show();
                    })
                    mccmncflag = 0;
                }
            })

            //plan selection
            $("#mccmncplansxdswa2").on("change", function(){
                $("#mplanscredits").trigger("blur");
            })
            
        }

        //for mcc mnc user, based on selected plan calculate total payable
        if($("#currencybox").length>0){
            $(document).on("keyup blur input","#mplanscredits", function(){
                //only numbers allowed
                if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test($(this).val()) && $(this).val()!=''){
                    $(this).addClass('error-input');
                    e.preventDefault();return;
                }else{
                    $(this).removeClass('error-input');
                }
                let tax = $("#mccmncplans option:selected").attr('data-ptax');
                let taxtype = $("#mccmncplans option:selected").attr('data-taxtype');
                let credits = parseFloat($("#mplanscredits").val()) || 0;
                let gtotal = 0;
                let taxstr = 'including all taxes';
                if(parseFloat(tax)>0){
                    gtotal = (credits + parseFloat((credits * (tax/100)))).toFixed(2);
                    let taxes = [
                        {tax: 'GT', str: 'GST'},
                        {tax: 'VT', str: 'VAT'},
                        {tax: 'ST', str: 'Service Tax'},
                        {tax: 'SC', str: 'Service Charges'},
                        {tax: 'OT', str: 'Other Taxes'}
                    ];
                    let taxtypestr = taxes.find((item) => item.tax==taxtype);
                    taxstr = `including ${tax}% ${taxtypestr.str}`;
                }else{
                    gtotal = credits.toFixed(2);
                }
                $("#total_payable").text(new Number(gtotal).toLocaleString('en-US', {minimumFractionDigits: 2}));
                $("#mcc_taxes").text(`(${taxstr})`);

            })
        }
        
        //match passwords
        $("#upass, #upass2").on("keyup blur",function(){
            var mode = $(this).attr('data-strength');
            var val = $(this).val();
            
            if(mode=='weak'){
                //length
                if(val.length < 6){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                }
            }
            
            if(mode=='average'){
                //length
                if(val.length < 8){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                    //alphabet letter
                    if(!/[a-zA-Z]/.test(val)){
                        errpass = 1;
                        $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one alphabet letter.'));
                    }else{
                        errpass = 0;
                        $("#pass-err").text('');
                        //numeric
                        if(!/[0-9]/.test(val)){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                        }
                        
                    }
                    
                }
            }
            
            if(mode=='strong'){
                //length
                if(val.length < 8){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                    //uppercase alphabet
                    if(!/[A-Z]/.test(val)){
                        errpass = 1;
                        $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one uppercase letter.'));
                    }else{
                        errpass = 0;
                        $("#pass-err").text('');
                        //numeric
                        if(!/[0-9]/.test(val)){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                            //special characters
                            if(!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(val)){
                                errpass = 1;
                                $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one special character.'));
                            }else{
                                errpass = 0;
                                $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                            }
                        }
                        
                    }
                    
                }
                
                    
            }
            if(errpass==0){
                //if everything is good match both passwords
                if($('#upass').val()!=$('#upass2').val()){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Passwords do not match each other. Please re-type your password'));
                }else{
                    errpass = 0;
                    $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                }
            }
        });
        //validate login id
        $("#ulogin").on("keyup blur",function(){
            var lid = $(this).val();
            $("#v-login").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>');
            if(lid.indexOf(' ') >= 0 || lid.length<5){
                $("#v-login").html('<i class="fa fa-lg fa-times text-danger"></i>');
                errloginid=1;
                emsg = SCTEXT('Invalid login ID. Must be at least 5 characters without spaces.');
            }else{
                $("#v-login").html('<i class="fa fa-lg fa-check text-success"></i>');
                errloginid=0;
                emsg = '';
                //verify
                $.ajax({
                url: app_url+'checkAvailability',
                method: 'post',
                async: false,    
                data: {mode: 'login', value: lid},
                success: function(res){
                        if(res=='FALSE'){
                            $("#v-login").html('<i class="fa fa-lg fa-times text-danger"></i>');
                            errloginid=1;
                            emsg = SCTEXT('Login ID already exist. Please enter a different login ID.');
                        }else{
                            $("#v-login").html('<i class="fa fa-lg fa-check text-success"></i>');
                            errloginid=0;
                            emsg = '';
                            
                        }
                    }
                });
            }
            
        });
        //validate email
        $("#uemail").on("keyup blur",function(){
            var email = $(this).val();
            $("#v-email").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>');
            if(!echeck(email)){
                $("#v-email").html('<i class="fa fa-lg fa-times text-danger"></i>');
                erremail=1;
                emsg = SCTEXT('Invalid Email ID');
            }else{
                $("#v-email").html('<i class="fa fa-lg fa-check text-success"></i>');
                erremail=0;
                emsg = '';
                //verify
                $.ajax({
                url: app_url+'checkAvailability',
                method: 'post',
                async: false,
                data: {mode: 'email', value: email},
                success: function(res){
                        if(res=='FALSE'){
                            $("#v-email").html('<i class="fa fa-lg fa-times text-danger"></i>');
                            erremail=1;
                            emsg = SCTEXT('Email ID already exist. Please enter a different email ID.');
                        }else{
                            $("#v-email").html('<i class="fa fa-lg fa-check text-success"></i>');
                            erremail=0;
                            emsg = '';
                            
                        }
                    }
                });
            }
            
        });
        //validate phone
        $("#uphn").on("keyup blur",function(){
            var phn = $(this).val();
            $("#v-phn").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>');
            if(!isValidPhone(phn)){
                $("#v-phn").html('<i class="fa fa-lg fa-times text-danger"></i>');
                errphone=1;
                emsg = SCTEXT('Invalid Phone number entered.');
            }else{
                $("#v-phn").html('<i class="fa fa-lg fa-check text-success"></i>');
                errphone=0;
                emsg = '';
                //verify
                $.ajax({
                url: app_url+'checkAvailability',
                method: 'post',
                async: false,
                data: {mode: 'mobile', value: phn},
                success: function(res){
                        if(res=='FALSE'){
                            $("#v-phn").html('<i class="fa fa-lg fa-times text-danger"></i>');
                            errphone=1;
                            emsg = SCTEXT('Phone number already exist. Please enter a different phone number.');
                        }else{
                            $("#v-phn").html('<i class="fa fa-lg fa-check text-success"></i>');
                            errphone=0;
                            emsg = '';
                            
                        }
                    }
                });
            }
            
        });
        
        
        //assign revoke routes
        $(document).on("click",".route-sel",function(){
            var ele = $(this);
             var eid = $(this).attr('id');
             var status = $('#'+eid+':checked').length;
             
             if(status==0){
                 //disable
                 ele.parent().parent().next().find("input.form-control").each(function(){
                     $(this).attr('disabled','disabled');
                 }); 
             }else{
                 //enable
                 ele.parent().parent().next().find("input.form-control").each(function(){
                     $(this).attr('disabled',false);
                 }); 
             }
            //calculate
            $("input.rtcredits").trigger('blur');
        });
        
        //switch sms plans
        $("#plan").change(function(){
           var planid = $(this).val() ;
            var ptype = $("#plan option:selected").attr('data-type');
            var rts = $("#plan option:selected").attr('data-rts');
            //get plan options
            $.ajax({
                url: app_url+'getSelPlanOptions',
                method: 'post',
                data: {planid: planid, ptype: ptype, routes: rts},
                success: function(res){
                    //make total & grand total zero
                    $("#total_amt, #grand_total_amt").text('0.00');
                    $("#udis, #utax").val('');
                    $("#plan_taxes").text('');
                    
                    if(ptype=='0'){
                        //volume based
                        var resar = [];
                        var rtdata = [];
                        resar = JSON.parse(res);
                        rtdata = resar['opt_data'];
                        var str = '';
                        for (rid in rtdata){
                           
                            if(planid==0){
                                //custom rates
                                 str += '<div class=po-ctr data-rid="'+rid+'"><div><div class="checkbox checkbox-primary"><input class=route-sel name="route['+rid+']"checked id="rtsel-'+rid+'" type=checkbox><label for="rtsel-'+rid+'">'+rtdata[rid]['title']+'</label></div></div><div><table class="row-border table wd100"><thead><tr><th>'+SCTEXT('SMS Credits')+'<th>'+SCTEXT('per SMS Cost')+'<tbody><tr><td><div class=input-group><input data-pid="'+planid+'" data-rid="'+rid+'" class="rtcredits form-control input-sm input-small-sc"name="credits['+rid+']"placeholder="e.g. 5000" id="rtcre-'+rid+'"><span class=input-group-addon>sms</span></div><td><div class=input-group><span class=input-group-addon>'+app_currency+'</span><input data-pid="'+planid+'" data-rid="'+rid+'" class="rtrates form-control input-sm input-small-sc"name="price['+rid+']"placeholder="e.g. 0.05" value="" id="rtprc-'+rid+'"></div></table></div></div>';
                            }else{
                                //predefined rates
                                 str += '<div class=po-ctr data-rid="'+rid+'"><div><div class="checkbox checkbox-primary"><input class=route-sel name="route['+rid+']"checked id="rtsel-'+rid+'" type=checkbox><label for="rtsel-'+rid+'">'+rtdata[rid]['title']+'</label></div></div><div><table class="row-border table wd100"><thead><tr><th>'+SCTEXT('SMS Credits')+'<th>'+SCTEXT('per SMS Cost')+'<tbody><tr><td><div class=input-group><input data-pid="'+planid+'" data-rid="'+rid+'" class="rtcredits form-control input-sm input-small-sc"name="credits['+rid+']"placeholder="e.g. 5000" id="rtcre-'+rid+'"><span class=input-group-addon>sms</span></div><td><div class=input-group><span class=input-group-addon>'+app_currency+'</span><input data-pid="'+planid+'" data-rid="'+rid+'" class="rtrates form-control input-sm input-small-sc"name="price['+rid+']"placeholder="e.g. 0.05" readonly value="'+rtdata[rid]['price']+'" id="rtprc-'+rid+'"></div></table></div></div>';
                            }
                            
                           
                        }
                        $("div.route-assign-ctr").html(str);
                        $("#routes-n-credits").find(".control-label").each(function(){
                           $(this).text(SCTEXT('Routes & Credits')+':'); 
                        });
                        $("#ptype").val('0');
                    }else{
                        //subscription based
                        var resar = [];
                        var pdata = [];
                        resar = JSON.parse(res);
                        pdata = resar['opt_data'];
                        var str = '<select name="plan_option" id="popt-sel" class="form-control" data-plugin="select2"><option></option>';
                        for(idn in pdata){
                            var prc = pdata[idn]['cycle']=='m'?app_currency+pdata[idn]['fee']+' per month':app_currency+pdata[idn]['fee']+' per year';
                            str += '<option value="'+idn+'">'+pdata[idn]['name']+' Plan ( '+prc+' )</option>';
                        }
                        str += '</select>';
                        $("div.route-assign-ctr").html(str);
                        $("div.route-assign-ctr").find("#popt-sel").each(function(){
                            $(this).select2({placeholder: SCTEXT('Choose Plan Option')+' . . .'});
                        });
                        $("#routes-n-credits").find(".control-label").each(function(){
                           $(this).text(SCTEXT('Plan Options:')); 
                        });
                        $("#ptype").val('1');
                    }
                }
            });
            
        });
        
        //change total and grand total when sms credits or price change
        $(document).on("keyup blur input",".rtcredits, .rtrates",function(e){
            
            //only numbers allowed
            if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test($(this).val()) && $(this).val()!=''){
                $(this).addClass('error-input');
                e.preventDefault();return;
            }else{
                $(this).removeClass('error-input');
            }
           //for each selected route get credits entered and calculate final price
            var routencredits = [];
            var pid = parseInt($("#plan").val());
            $("#routes-n-credits").find(".po-ctr").each(function(){
                var ele = $(this);
                var rid = ele.attr('data-rid');
                if($('#rtsel-' + rid).is(":checked")){
                    //route assigned
                    var rdata = {id:rid, credits:$("#rtcre-"+rid).val(), price:$("#rtprc-"+rid).val()}; 
                    routencredits.push(rdata);
                    
                }
            });
            
                //send these data and get sms rate applicable for this volume
                $.ajax({
                    url: app_url+'getPlanSmsPrice',
                    method: 'post',
                    data: {plan: pid, routesData: JSON.stringify(routencredits), discount: $("#udis").val(), dtype: $("#distype").val(), addTax: $("#utax").val()},
                    success: function(res){
                        var myarr = [];
                        myarr = JSON.parse(res);
                        //you have the price and credits entered
                        
                        //update the rate received from the db in case a plan is chosen
                        if(pid!='0'){
                            for (grid in myarr.price){
                            $("#rtprc-"+grid).val(myarr.price[grid].price);
                            }
                        }
                    
                        
                        var plan_cost = myarr.total_plan;
                        var ptax = myarr.plan_tax;
                        var gtotal = myarr.grand_total;
                        
                        //put plan total
                        $("#total_amt").text(plan_cost);
                        
                        //put tax declaration
                        $("#plan_taxes").text(ptax);
                        
                        //put grand total
                        $("#grand_total_amt").text(gtotal);
                        
                        //check error 
                        if(myarr.errcredits=='1'){
                            errcredits = 1
                        }else{
                            errcredits = 0;
                        }
                        
                    }
                });
            
            
            
        });
        
        //change total and grand total when plan option is selected
        $(document).on("change","#popt-sel",function(){
            var pid = $("#plan").val();
            var idn = $(this).val();
            //send the idn additional taxes and discount to server
            $.ajax({
                    url: app_url+'getPlanSmsPrice',
                    method: 'post',
                    data: {mode: 'sub', plan: pid, idn: idn, discount: $("#udis").val(), dtype: $("#distype").val(), addTax: $("#utax").val()},
                    success: function(res){
                        var myarr = [];
                        myarr = JSON.parse(res);
                        //you have the price and tax
                        
                        var plan_cost = myarr.total_plan;
                        var ptax = myarr.plan_tax;
                        var gtotal = myarr.grand_total;
                        
                        //put plan total
                        $("#total_amt").text(plan_cost);
                        
                        //put tax declaration
                        $("#plan_taxes").text(ptax);
                        
                        //put grand total
                        $("#grand_total_amt").text(gtotal);
                    }
                });
        });
        
        //addtnal tax n discount change event
        $("#utax, #udis").on("keyup blur",function(){
            //only numbers allowed
            if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test($(this).val()) && $(this).val()!=''){
                $(this).addClass('error-input');
                e.preventDefault();return;
            }else{
                $(this).removeClass('error-input');
            }
            
            if($("#ptype").val()=='1'){
                //subs based
                $("#popt-sel").trigger("change");
            }else{
                //vol based
                $("input.rtcredits").trigger('blur');
            }
        });
        $("#distype").on("change",function(){
            if($("#ptype").val()=='1'){
                //subs based
                $("#popt-sel").trigger("change");
            }else{
                //vol based
                $("input.rtcredits").trigger('blur');
            }
        });
        
        //show remarks box for prepaid accounts
        $("#inv-p, #inv-d").click(function(){
            if($(this).val()=='1'){
                $("#invrmbox").removeClass("hidden");
            }else{
                $("#invrmbox").addClass("hidden");
            }
        })
        
        //submit
         $("#save_changes").click(function(){
             
             //validate all fields
             if($("#uname").val()==''){
               bootbox.alert(SCTEXT('Please enter name of the user.'));
               return;
               }

                if($("#uemail").val()=='' || $("#uphn").val()=='' || $("#ulogin").val()=='' || $("#upass").val()==''){
                    bootbox.alert(SCTEXT('Please enter values in all the fields.'));
                   return;
                }

                if(erremail==1 || errloginid==1 || errphone==1 || errpass==1){
                    if(emsg==''){
                        bootbox.alert(SCTEXT('Some errors are found with your entry. Please rectify before submitting the form.'));
                    }else{
                        bootbox.alert(emsg);
                    }

                    return;
                }
             
             if(errcredits==1){
                 bootbox.alert(SCTEXT('You cannot assign more credits than available in your account.'));
                 return;
             }
             
             //cannot assign subscription based plan for reseller
             if($("#ptype").val()=='1' && $("#ucat").val()=='reseller'){
                bootbox.alert(SCTEXT('Subscription based plans cannot be assigned to reseller accounts. Please choose a different plan or assign custom SMS rates.'));
               return; 
             }
             
             //if vol based pricing make sure at least one route is assigned properly
             if(mccmncflag==0){
                if($("#ptype").val()=='0'){
                    var $creditserr = 0;
                    
                    $("#routes-n-credits").find(".po-ctr").each(function(){
                       var ele = $(this);
                       var rid = ele.attr('data-rid');
                       if($('#rtsel-' + rid).is(":checked")){
                           //route assigned
                           if($("#rtcre-"+rid).val()==''){
                               $("#rtcre-"+rid).addClass('error-input');
                               $creditserr = 1;
                               $cemsg = SCTEXT('Please enter the credits to be assigned. If you do not wish to assign this route, uncheck the Route name.');
                               return false; //break
                               }else{
                                   $("#rtcre-"+rid).removeClass('error-input');
                                   $creditserr = 0;
                               }
                               //price
                               if($("#rtprc-"+rid).val()=='' || $("#rtprc-"+rid).val()==0){
                                   $("#rtprc-"+rid).addClass('error-input');
                                   $creditserr = 1;
                                   $cemsg = 'Please enter the sms rate. This cannot be blank or zero';
                                   return false; //break
                               }else{
                                   $("#rtprc-"+rid).removeClass('error-input');
                                   $creditserr = 0;
                               }
                           }
                       });
                    
                   if($creditserr==1){
                       bootbox.alert($cemsg);
                       return;
                   }
                
                }else{
                    //if subscriptn based make sure plan option is selected
                    if($("#popt-sel").val()==0 || $("#popt-sel").val()==null){
                       bootbox.alert('Please select one subscription plan option for this user');
                       return;
                    }
                }
             }else{
                 //check if invalid credits
                 if($("#mplanscredits").val()=='' || parseFloat($("#mplanscredits").val())<=0){
                    bootbox.alert(SCTEXT('Please enter valid credits. This cannot be blank or zero'));
                    return;
                 }
             }
             
            
             
               
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Creating Account')}. . . ${SCTEXT('This might take a few seconds.')}</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#user_form").attr('action',app_url+'createUserAccount');
                                $("#user_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageUsers';
        });
        
    }
    
    
    
    
//16. Website Management
    if(curpage=='gen_web_set'){
          //submit form
        $("#save_changes").click(function(){
            //validate
           if($("#comname").val()==''){
               bootbox.alert(SCTEXT('Please enter name of the company.'));
               return;
           }
            
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Website Settings')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#set_form").attr('action',app_url+'saveWebSettings');
                                $("#set_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'genWebSettings';
        });
    }
    
    if(curpage=='sig_web_set'){
         //submit form
        $("#save_changes").click(function(){
            //validate
            //only numbers allowed
            if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test($('#smsrate').val()) && $('#smsrate').val()!=''){
                $('#smsrate').addClass('error-input');
                bootbox.alert(SCTEXT('Please enter valid SMS rate'));
                return;
            }else{
                $('#smsrate').removeClass('error-input');
            }
            
           if(!isPositiveInteger($("#frecre").val())){
               bootbox.alert(SCTEXT('Please enter valid SMS credits'));
               return;
           }
            
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Sign up Settings')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#sig_form").attr('action',app_url+'saveSignupSettings');
                                $("#sig_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'signupWebSettings';
        });
        
    }
    
    if(curpage=='thm_web_set'){
        //color options
        $("a.color").each(function(){
           var ele = $(this);
            ele.css("background-color",ele.attr('data-color'));
            if($("#ccode").val()==ele.attr('data-color')){
                ele.addClass('activeColor');
            }
        });
        //change color
        $(document).on("click","a.color",function(){
            var ele = $(this);
            var pele = ele.parent().parent();
            //remove the check
            pele.find("a.color").each(function(){
                $(this).removeClass('activeColor').html('');
            });
            ele.addClass('activeColor').html('<i class="fa fa-lg fa-check fa-inverse"></i>');
        });
        //apply theme
        $(document).on("click",".btn-primary",function(){
           var btn = $(this);
            var colele = btn.prev().prev().find("a.activeColor");
            $("#cname").val(colele.attr('data-code'));
            $("#ccode").val(colele.attr('data-color'));
            $("#tname").val(btn.attr('data-theme'));
            
            var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Applying selected theme')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#thm_form").attr('action',app_url+'updateThemeSettings');
                                $("#thm_form").submit();
                                }, 200);
                            }); 
            
        });
    }
    
    
    if(curpage=='home_web_set'){
        //banner upload
        $(document).on("change",".sld-file",function(){
            var ele = $(this);
            ele.next().next().html(ele.val());
        });
        //twg yes no
        $("#twg-y, #twg-n").click(function(){
            var sel = $(this).val();
            if(sel=='1'){
                $("#twg-opts").removeClass('disabledBox');
            }else{
                $("#twg-opts").addClass('disabledBox');
            }
        });
        //slider yes no
        $("#sld-y, #sld-n").click(function(){
            var sel = $(this).val();
            if(sel=='1'){
                $("#sld-opts").removeClass('disabledBox');
            }else{
                $("#sld-opts").addClass('disabledBox');
            }
        });
        //submit
        $("#save_changes").click(function(){
            
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Please wait. Saving Home page Settings')} . . This may take a while</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},1500)
                            setTimeout(function(){
                                $("#set_form").attr('action',app_url+'saveWebPageSettings');
                                $("#set_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'homeWebSettings';
        });
    }
    
    
    if(curpage=='about_web_set'){
        
        //submit
        $("#save_changes").click(function(){
            
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving About page Settings')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#set_form").attr('action',app_url+'saveWebPageSettings');
                                $("#set_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'aboutWebSettings';
        });
    }
    
    if(curpage=='pricing_web_set'){
        
        //submit
        $("#save_changes").click(function(){
            
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Pricing page Settings')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#set_form").attr('action',app_url+'saveWebPageSettings');
                                $("#set_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'pricingWebSettings';
        });
    }
    
    if(curpage=='contact_web_set'){
        
        //submit
        $("#save_changes").click(function(){
            
            if($("#qmail").val()==''){
                bootbox.alert(SCTEXT('Email cannot be empty.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Contact page Settings')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#set_form").attr('action',app_url+'saveWebPageSettings');
                                $("#set_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'contactWebSettings';
        });
    }
    
    if(curpage=='login_web_set'){
        
        //submit
        $("#save_changes").click(function(){
            
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Login page Settings')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#set_form").attr('action',app_url+'saveWebPageSettings');
                                $("#set_form").submit();
                                }, 200);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'loginWebSettings';
        });
    }

    
//17. Client Dashboard
    
    if(curpage=='client_dashboard'){
        
        //load notifs
        loadAppAlerts();
        
             $('#smsstdp').daterangepicker({
                ranges: {
                    'Today': ['today', 'today'],
                    'Yesterday': ['yesterday', 'yesterday'],
                    'Last 7 Days': [Date.today().add({
                        days: -6
                    }), 'today'],
                    'Last 30 Days': [Date.today().add({
                        days: -29
                    }), 'today'],
                    'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                    'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                        months: -1
                    }), Date.today().moveToFirstDayOfMonth().add({
                        days: -1
                    })]
                },
                opens: 'right',
                format: 'MM/dd/yyyy',
                separator: ' to ',
                startDate: Date.today().add({
                    days: -29
                }),
                endDate: Date.today(),
                minDate: '01/01/2012',
                maxDate: '12/31/2020',
                locale: {
                    applyLabel: 'Apply',
                    clearLabel: 'Cancel',
                    customRangeLabel: 'Custom Range',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                    monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    firstDay: 1
                },
                showWeekNumbers: true,
                buttonClasses: ['btn-danger']
            },
            function (start, end) {
                $('#smsstdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
                //reload sms figures
                   $.ajax({
                            type: 'GET',
                            url: app_url+'getUserSmsActivity/'+$('#smsstdp span').html(),
                            success: function(res){
                                var mydata = JSON.parse(res);
                                $str = `<ul class="list-group"><li class="list-group-item"><span class="badge badge-info">${mydata.sent || 0}</span>${SCTEXT('Total SMS Sent')}</li><li class="list-group-item"><span class="badge badge-success">${mydata.delivered || 0}</span>${SCTEXT('SMS Delivered')}</li><li class="list-group-item"><span class="badge badge-danger">${mydata.failed || 0}</span>${SCTEXT('Failed SMS')}</li><li class="list-group-item"><span class="badge badge-purple">${mydata.used || 0}</span>${SCTEXT('Credits Used')}</li><li class="list-group-item"><span class="badge badge-pink">${mydata.refunds || 0}</span>${SCTEXT('Credits Refunded')}</li></ul>`;
                                $("#smsactctr").fadeOut(function(){$(this).html($str).fadeIn();})
                            }
                            });

            });
            //Set the initial state of the picker label
             $('#smsstdp span').html(Date.today().add({
                days: -6
            }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));

            //----------------//      

    
        //load dash stats
        $.ajax({
            type: 'GET',
            url: app_url+'getUserDashStats',
            success: function(res){
                var mydata = JSON.parse(res);
                $sms_this_week = mydata.sms_this_week;
                $sms_this_month = mydata.sms_this_month;
                $sms_seven_days = mydata.sms_seven_days;
                $total_sms_seven_days = mydata.total_sms_data_last_seven;

                $('#weekly_cre_ctr').html(mydata.total_weekly_credits || 0);
                $('#weekly_ref_ctr').html(mydata.total_weekly_refunds || 0);
                $('#weekly_sms_ctr').html(mydata.total_weekly_sms);
                $('#monthly_sms_ctr').html(mydata.total_monthly_sms);

                //weekly small chart
                var arr = [];
                    for (elem in mydata.weekly_sms) {
                       arr.push(mydata.weekly_sms[elem]);
                    }
                var s_arr = [];
                    for (s_elem in mydata.monthly_sms) {
                       s_arr.push(mydata.monthly_sms[s_elem]);
                    }
               $("#wk_sm_chart").sparkline(arr,{type: 'bar', barColor: '#ffffff', barWidth: 3, barSpacing: 2});
                $("#mn_sm_chart").sparkline(s_arr,{type: 'bar', barColor: '#ffffff', barWidth: 2, barSpacing: 1.5});
               //monthly small chart
                 var arr2 = [];
                    for (elem2 in mydata.weekly_credits) {
                       arr2.push(mydata.weekly_credits[elem2]);
                    }
                var s_arr2 = [];
                    for (s_elem2 in mydata.weekly_refunds) {
                       s_arr2.push(mydata.weekly_refunds[s_elem2]);
                    }
                $("#wk_cre_chart").sparkline(arr2,{type: 'bar', barColor: '#ffffff', barWidth: 3, barSpacing: 2});
                $("#wk_ref_chart").sparkline(s_arr2,{type: 'bar', barColor: '#ffffff', barWidth: 3, barSpacing: 2});

                

                // sms activity
                var sent = parseInt(mydata.total_sms_data_last_seven.sent) || 0;
                var del = parseInt(mydata.total_sms_data_last_seven.delivered) || 0;
                var fld = parseInt(mydata.total_sms_data_last_seven.failed) || 0;
                var cre = parseInt(mydata.total_sms_data_last_seven.used) || 0;
                var ref = parseInt(mydata.total_sms_data_last_seven.refunds) || 0;
                
                var str = `<ul class="list-group"><li class="list-group-item"><span class="badge badge-info">${sent}</span>${SCTEXT('Total SMS Sent')}</li><li class="list-group-item"><span class="badge badge-success">${del}</span>${SCTEXT('SMS Delivered')}</li><li class="list-group-item"><span class="badge badge-danger">${fld}</span>${SCTEXT('Failed SMS')}</li><li class="list-group-item"><span class="badge badge-purple">${cre}</span>${SCTEXT('Credits Used')}</li><li class="list-group-item"><span class="badge badge-pink">${ref}</span>${SCTEXT('Credits Refunded')}</li></ul>`;
                $("#smsactctr").fadeOut(function(){$(this).html(str).fadeIn();})

            }
        });

        
        //recent transactions
         $.ajax({
            type: 'GET',
            url: app_url+'getRecentTransactions',
            success: function(res){
                var mydata = JSON.parse(res);
                $("#rectransbox").fadeOut(function(){
                    $(this).html(mydata.str).fadeIn();
                });
            }
            });
        
        
        //recent campaigns
         $.ajax({
            type: 'GET',
            url: app_url+'getRecentCampaigns',
            success: function(res){
                var mydata = JSON.parse(res);
                $("#recsmsbox").fadeOut(function(){
                    $(this).html(mydata.str).fadeIn();
                });
            }
            });
    }
    
    
    
//18. Sender ID Mgmt
    
    if(curpage=='manage_sender'){
        $(document).on("click",".del-sid",function(){
            var sid = $(this).attr('data-sid');
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this Sender ID?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location=app_url+'deleteSender/'+sid;
                            }
                        }
                    }); 
            
        });
    }
    
    if(curpage=='add_sender' || curpage=='edit_sender'){
        //submit
        $("#save_changes").click(function(){
            
            if($("#sid").val()==''){
                bootbox.alert(SCTEXT('Sender ID cannot be blank.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Sender ID')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},200)
                            setTimeout(function(){
                                $("#sid_form").attr('action',app_url+'saveSender');
                                $("#sid_form").submit();
                                }, 100);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageSenderId';
        });
    }
    
    

//19. SMS Template Mgmt
    
    if(curpage=='manage_templates'){
        $(document).on("click",".del-tmp",function(){
            var tid = $(this).attr('data-tmp');
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this SMS Template?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location=app_url+'deleteTemplate/'+tid;
                            }
                        }
                    }); 
            
        });
    }
    
    if(curpage=='add_template' || curpage=='edit_template'){
        //toggle route box
        $("#toggle-rt").change(function(){
           $("#rtbox").toggleClass("hidden"); 
        });
        //submit
        $("#save_changes").click(function(){
            
            if($("#tname").val()==''){
                bootbox.alert(SCTEXT('Template name cannot be blank.'));
                return;
            }
            if($("#tcont").val()==''){
                bootbox.alert(SCTEXT('Template content cannot be blank.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving SMS Template')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},200)
                            setTimeout(function(){
                                $("#tmp_form").attr('action',app_url+'saveTemplate');
                                $("#tmp_form").submit();
                                }, 100);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageTemplates';
        });
    }
    
   
    
    
//20. Contact group Mgmt
    
    if(curpage=='manage_groups'){
        $(document).on("click",".del-gid",function(){
            var gid = $(this).attr('data-gid');
            bootbox.confirm({
                    message: SCTEXT("All contacts from this group will be deleted. Are you sure you want to delete this contact group?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location=app_url+'deleteGroup/'+gid;
                            }
                        }
                    }); 
            
        });
    }
    
    if(curpage=='add_group' || curpage=='edit_group'){
        //submit
        $("#save_changes").click(function(){
            
            if($("#gname").val()==''){
                bootbox.alert(SCTEXT('Group name cannot be blank.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving contact group')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},200)
                            setTimeout(function(){
                                $("#grp_form").attr('action',app_url+'saveGroup');
                                $("#grp_form").submit();
                                }, 100);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageGroups';
        });
    }
    
    if(curpage=='move_contacts'){
        //submit
        $("#save_changes").click(function(){
            
            if($("#grp").val()==0){
                bootbox.alert(SCTEXT('Please select a group.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Moving contacts to selected group')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},200)
                            setTimeout(function(){
                                $("#grp_form").attr('action',app_url+'saveMoveContacts');
                                $("#grp_form").submit();
                                }, 100);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageGroups';
        });
    }
    
    
    if(curpage=='manage_contacts'){
        $(document).on("click",".del-cid",function(){
            var cid = $(this).attr('data-cid');
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this contact?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location=app_url+'deleteContact/'+cid;
                            }
                        }
                    }); 
            
        });
    }
    
    if(curpage=='add_contact' || curpage=='edit_contact'){
        //submit
        $("#save_changes").click(function(){
            
            if($("#contactno").val()==0 || !isValidPhone($("#contactno").val())){
                bootbox.alert(SCTEXT('Invalid contact number entered. Please enter a proper mobile number.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Contact')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},200)
                            setTimeout(function(){
                                $("#ct_form").attr('action',app_url+'saveContacts');
                                $("#ct_form").submit();
                                }, 100);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'viewContacts/'+$("#groupid").val();
        });
    }
    
    if(curpage=='import_contact'){
        //show group columns
        $("#group").on("change",function(){
            if($(this).val()!=''){
                $("#colbox").html(atob($("#group option:selected").attr("data-colstr")));
                $('body').tooltip({
                    selector: '[data-toggle="tooltip"]'
                });
            }else{
                $("#colbox").html('- '+SCTEXT('Select a group to display column suggestions')+' -');
            }
        })
        
        //submit
        $("#save_changes").click(function(){
            
            if($("#group").val()=='' || $("#group").val()==0){
                bootbox.alert(SCTEXT('Choosing a group name is required. Add a new group if you do not have any yet.'));
                return;
            }
            //check if any upload is in progress
            if($("#uprocess").val()==1){
                bootbox.alert(SCTEXT('File upload is in progress. Kindly wait for upload to finish or Cancel Upload & proceed.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Importing Contacts. This may take a while. Please wait')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#ct_form").attr('action',app_url+'saveContacts');
                                $("#ct_form").submit();
                                }, 50);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageGroups';
        });
    }
    
    
    
//21. Send SMS
    
    if(curpage=='composeSMS' || curpage=='resend_campaign' || curpage=="edit_sch_campaign"){

        
        var rangeErr = 0;
        
        //show hide phonebook contacts
        if($("#syspb").length>0){
            //toggle
            $("input[name='contact-type']").click(function(){
                var ele = $(this);
                if(ele.val()=='my'){
                   $("#phonebookbox").hide("fade", function(){
                       //show my 
                       $("#mycontactbox").show("fade");
                   });

                }else{
                    $("#mycontactbox").hide("fade", function(){
                       //show my 
                       $("#phonebookbox").show("fade");
                   });

                } 
                calcContacts();

            });
            //phonebook group selection
            $(document).on("click",".pbdbsel",function(){
                //show the count 
                var scount = $(this).attr('data-count');
                
                if(scount=='0'){scount=1;}
                
                $("#pbfrom").val('1');
                $("#pbto").val(scount);
                
                calcContacts();
            });
            
            //range 
            $("#pbfrom, #pbto").on("keyup blur", function(e){
                //only numbers allowed
                if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test($(this).val()) && $(this).val()!=''){
                    $(this).addClass('error-input');
                    rangeErr = 1;
                    e.preventDefault();return;
                }else{
                    $(this).removeClass('error-input');
                    rangeErr = 0;
                }
                
                //greater than 0
                if(parseInt($(this).val())<1){
                    $(this).addClass('error-input');
                    rangeErr = 1;
                    e.preventDefault();return;
                }
                
                //within max value
                var maxval = parseInt($(".pbdbsel:checked").attr("data-count"));
                if(parseInt($(this).val())>maxval){
                    $(this).addClass('error-input');
                    rangeErr = 1;
                    e.preventDefault();return;
                }
                
                //calculate contacts
                calcContacts();
                
            })
            
        }
        
        
        //toggle column box on personalize sms type
        $("#dynsms").on("change",function(){
           if($(this).is(":checked")){
               $("#xlcolbox").removeClass("hidden");
               $("#dyncountnotice").removeClass("hidden");
               $("#grpsel").prepend('<option id="placeholder4cgsel"></option>');
               $("#grpsel").attr("multiple",false);
               $("#grpsel").select2("destroy").select2({placeholder: SCTEXT('Select Group')+'. . . .'});
               $("#contactinput").attr("disabled","disabled");
           }else{
               $("#xlcolbox").addClass("hidden");
               $("#dyncountnotice").addClass("hidden");
               $("#placeholder4cgsel").remove();
               $("#grpsel").attr("multiple",true);
               $("#grpsel").select2("destroy").select2({placeholder: SCTEXT('Select Groups')+'. . . .'});
               $("#grpsel").select2("val"," ");
               $("#contactinput").removeAttr("disabled");
           } 
        });
        
        //for personalize sms click button to add column
        $(document).on("click",".colsbtn",function(){
            var col = $(this).attr('data-colval');
            insertAtCaret('text_sms_content','#'+col+'#');
            $("#text_sms_content").trigger("keyup");
        })
        
        //rtl to ltr after unicode uncheck
        $("#unicodesms").on("click",function(){
            if(!$(this).is(":checked")){
                $("#text_sms_content").attr("dir","ltr");
            }
        })
        
        //response
        if($("#pageResp").length>0){
            $('#pageResp').modal({show:true})
        }
        
        //validate and submit campaign
        $("#submitsms").click(function(){
            
            //check if phonebook selected then from and to values are valid
            if($("#syspb").length>0){
                if($("#syspb").is(":checked")){
                    var rfrom = parseInt($("#pbfrom").val());
                    var rto =parseInt($("#pbto").val());
                    
                    if(rfrom > rto){
                        bootbox.alert(SCTEXT('Incorrect range selected for Phonebook option. "FROM" should be a lesser value than "TO" field. Your selected range was:')+' from-'+rfrom+' : to-'+rto);
                        return;
                    }
                }
            }
            
            //check if any upload is in progress
            if($("#uprocess").val()==1){
                bootbox.alert(SCTEXT('File upload is in progress. Kindly wait for upload to finish or Cancel Upload & proceed.'));
                return;
            }
            
            //entered sender id if required
            if($("#routesel option:selected").attr('data-stype')=='2' && $("#senderopn").val()==''){
                bootbox.alert(SCTEXT('Sender ID cannot be blank.'));
                return;
            }
            if($("#routesel option:selected").attr('data-stype')=='0' && !$("#sendersel").val()){
                bootbox.alert(SCTEXT('Please select an approved sender ID.'));
                return;
            }
            
            //if editing scheduled campaign no contacts would be actually present
            if(curpage=='edit_sch_campaign'){
                var dialog = bootbox.dialog({
                                    closeButton: false,
                                    message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes to the campaign')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                                });   
                        dialog.init(function(){
                                $("#stbar").animate({width:"100%"},2000)
                                setTimeout(function(){
                                    $("#sendsms_form").attr('action',app_url+'saveEditScheduledCampaign');
                                    $("#sendsms_form").submit();
                                    }, 100);
                                });
            }else{
                //send or resend campaign
                //at least one contact
                if($("#syspb").length>0 && $("input[name='contact-type']:checked").val()=='pb'){
                    if($("#pbfrom").val()=='' || $("#pbto").val()==''){
                        bootbox.alert(SCTEXT('Please select a phonebook category for SMS recipient.'));
                        return;
                    }
                }else{
                    if($("#contactinput").val()=='' && !$("#grpsel").val() && $("#ufilecno").val()=='0'){
                        bootbox.alert(SCTEXT('Please enter at least one field for SMS recipient.'));
                        return;
                    }
                }
                
                
                if(rangeErr==1){
                    bootbox.alert(SCTEXT('Please enter contact range from Phonebook.'));
                    return;
                }
                

                 var dialog = bootbox.dialog({
                                    closeButton: false,
                                    message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Processing SMS . . .<br>This may take few minutes for personalized SMS or large campaign.')}</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                                });   
                        dialog.init(function(){
                                $("#stbar").animate({width:"100%"},2000)
                                setTimeout(function(){
                                    $("#sendsms_form").attr('action',app_url+'processCampaign');
                                    $("#sendsms_form").submit();
                                    }, 100);
                                });
            }
            
            
            
            
        });
        
        
        
        //count contacts when column changes
        $("body").on("change","#xlcol",function(){
	       $sheet = $("#xlsheet option:selected").val();
	       var file = $("input.uploadedFile").val();
           var coln = $(this).val();
           $.ajax({
					type: 'post',
				    dataType: 'json',
				    url: app_url+'getSheetnColumns',
				    data: {
				            file: file,
				            mode: 'colcount',
				            sheet : $sheet,
                            col : coln
				          },
				    success: function(res){
                        var data = res;
				        
				        //append strings to proper select boxed
						
						$("#ufilecno").val(parseInt(data.totalrows));	
                        
                        //count contacts
                        calcContacts();
                    }	
				});
	    });
        
        //load columns when sheet changed
        $("body").on("change","#xlsheet",function(){
	       $sheet = $(this).val();
	       var file = $("input.uploadedFile").val();
		   $("#xlcol").attr('disabled','disabled');
            
           $.ajax({
					type: 'post',
				    dataType: 'json',
				    url: app_url+'getSheetnColumns',
				    data: {
				            file: file,
				            mode: 'columns',
				            sheet : $sheet
				          },
				    success: function(res){
                        var data = res;
				        $cols = data.cols;
									
				        $cols_str='';	
                        $cols_btns = '';
				        for(var j in $cols){
								if($cols[j]!=null && $cols[j]!=''){
								    $cols_str += '<option value="'+j+'">'+$cols[j]+'</option>';
                                    $cols_btns += '<button data-colval="'+j+'" type="button" class="colsbtn btn btn-sm btn-default">'+$cols[j]+'</button>';
								}
				        }
				        //append strings to proper select boxed
									
				        $("#xlcol").html($cols_str).attr('disabled',false);
						$("#ufilecno").val(parseInt(data.totalrows));	
                        $("#xlcolbtns").html($cols_btns);
                        //count contacts
                        calcContacts();
                    }	
				});
	    });
        
        
        //sms preview
        $("#smsprev").click(function(){
		 
			$type = $("input[name='smstype']:checked").val();
			
            if($type=='text'){
                if($("#dynsms").is(':checked')){
						//send a GET request and pass sms text and excel filename
						$.ajax({
                            type: 'post',
							url: app_url+'genDynamicPreview',
							data: {
								sms: $("#text_sms_content").val(),
								filename: $('[name="uploadedFiles[]"]').attr('id'),
                                xlsheet: $("#xlsheet option:selected").val(),
                                xlcol: $("#xlcol option:selected").val(),
                                selgrp: $("#grpsel option:selected").val()
								},
							success: function(res){
								$("#preview_text").html(nl2br(res));
								}	
							});
						}else{
                            $("#preview_text").html(nl2br($("#text_sms_content").val()));
                        }
       			
			}else if($type=='wap'){
				
				$wpttl = $("#wap_sms_title").val();
				$wpurl = $("#wap_sms_url").val();
				$txt = $wpttl+'<br>'+'<a href="'+$wpurl+'" target="_blank">'+$wpurl+'</a>';
				$("#preview_text").html($txt);
				
				}else if($type=='vcard'){
					$("#preview_text").html('['+SCTEXT('No Preview Available')+']');
				}
	
                $('#smspreview').modal({show:true})
			});
        
        
        //use template
        $(document).on("click",".useTempBtn",function(){
            var tmpText = $(this).attr('data-template');
            $("#text_sms_content").val(tmpText).trigger("keyup");
        })
        
        //use tiny url
        $(document).on("click",".useTurlBtn",function(){
            var turl = $(this).attr('data-turl');
            insertAtCaret('text_sms_content','http://'+turl);
            $("#text_sms_content").trigger("keyup");
            if($(this).attr("data-track")=='1'){
                bootbox.alert(SCTEXT("Please make sure <b>Personalized</b> box is checked. Click Tracking is available only for Personalized SMS."));
            }
        })
        
        
        //count credits 
        $(document).on("keyup blur","#text_sms_content", function(){
            var content = $(this).val();
            var clen = content.length; 
            var totalspclchargroups = Object.keys(crecountrule.special).length;
            
            var totaloccurences = 0;
            var totalspcladd = 0;
            //check special characters 
            for(var i=1;i<=totalspclchargroups;i++){
                if(i>1){
                    //it means according to this credit count rule, there are some special characters which will be counted as more than 1 character
                    var spclchars = crecountrule.special[i].join().replace(/,/g,"").replace(/clb/g,"]").replace(/\\/g, '\\\\');
                    
                    //check out occurences
                    var ptrn = new RegExp(`[${spclchars}]`, "g");
                    var matches = content.match(ptrn);
                    var occurrences = matches==null ? 0 : matches.length;
                    
                    totaloccurences += occurrences;
                    totalspcladd += occurrences*i;
                    
                }
            }
            
            var totallength = (clen-totaloccurences)+totalspcladd;
            
            //check how many sms count based on sms type
            var smscount = 1;
            if($("#unicodesms").is(':checked')){
                //unicode sms count
                
               for(var j=1;j<=5;j++){
                    if(totallength>=crecountrule.unicode[j].from && totallength<=crecountrule.unicode[j].to){
                        //matched
                        smscount = j;
                        break;
                    }
                }
                //check if sms count was higher than the range
                if(totallength>crecountrule.unicode[5].to){
                    //simply calculate the per sms factor
                    var persms = Math.ceil(crecountrule.unicode[5].to/5);
                    smscount = Math.ceil(totallength/persms);
                }
                
            }else{
                //normal sms count
                
                for(var j=1;j<=5;j++){
                    if(totallength>=crecountrule.normal[j].from && totallength<=crecountrule.normal[j].to){
                        //matched
                        smscount = j;
                        break;
                    }
                }
                //check if sms count was higher than the range
                if(totallength>crecountrule.normal[5].to){
                    //simply calculate the per sms factor
                    var persms = Math.ceil(crecountrule.normal[5].to/5);
                    smscount = Math.ceil(totallength/persms);
                }
            }
            
            //populate fields
            //if Doo::conf()->credit_counter_dir=='h2l'?1000-totallength:totallength
            $("#txtleft").val(totallength);
            $("#txtcount").val(smscount);
            
            //calculate credits required 
            calcContacts();
        });
        
        
        //transliteration
        google.setOnLoadCallback(onLoad);
        
        //display sms content box based on sms type switch 
        $("input[name='smstype']").click(function(){
            var ele = $(this);
            if(ele.val()=='text'){
               $("#stype-subopts").show("slide", { direction: "left" }, 400,function(){
                   //show text box
                   $("#sms_content_box").removeClass('hidden');
                   $("#wap_content_box").addClass('hidden');
                   $("#vcard_content_box").addClass('hidden');
               });
                
            }else{
               $("#stype-subopts").hide("slide", { direction: "left" }, 400, function(){
                   if(ele.val()=='wap'){
                        //show wap box
                       $("#sms_content_box").addClass('hidden');
                       $("#wap_content_box").removeClass('hidden');
                       $("#vcard_content_box").addClass('hidden');
                    }else if(ele.val()=='vcard'){
                        //show vcard box
                        $("#sms_content_box").addClass('hidden');
                       $("#wap_content_box").addClass('hidden');
                       $("#vcard_content_box").removeClass('hidden');
                        
                    }
               });
                
            } 
            calcContacts();
            
        });
        
        //count contacts and total sms every time user
        
            //a. enters mobile number in text field
                $("#contactinput").on("blur",function(){
                    calcContacts();
                })
            
            //b. choses contact groups
                $("#grpsel").on("change",function(){
                    if($("#dynsms").is(':checked')){
                        var colstrenc = $("#grpsel option:selected").attr("data-colstr");
                        $("#xlcolbtns").html(atob(colstrenc));
                    }
                    
                    calcContacts();
                })
            //c. uploads a file
                //done on callback
        
            //d. changes sms type
                //done on click event
                
            //e. changes sms text
                //done on keyup
        
        //based on route switch show
        $("#routesel").on("change",function(){
            var rtele = $("#routesel option:selected");
            //a. available credits
            $("#rtavcr").html(formatInt(parseInt(rtele.attr('data-acr'))));
            
            //b. status and active time message if current time falls in the active time for route
            var actdata = JSON.parse(rtele.attr('data-actspan'));
            
            if(actdata['type']=='0'){
                //route is active all the time
                var statushtml = `<span class="label label-success"><i class="fa fa-lg fa-check-circle"></i> &nbsp; ${SCTEXT('active')}</span><i id="rtstatusexp" class="m-l-xs fa fa-lg fa-info-circle" data-trigger="hover" data-content="<span class='text-dark'>${SCTEXT('This Route accepts SMS 24x7. SMS submission is allowed.')}</span>"></i>`;
                $("#rtstatus").html(statushtml);
                $("#rtstatusexp").popover({html:true, placement: 'top'});
                
                //initialize datepicker
                $("#schdp").datetimepicker({ minDate: moment(), showClose: true, icons: { close: 'dpclose m-t-xs m-b-xs label-info label label-flat label-md'}, sideBySide: true, toolbarPlacement: 'bottom' });
                //set timezone
                $("#timezone option").each(function(){
					if( $(this).val()==actdata['timezone']){
					$(this).attr('selected','selected');	
					}
					});
                $("#timezone").trigger("change.select2");
                
            }else{
                //route is active during selected time period
                var nowhr = moment().tz(actdata['timezone']);
                var actfhr = moment(actdata['from'],'H:mm').tz(actdata['timezone']);
                var actthr = moment(actdata['to'],'H:mm').tz(actdata['timezone']);

                if(nowhr.isBetween(actfhr, actthr)){
                    //sms submission allowed
                     var statushtml = `<span class="label label-success"><i class="fa fa-lg fa-check-circle"></i> &nbsp; ${SCTEXT('active')}</span><i id="rtstatusexp" class="m-l-xs fa fa-lg fa-info-circle" data-trigger="hover" data-content="<span class='text-dark'>${SCTEXT('This Route accepts SMS between')} ${actdata['from']} & ${actdata['to']} Hrs (${actdata['timezone']} time). ${SCTEXT('SMS submission is allowed.')}</span>"></i>`;
                }else{
                    //sms submission not allowed
                    var statushtml = `<span class="label label-danger"><i class="fa fa-lg fa-times-circle"></i> &nbsp; ${SCTEXT('inactive')}</span><i id="rtstatusexp" class="m-l-xs fa fa-lg fa-info-circle" data-trigger="hover" data-content="<span class='text-dark'>${SCTEXT('This Route accepts SMS between')} ${actdata['from']} & ${actdata['to']} Hrs (${actdata['timezone']} time). ${SCTEXT('SMS submission is currently not allowed.')}</span>"></i>`;
                }
                
                $("#rtstatus").html(statushtml);
                $("#rtstatusexp").popover({html:true, placement: 'top'});
                
                //c. set timezone for scheduling and limit schedule time to select within active time
                
                
                var list = [];
                for (var i = parseInt(actdata['from']); i < parseInt(actdata['to']); i++) {
                    list.push(i);
                }
                if($("#schdp").data("DateTimePicker")) $("#schdp").data("DateTimePicker").destroy();
                $("#schdp").datetimepicker({ minDate: moment(), showClose: true, icons: { close: 'dpclose m-t-xs m-b-xs label-info label label-flat label-md'}, sideBySide: true, toolbarPlacement: 'bottom', enabledHours: list });
                
                $("#timezone option").each(function(){
					if( $(this).val()==actdata['timezone']){
					$(this).attr('selected','selected');	
					}
					});
                $("#timezone").trigger("change.select2");
                
                
            }
            
            //d. sender id box type, default sender id and max allowed length
                var stype = parseInt(rtele.attr('data-stype'));
                if(stype==0){
                    //approval based sender id
                    $("#sidselbox").removeClass('hidden');
                    $("#sidopnbox").addClass('hidden');
                }
                if(stype==1){
                    //sender id not allowed
                    $("#sidselbox").addClass('hidden');
                    $("#sidopnbox").addClass('hidden');
                }
                if(stype==2){
                    //open sender id allowed
                    $("#sidselbox").addClass('hidden');
                    $("#sidopnbox").removeClass('hidden');
                }
            
            //e. credit count rule display
            $.ajax({
               url:app_url+'getCreditCountRuleDetails/'+rtele.attr('data-crule'),
                success: function(res){
                    var respar = JSON.parse(res);
                    crecountrule = { normal : respar.text, unicode : respar.unicode, special : respar.special };
                    
                    $("#ccruledata").attr("data-content",respar.html).popover({animation:false,placement:'left',html:true, trigger:'hover'});
                }    
            });

        });

        //campaign selection 
        if($("#account_type").val()=='0'){
            $("#campsel").on("change",function(){
                var cmpele = $("#campsel option:selected");
                $("#campaignid").val(cmpele.val());
                var defrt = cmpele.attr('data-defroute');
                if(defrt!=0 && defrt!=''){
                    //select the set route
                    $('#routesel').val(defrt).change()
                }else{
                    $('#routesel').trigger("change");
                }
                
            })
        $("#campsel").trigger("change");
        }else{
            $("#campsel").on("change",function(){
                var cmpele = $("#campsel option:selected");
                $("#campaignid").val(cmpele.val());
            })
            $("#campsel").trigger("change");
            var rtele = $("#mccdefroute");
            //a. available credits
            //none for currency based
            
            //b. status and active time message if current time falls in the active time for route
            var actdata = JSON.parse(rtele.attr('data-actspan'));
            
            if(actdata['type']=='0'){
                //route is active all the time
                var statushtml = `<span class="label label-success"><i class="fa fa-lg fa-check-circle"></i> &nbsp; ${SCTEXT('active')}</span><i id="rtstatusexp" class="m-l-xs fa fa-lg fa-info-circle" data-trigger="hover" data-content="<span class='text-dark'>${SCTEXT('This Route accepts SMS 24x7. SMS submission is allowed.')}</span>"></i>`;
                $("#rtstatus").html(statushtml);
                $("#rtstatusexp").popover({html:true, placement: 'top'});
                
                //initialize datepicker
                $("#schdp").datetimepicker({ minDate: moment(), showClose: true, icons: { close: 'dpclose m-t-xs m-b-xs label-info label label-flat label-md'}, sideBySide: true, toolbarPlacement: 'bottom' });
                //set timezone
                $("#timezone option").each(function(){
					if( $(this).val()==actdata['timezone']){
					$(this).attr('selected','selected');	
					}
					});
                $("#timezone").trigger("change.select2");
                
            }else{
                //route is active during selected time period
                var nowhr = moment().tz(actdata['timezone']);
                var actfhr = moment(actdata['from'],'H:mm').tz(actdata['timezone']);
                var actthr = moment(actdata['to'],'H:mm').tz(actdata['timezone']);

                if(nowhr.isBetween(actfhr, actthr)){
                    //sms submission allowed
                     var statushtml = `<span class="label label-success"><i class="fa fa-lg fa-check-circle"></i> &nbsp; ${SCTEXT('active')}</span><i id="rtstatusexp" class="m-l-xs fa fa-lg fa-info-circle" data-trigger="hover" data-content="<span class='text-dark'>${SCTEXT('This Route accepts SMS between')} ${actdata['from']} & ${actdata['to']} Hrs (${actdata['timezone']} time). ${SCTEXT('SMS submission is allowed.')}</span>"></i>`;
                }else{
                    //sms submission not allowed
                    var statushtml = `<span class="label label-danger"><i class="fa fa-lg fa-times-circle"></i> &nbsp; ${SCTEXT('inactive')}</span><i id="rtstatusexp" class="m-l-xs fa fa-lg fa-info-circle" data-trigger="hover" data-content="<span class='text-dark'>${SCTEXT('This Route accepts SMS between')} ${actdata['from']} & ${actdata['to']} Hrs (${actdata['timezone']} time). ${SCTEXT('SMS submission is currently not allowed.')}</span>"></i>`;
                }
                
                $("#rtstatus").html(statushtml);
                $("#rtstatusexp").popover({html:true, placement: 'top'});
                
                //c. set timezone for scheduling and limit schedule time to select within active time
                
                
                var list = [];
                for (var i = parseInt(actdata['from']); i < parseInt(actdata['to']); i++) {
                    list.push(i);
                }
                if($("#schdp").data("DateTimePicker")) $("#schdp").data("DateTimePicker").destroy();
                $("#schdp").datetimepicker({ minDate: moment(), showClose: true, icons: { close: 'dpclose m-t-xs m-b-xs label-info label label-flat label-md'}, sideBySide: true, toolbarPlacement: 'bottom', enabledHours: list });
                
                $("#timezone option").each(function(){
					if( $(this).val()==actdata['timezone']){
					$(this).attr('selected','selected');	
					}
					});
                $("#timezone").trigger("change.select2");
                
                
            }
            
            //d. sender id box type, default sender id and max allowed length
                var stype = parseInt(rtele.attr('data-stype'));
                if(stype==0){
                    //approval based sender id
                    $("#sidselbox").removeClass('hidden');
                    $("#sidopnbox").addClass('hidden');
                }
                if(stype==1){
                    //sender id not allowed
                    $("#sidselbox").addClass('hidden');
                    $("#sidopnbox").addClass('hidden');
                }
                if(stype==2){
                    //open sender id allowed
                    $("#sidselbox").addClass('hidden');
                    $("#sidopnbox").removeClass('hidden');
                }
            
            //e. credit count rule display
            $.ajax({
               url:app_url+'getCreditCountRuleDetails/'+rtele.attr('data-crule'),
                success: function(res){
                    var respar = JSON.parse(res);
                    crecountrule = { normal : respar.text, unicode : respar.unicode, special : respar.special };
                    
                    $("#ccruledata").attr("data-content",respar.html).popover({animation:false,placement:'left',html:true, trigger:'hover'});
                }    
            });
        }
        
        
        
        //datepicker close
         $("#schdp").on("dp.show", function(e) {
            $('.dpclose').html("<i class='fa fa-lg fa-check'></i>&nbsp;&nbsp;Done");
          });
        //toggle schedule
        $("#slater, #snow, #sbatch").on("click",function(){
           if($(this).val()=='1'){
            $("#sbbox").hide("slide", { direction: "left" }, 600, ()=>{
                $("#schbox").show("slide", { direction: "left" }, 600);
               });
           }
           if($(this).val()=='2'){
               $("#schbox").hide("slide", { direction: "left" }, 600, ()=>{
                $("#sbbox").show("slide", { direction: "left" }, 600);
               });
           } 
           if($(this).val()=='0'){
            $("#schbox").hide("slide", { direction: "left" }, 600, ()=>{
             $("#sbbox").hide("slide", { direction: "left" }, 600);
            });
        } 
        });
        
           
         
        
        if(curpage=='resend_campaign'){
            
            //show sms type
            var ele = $("input[name='smstype']:checked");
            if(ele.val()=='text'){
               $("#stype-subopts").show("slide", { direction: "left" }, 400,function(){
                   //show text box
                   $("#sms_content_box").removeClass('hidden');
                   $("#wap_content_box").addClass('hidden');
                   $("#vcard_content_box").addClass('hidden');
               });
                
            }else{
               $("#stype-subopts").hide("slide", { direction: "left" }, 400, function(){
                   if(ele.val()=='wap'){
                        //show wap box
                       $("#sms_content_box").addClass('hidden');
                       $("#wap_content_box").removeClass('hidden');
                       $("#vcard_content_box").addClass('hidden');
                    }else if(ele.val()=='vcard'){
                        //show vcard box
                        $("#sms_content_box").addClass('hidden');
                       $("#wap_content_box").addClass('hidden');
                       $("#vcard_content_box").removeClass('hidden');
                        
                    }
               });
                
            } 
            
            //count sms char and credits required
            $(document).ajaxStop(function() {
              // code to be executed on completion of last outstanding ajax call here
                $("#text_sms_content").trigger("keyup");
            });
            
            
            
        }
        
        if(curpage=='edit_sch_campaign'){
             //count sms char and credits required
            $(document).ajaxStop(function() {
              // code to be executed on completion of last outstanding ajax call here
                $("#text_sms_content").trigger("keyup");
                $("#schdp").val($("#orgschdate").val());
                
                $("#timezone option").each(function(){
					if( $(this).val()==$("#orgschtz").val()){
					$(this).attr('selected','selected');	
					}
					});
                $("#timezone").trigger("change.select2");
            });
            
            
            
        }

        
        
    }
    
    
    

//22. Transaction reports
    
    if(curpage=='transactions' || curpage=='va_tran_history'){
        
        //top sales
        $('#transdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#transdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload table
            $('#dt_utrans').dataTable().api().ajax.url(app_url+"getMyTransactions/"+$('#transdp span').html()+'/'+$("#userid").val()).load();
            
        });
        //Set the initial state of the picker label
         $('#transdp span').html('Select Date');
        
    }
        
    
//23. View DLR
    
     if(curpage=='dlr' || curpage=='va_sentsms'){

        $("#campsel").on("change",function(){
            $('#t-dlrsum').dataTable().api().ajax.url(app_url+"getMySmsCampaigns/"+$("#campsel").val()+'/'+$('#dlrdp span').html()+"/"+$("#userid").val()).load();
        })
        
        //date pkr dlr
        $('#dlrdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#dlrdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
            //reload table
            var campaignid = $("#campsel").val() || 0;
            $('#t-dlrsum').dataTable().api().ajax.url(app_url+"getMySmsCampaigns/"+campaignid+'/'+$('#dlrdp span').html()+"/"+$("#userid").val()).load();
            
        });
        //Set the initial state of the picker label
         $('#dlrdp span').html('Select Date');
         
         
         //get dlr summary
         $('body').on('click','.dlrsumldr',function(){
                 var ele = $(this);
                var pbox = ele.next().find(".popover-content");
                var arele = ele.next().find(".arrow");
                 $.ajax({
                     url: app_url+'getDlrSummary/'+$("#userid").val(),
                     data:{
                         shootid: ele.attr('data-shootid'),
                         routeid: ele.attr('data-routeid'),
                         mode: 'popover'
                     },
                     success: function(res){
                        arele.css('top','20px');
                       pbox.html(res);
                     }
                 });
        });
         
        $('body').on("click",".closePO",function(){
            $(".dlrsumldr").popover("hide");
        });
         
        
    }
    
     if(curpage=='dlr_details' || curpage=='va_dlrdetails'){
         
        //admin summary
        if($("#adminsummary").length>0){
            $("#adminsummary").on("click",function(){
                $("#adminsumctr").html(`<i class="fa-circle-o-notch fa fa-lg m-r-xs fa-spin"></i> <b>${SCTEXT('Loading')}...</b>`);
                $.ajax({
                    url:app_url+'getAdminSmsSummary/'+$("#shootid").val(),
                     success: function(res){
                         $("#adminsumctr").html(res);
                     }    
                 });
            })
        }

         //fetch dlr summary
         $.ajax({
             url: app_url+'getDlrSummary/'+$("#userid").val(),
             data:{
                 shootid: $("#shootid").val(),
                 routeid: $("#routeid").val()
             },
             success: function(res){
               $('#dlrsumctr').html(res);  
             }
         })
         
     }
    
//24. doc manager    
    if(curpage=='docs'){
        
        //delete docs
        $("#app-main").on("click",".deleteDoc",function(){
            var ele = $(this);
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this file? All comments/remarks will be deleted and no user will be able to access this file. Proceed anyway?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'deleteDocument/'+ele.attr('data-docid'),
                                success: function(res){
                                    window.location = app_url+'manageDocs';
                                }
                            })
                            }
                        }
                    }); 
        })
        
        //date picker
         
            $('#docmgrdp').daterangepicker({
                    ranges: {
                        'Today': ['today', 'today'],
                        'Yesterday': ['yesterday', 'yesterday'],
                        'Last 7 Days': [Date.today().add({
                            days: -6
                        }), 'today'],
                        'Last 30 Days': [Date.today().add({
                            days: -29
                        }), 'today'],
                        'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                        'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                            months: -1
                        }), Date.today().moveToFirstDayOfMonth().add({
                            days: -1
                        })]
                    },
                    opens: 'left',
                    format: 'MM/dd/yyyy',
                    separator: ' to ',
                    startDate: Date.today().add({
                        days: -29
                    }),
                    endDate: Date.today(),
                    minDate: '01/01/2012',
                    maxDate: '12/31/2020',
                    locale: {
                        applyLabel: 'Apply',
                        clearLabel: 'Cancel',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                        firstDay: 1
                    },
                    showWeekNumbers: true,
                    buttonClasses: ['btn-danger']
                },
                function (start, end) {
                    $('#docmgrdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
                    //reload invoices
                      $.ajax({
                        type: 'GET',
                        url: app_url+'getUserDocs/1/'+$('#docmgrdp span').html(),
                        success: function(res){
                            var mydata = JSON.parse(res);
                            $("#inv-file-ctr").fadeOut(function(){
                                $(this).html(mydata.str).fadeIn(function(){
                                    if(mydata.more==1 && mydata.rows==10){
                                    $("#more_docinv").removeClass('hidden').attr('data-custom','10,10').html(SCTEXT('Show More')+' ...');
                                    }else{
                                         $("#more_docinv").addClass('hidden');
                                    }
                                    $("#inv-file-ctr").find(".pop-over").each(function(){
                                        $(this).popover({html: true});
                                    });
                                });
                            });
                        }
                        });
                //reload agreements
                        $.ajax({
                            type: 'GET',
                            url: app_url+'getUserDocs/2/'+$('#docmgrdp span').html(),
                            success: function(res){
                                var mydata = JSON.parse(res);
                                $("#apl-file-ctr").fadeOut(function(){
                                    $(this).html(mydata.str).fadeIn(function(){
                                        if(mydata.more==1 && mydata.rows==10){
                                        $("#more_docapl").removeClass('hidden').attr('data-custom','10,10').html(SCTEXT('Show More')+' ...');
                                        }else{
                                             $("#more_docapl").addClass('hidden');
                                        }
                                    });
                                     $("#apl-file-ctr").find(".pop-over").each(function(){
                                            $(this).popover({html: true});
                                     });
                                });


                            }
                            });
                //reload other docs
                        $.ajax({
                            type: 'GET',
                            url: app_url+'getUserDocs/3/'+$('#docmgrdp span').html(),
                            success: function(res){
                                var mydata = JSON.parse(res);
                                $("#oth-file-ctr").fadeOut(function(){
                                    $(this).html(mydata.str).fadeIn(function(){
                                        if(mydata.more==1 && mydata.rows==10){
                                        $("#more_docoth").removeClass('hidden').attr('data-custom','10,10').html(SCTEXT('Show More ')+'...');
                                        }else{
                                             $("#more_docoth").addClass('hidden');
                                        }
                                    });
                                     $("#oth-file-ctr").find(".pop-over").each(function(){
                                            $(this).popover({html: true});
                                     });
                                });


                            }
                            });
                });
                //Set the initial state of the picker label
                $('#docmgrdp span').html('Select Date');
                //----------------//
	
        
        // load invoices
        $.ajax({
		type: 'GET',
		url: app_url+'getUserDocs/1/'+$('#docmgrdp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
			$("#inv-file-ctr").fadeOut(function(){
                $(this).html(mydata.str).fadeIn(function(){
                    if(mydata.more==1 && mydata.rows==10){
                    $("#more_docinv").removeClass('hidden').attr('data-custom','10,10');
                    }else{
                         $("#more_docinv").addClass('hidden');
                    }
                });
                 $("#inv-file-ctr").find(".pop-over").each(function(){
                        $(this).popover({html: true});
                 });
            });
           
            
        }
		});
// show more invoices
        $('#more_docinv').on("click",function(){
            $limit = $(this).attr('data-custom');
            if($limit!='0,10'){
                //check to make sure all data isnnot loaded
            $(this).attr('disabled','disabled').html(SCTEXT('loading')+'....');
            $.ajax({
                type: 'GET',
                url: app_url+'getUserDocs/1/'+$('#docmgrdp span').html()+'/'+$limit,
                success: function(res){
                    var mydata = JSON.parse(res);
                    if(mydata.more==1){
                    $("#inv-file-ctr").append(mydata.str);
                    $('html, body').animate({
                        scrollTop: $('#inv-file-ctr').height()}, 500, function(){
                        $('#more_docinv').html(SCTEXT('Show More')+' ...').attr({"disabled":false,"data-custom":mydata.limit});
                        $("#inv-file-ctr").find(".pop-over").each(function(){
                            $(this).popover({html: true});
                        });
                    });
                       
                    }else{
                        
                        $('#more_docinv').html(SCTEXT('All loaded')).attr({"disabled":false,"data-custom":mydata.limit}); 
                    }
                }
            });
            }
        });        

        
        
      // load agreements
        $.ajax({
		type: 'GET',
		url: app_url+'getUserDocs/2/'+$('#docmgrdp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
			$("#apl-file-ctr").fadeOut(function(){
                $(this).html(mydata.str).fadeIn(function(){
                    if(mydata.more==1 && mydata.rows==10){
                    $("#more_docapl").removeClass('hidden').attr('data-custom','10,10');
                    }else{
                         $("#more_docapl").addClass('hidden');
                    }
                });
                 $("#apl-file-ctr").find(".pop-over").each(function(){
                        $(this).popover({html: true});
                 });
            });
           
            
        }
		});
// show more agreements
        $('#more_docapl').on("click",function(){
            $limit = $(this).attr('data-custom');
            if($limit!='0,10'){
                //check to make sure all data isnnot loaded
            $(this).attr('disabled','disabled').html(SCTEXT('loading')+'....');
            $.ajax({
                type: 'GET',
                url: app_url+'getUserDocs/2/'+$('#docmgrdp span').html()+'/'+$limit,
                success: function(res){
                    var mydata = JSON.parse(res);
                    if(mydata.more==1){
                    $("#apl-file-ctr").append(mydata.str);
                    $('html, body').animate({
                        scrollTop: $('#apl-file-ctr').height()}, 500, function(){
                        $('#more_docapl').html(SCTEXT('Show More')+' ...').attr({"disabled":false,"data-custom":mydata.limit});
                        $("#apl-file-ctr").find(".pop-over").each(function(){
                            $(this).popover({html: true});
                        });
                    });
                       
                    }else{
                        
                        $('#more_docapl').html(SCTEXT('All loaded')).attr({"disabled":false,"data-custom":mydata.limit}); 
                    }
                }
            });
            }
        });        
        
        
      // load other docs
        $.ajax({
		type: 'GET',
		url: app_url+'getUserDocs/3/'+$('#docmgrdp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
			$("#oth-file-ctr").fadeOut(function(){
                $(this).html(mydata.str).fadeIn(function(){
                    if(mydata.more==1 && mydata.rows==10){
                    $("#more_docoth").removeClass('hidden').attr('data-custom','10,10');
                    }else{
                         $("#more_docoth").addClass('hidden');
                    }
                });
                 $("#oth-file-ctr").find(".pop-over").each(function(){
                        $(this).popover({html: true});
                 });
            });
           
            
        }
		});
// show more other docs
        $('#more_docoth').on("click",function(){
            $limit = $(this).attr('data-custom');
            if($limit!='0,10'){
                //check to make sure all data isnnot loaded
            $(this).attr('disabled','disabled').html(SCTEXT('loading')+'....');
            $.ajax({
                type: 'GET',
                url: app_url+'getUserDocs/3/'+$('#docmgrdp span').html()+'/'+$limit,
                success: function(res){
                    var mydata = JSON.parse(res);
                    if(mydata.more==1){
                    $("#oth-file-ctr").append(mydata.str);
                    $('html, body').animate({
                        scrollTop: $('#oth-file-ctr').height()}, 500, function(){
                        $('#more_docoth').html(SCTEXT('Show More')+' ...').attr({"disabled":false,"data-custom":mydata.limit});
                        $("#oth-file-ctr").find(".pop-over").each(function(){
                            $(this).popover({html: true});
                        });
                    });
                       
                    }else{
                        
                        $('#more_docoth').html(SCTEXT('All loaded')).attr({"disabled":false,"data-custom":mydata.limit}); 
                    }
                }
            });
            }
        });        
        
        

        //show open folder icon
        $(".docnav").on("click",function(){
            var ele = $(this);
            if($(this).parent().attr('class')==''){
                $(".docnav").each(function(){
                    $(this).find('i').attr('class','fa fa-lg fa-folder m-r-xs');
                });
                ele.find('i').attr('class','fa fa-lg fa-folder-open m-r-xs');
            }
        });
    }
    
    
    if(curpage=='add_doc'){
        
        //submit
         $("#save_changes").click(function(){
            
            if($("#docname").val()==''){
                bootbox.alert(SCTEXT('Please enter a title for the document'));
                return;
            }
            
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Uploading Document')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},200)
                            setTimeout(function(){
                                $("#udoc_form").attr('action',app_url+'saveDocument');
                                $("#udoc_form").submit();
                                }, 100);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageDocs';
        });
        
    }
    
    
    if(curpage=='view_doc'){
        
        //agreement doc
        $(".agraction").on("click", function(){
            var ele = $(this);
            var msg = ele.attr('data-action')=='1'?SCTEXT('Are you sure you want to approve this agreement?'):SCTEXT('Are you sure you want to decline this agreement?');
            bootbox.confirm({
                    message: msg,
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //ajax call 
                            $.ajax({
                                type: 'post',
                                url: app_url+'markAgreementStatus',
                                data: {
                                  action :   ele.attr("data-action"),
                                    docid: ele.attr("data-docid")
                                },
                                success: function(res){
                                     window.location.reload(false);
                                }
                            })
                            }
                        }
                    });
        });
        
        
        //invoice actions
        $(".invaction").on("click", function(){
            var ele = $(this);
            var msg = ele.attr('data-action')=='1'?SCTEXT('Please make sure you have received the payment and enter transaction details as a comment below. Are you sure you want to mark this invoice as PAID?'):SCTEXT('Are you sure you want to cancel this invoice?');
            bootbox.confirm({
                    message: msg,
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //ajax call 
                            $.ajax({
                                type: 'post',
                                url: app_url+'markInvoiceStatus',
                                data: {
                                  action :   ele.attr("data-action"),
                                    docid: ele.attr("data-docid")
                                },
                                success: function(res){
                                     window.location.reload(false);
                                }
                            })
                            }
                        }
                    });
        });
        
        //print invoice
        $("#docinvprint").on("click", function(){
            $('#invoiceBox').printThis();
        });
        
        //scroll content of chats to bottom
        $('#docremk').animate({scrollTop: $('#docremk').prop("scrollHeight")}, 500);
        
        //post comment
        $("#submitCmt").click(function(){
           //validate
            if($('#doc_comment').val()==''){
                bootbox.alert(SCTEXT('Your comment cannot be blank'));
                return;
            }
            //post
            $(this).attr('disabled','disabled').html(SCTEXT('Submitting')+' ...');
            $("#cmt_form").attr('action',app_url+'postFileComment');
            $("#cmt_form").submit();
            
        });
        
        //share doc
        if($('#sharedoc').length>0){
            $('#sharedoc').on("click",function(){
                //collect values
                
                //show popup
                $("#shareusrbox").modal({show: true});
                
                
            });
            
            $("#submitShare").on("click", function(){
               if($("#sharedusr").val()==''){
                   bootbox.alert(SCTEXT('Please select at least one user'));
                   return;
               }
                
                $(this).attr('disabled','disabled').html(SCTEXT('Submitting')+' ...');
                $("#shareform").attr('action',app_url+'postSharedUsers');
                $("#shareform").submit();
                    
                
            });
            
        }
        
        //undo sharing
        $(".remshare").on("click", function(){
           var ele = $(this);
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to remove this user from shared list?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'rmvSharedUsr',
                                method: 'post',
                                data: {
                                    uid: ele.attr('data-uid'),
                                    docid: ele.attr('data-docid')
                                },
                                success: function(res){
                                    window.location=app_url+'viewDocument/'+ele.attr('data-docid');
                                }
                            })
                            }
                        }
                    }); 
        });
        
        
        //re-upload document
        $("#docreupload").on("click", function(){
            //show popup
                $("#reupbox").modal({show: true});
        });
        $("#submitReup").on("click", function(){
               if($(".uploadedFile").length==0){
                   bootbox.alert(SCTEXT('Please upload a file.'));
                   return;
               }
                
                $(this).attr('disabled','disabled').html(SCTEXT('Submitting')+' ...');
                $("#reuploadform").attr('action',app_url+'documentReupload');
                $("#reuploadform").submit();
                    
                
            });
        
        //delete doc
        $(".deleteDoc").on("click",function(){
            var ele = $(this);
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this file? All comments/remarks will be deleted and no user will be able to access this file. Proceed anyway?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'deleteDocument/'+ele.attr('data-docid'),
                                success: function(res){
                                    window.location=app_url+'manageDocs';
                                }
                            })
                            }
                        }
                    }); 
        })
        
        
        //make payment for invoice
        if($("#docinvpay").length>0){
            $("#docinvpay").on("click", function(){
                    var invid = $(this).attr("data-docid");
                    var dialog = bootbox.dialog({
                        message: $("#paymentopts").html(),
                        buttons: {
                            cancel: {
                                label: SCTEXT("Pay Later")
                            },
                            
                            ok: {
                                label: SCTEXT("Confirm Order"),
                                className: 'btn-primary',
                                callback: function(){
                                    var wflag = $(".modal-body").find("#wbalflag").is(":checked")==true?1:0;
                                    var resobj = {invoiceid:invid, walletflag:wflag, returntoinvoice:1};
                                    
                                    //console.log(serialize(resobj));
                                    window.location = app_url+'confirmPurchaseOrder/'+btoa(serialize(resobj));
                                }
                            }
                        }
                    });
                    // do something in the background
                    dialog.modal('show');
            })
            
             
        }
        
       
        
            $(document).on("change","#wbalflag", function(){
                var wflag = $(this).is(":checked")?1:0;
                $(this).applyWbal(wflag);
                 
            })
        
        
        $.fn.applyWbal = function(e) { 
            var total = $("#gtotal").val();
            var remwal = 0;
            if(e==1){
                
                                    var totalpayable = total<=parseFloat($("#walbal").val())?0:total-parseFloat($("#walbal").val());
                                
                                    $(".modal-body").find("#total_amt_payable").html(totalpayable.toLocaleString());
                                   
                                    remwal = total>=parseFloat($("#walbal").val())?0:($("#walbal").val()-total).toLocaleString();
                                    $(".modal-body").find("#remwal").text(app_currency+remwal);
                
               
                
                                }else{
                                    
                                    //customer does not wanna use wallet credits
                                    var totalpayable = total;
                                    
                                    $(".modal-body").find("#total_amt_payable").html(totalpayable.toLocaleString());
                                    
                                    remwal = $("#walbal").val().toLocaleString();
                                    $(".modal-body").find("#remwal").text(app_currency+remwal);
                                    
                                   
                                    
                                }
            
         }
        
        
    
        
    }
    
    

//25. Support
    
    if(curpage=='support_tickets'){
        $('#tktdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#tktdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload table
            $('#dt_e').dataTable().api().ajax.url(app_url+"getMyTickets/"+$('#tktdp span').html()).load();
            
        });
        //Set the initial state of the picker label
         $('#tktdp span').html('Select Date');
    }
    
    if(curpage=='add_ticket'){
        
        //submit form
        $("#save_changes").click(function(){
            
            if($("#tkttitle").val()==''){
                bootbox.alert(SCTEXT('Please enter the subject/title for the ticket.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Submitting ticket to Support team')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#st_form").attr('action',app_url+'saveSupportTicket');
                                $("#st_form").submit();
                                }, 100);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'supportTickets';
        });
    }
    
    
    if(curpage=='view_ticket'){
        
        //scroll to the bottom of comment box
        $('#docremk').animate({scrollTop: $('#docremk').prop("scrollHeight")}, 500);
        
        //post comment
        $("#submitCmt").click(function(){
           //validate
            if($('#t_comment').val()==''){
                bootbox.alert(SCTEXT('Your comment cannot be blank'));
                return;
            }
            //post
            $(this).attr('disabled','disabled').html(SCTEXT('Submitting')+' ...');
            $("#cmt_form").attr('action',app_url+'postTicketComment');
            $("#cmt_form").submit();
            
        });
    }
    
    

//26. Logs
    
    if(curpage=='refund_log'){
        //datepicker
        $('#rldp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#rldp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload table
            $('#t-reflog').dataTable().api().ajax.url(app_url+"getRefundLog/"+$('#rldp span').html()).load();
            
        });
        //Set the initial state of the picker label
         $('#rldp span').html('Select Date');
    }
    
    if(curpage=='credit_log' || curpage=='va_crelog'){
        //datepicker
        $('#cldp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#cldp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload table
            $('#t-crelog').dataTable().api().ajax.url(app_url+"getCreditLog/"+$('#cldp span').html()+'/'+$("#userid").val()).load();
            
        });
        //Set the initial state of the picker label
         $('#cldp span').html('Select Date');
    }
    
    
    if(curpage=='usms_log'){
        
        //datepicker
        $('#sldp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'right',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#sldp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
            
        });
        //Set the initial state of the picker label
         $('#sldp span').html('Select Date');
        
        
        //search filter
        $("#dt_filter").click(function(){
            //reload table
            $('#t-usmslog').dataTable().api().ajax.url(app_url+"getUserSmsLog/"+$('#sldp span').html()+'/'+$("#sidsel").val()+'/'+$("#rtsel").val()).load();
        });
        
        //download reports
        
    }
    
    
    
//27. API
    
    if(curpage=='hapi' || curpage=='xapi'){
        //regenrate key
        $("body").on("click",".btn",function(){
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to regenerate API Key? Old implementations of the API would not work unless you update newly generated API Key in those. Shall we proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            window.location = app_url+'regAPIKey';
                            }
                        }
                    });  
        });
    }
    

    
//28. SMS Stats    
    
    if(curpage=='stats'){
        //date picker
        $('#stdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#stdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
            //reload traffic summary
            $.ajax({
                url: app_url+'getSmsStatsReport/'+$('#stdp span').html(),
                success: function(res){
                    var mydata = JSON.parse(res);
                    var myChart = echarts.init(document.getElementById('linesum'));
                    var myPie = echarts.init(document.getElementById('piesum'));
                    var loption = {
                        tooltip : {
                                    trigger: 'axis'
                                  },
                                  color: ['#35b8e0','#10c469','#ff5b5b'],
                                  legend: {
                                    data:['Sent','Delivered','Failed']
                                  },
                                  calculable : true,
                                  xAxis : [
                                    {
                                      type : 'category',
                                      data :  mydata.line.dates 
                                    }
                                  ],
                                  yAxis : [
                                    {
                                      type : 'value'
                                    }
                                  ],
                                  series : [
                                    {
                                      name:'Sent',
                                      type:'line',
                                      data: mydata.line.Sent,
                                      markPoint : {
                                        data : [
                                          {type : 'max', name: 'Max'},
                                          {type : 'min', name: 'Min'}
                                        ]
                                      },
                                      markLine : {
                                        data : [
                                          {type : 'average', name: 'Average'}
                                        ]
                                      }
                                    },
                                    {
                                      name:'Delivered',
                                      type:'line',
                                      data: mydata.line.Delivered,
                                      markPoint : {
                                        data : [
                                          {type : 'max', name: 'Max'},
                                          {type : 'min', name: 'Min'}
                                        ]
                                      },
                                      markLine : {
                                        data : [
                                          {type : 'average', name: 'Average'}
                                        ]
                                      }
                                    },                                                       
                                    {
                                      name:'Failed',
                                      type:'line',
                                      data: mydata.line.Failed,
                                      markPoint : {
                                        data : [
                                          {type : 'max', name: 'Max'},
                                          {type : 'min', name: 'Min'}
                                        ]
                                      },
                                      markLine : {
                                        data : [
                                          {type : 'average', name : 'Average'}
                                        ]
                                      }
                                    }
                                  ]
                    };
                    myChart.setOption(loption);
                    
                    var poption = {
                        tooltip : {   trigger: 'item', formatter: '{c} ({d}%)', z:15},
                                    color: ['#35b8e0','#10c469','#ff5b5b'],   
                                    legend: {
                                        orient: 'vertical',
                                        x: 'left',
                                        data: ['Sent','Delivered','Failed']
                                    },
                                    series : [
                                        {
                                            name: 'Access Sources',
                                            type: 'pie',
                                            radius : '55%',
                                            center: ['50%', '60%'],
                                            data:[
                                                {value:mydata.pie.Sent, name:'Sent'},
                                                {value:mydata.pie.Delivered, name:'Delivered'},
                                                {value:mydata.pie.Failed, name:'Failed'}
                                            ],
                                            itemStyle: {
                                                emphasis: {
                                                    shadowBlur: 10,
                                                    shadowOffsetX: 0,
                                                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                                                }
                                            }
                                        }
                                    ]
                    };
                    myPie.setOption(poption);
                }
            });
            
            
        });
        //Set the initial state of the picker label
         $('#stdp span').html(Date.today().add({
            days: -9
        }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
    }
    

//29. SMS Archive
    
    if(curpage=='smsarchive'){
        //datepicker
        $('#sldp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'right',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#sldp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
            $('#chosenDate').val($('#sldp span').html());
        });
        //Set the initial state of the picker label
         $('#sldp span').html('Select Date');
        
        
        //submit search task
        //cancel schedule
         $("body").on("click","#submit_archdt",function(){
             var daterg =  $('#chosenDate').val();
             
             if(daterg=='Select Date'){
                 bootbox.alert(SCTEXT('Please select a valid date to proceed.'));
                 exit; 
             }
             
            bootbox.confirm({
                    message: SCTEXT("System will now fetch records from selected date range. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                                $("#ftadd_frm").attr('action',app_url+'saveArchiveFetchTask');
                                $("#ftadd_frm").submit();
                            }
                        }
                    });  
        });
        
        
        
    }
    
    
    
//30. Scheduled SMS
    
    if(curpage=='scheduled'){
        
        //cancel schedule
         $("body").on("click",".delsch",function(){
             var shootid = $(this).attr('data-shootid');
            bootbox.confirm({
                    message: SCTEXT("This action will cancel your campaign. The credits deducted will be refunded back to your account. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            window.location = app_url+'cancelSchedule/'+shootid;
                            }
                        }
                    });  
        });
        
        
        //datepicker
        $('#dlrdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#dlrdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload table
            $('#t-schtbl').dataTable().api().ajax.url(app_url+"getMyScheduledCampaigns/"+$('#dlrdp span').html()).load();
            
        });
        //Set the initial state of the picker label
         $('#dlrdp span').html('Select Date');
         
         
    }
    
    
    
//31. Reseller Dashboard
    
    if(curpage=='reseller_dashboard'){
        
        
        //sales and signups
        $.ajax({
            url: app_url+'getResellerStats',
            success: function(res){
                var mydata = JSON.parse(res);
                //top four boxes
                $('#weekly_sales_ctr').html(formatInt(mydata.s_total_week));
                $('#monthly_sales_ctr').html(formatInt(mydata.s_total_month));
                $('#weekly_usr_ctr').html(mydata.u_total_week);
                $('#monthly_usr_ctr').html(mydata.u_total_month);

                //weekly small chart
                var arr = [];
                    for (elem in mydata.s_this_week) {
                       arr.push(mydata.s_this_week[elem]);
                    }
                var u_arr = [];
                    for (u_elem in mydata.u_this_week) {
                       u_arr.push(mydata.u_this_week[u_elem]);
                    }
               $("#wk_sales_chart").sparkline(arr,{type: 'bar', barColor: '#ffffff', barWidth: 3, barSpacing: 2});
                $("#wk_usr_chart").sparkline(u_arr,{type: 'bar', barColor: '#ffffff', barWidth: 3, barSpacing: 2});
               //monthly small chart
                 var arr2 = [];
                    for (elem2 in mydata.s_this_month) {
                       arr2.push(mydata.s_this_month[elem2]);
                    }
                var u_arr2 = [];
                    for (u_elem2 in mydata.u_this_month) {
                       u_arr2.push(mydata.u_this_month[u_elem2]);
                    }
                $("#mn_sales_chart").sparkline(arr2,{type: 'bar', barColor: '#ffffff', barWidth: 2, barSpacing: 1.5});
                $("#mn_usr_chart").sparkline(u_arr2,{type: 'bar', barColor: '#ffffff', barWidth: 2, barSpacing: 1.5});

                //chart
                var myChart = echarts.init(document.getElementById('salesgr'));
                    var options = {
                        tooltip : {
                                    trigger: 'axis'
                                  },
                                  color: ['#35b8e0','#f9c851'],
                                  legend: {
                                    data:['Sales','New Users']
                                  },
                                  calculable : true,
                                  xAxis : [
                                    {
                                      type : 'category',
                                      data :  mydata.line_r.dates 
                                    }
                                  ],
                                  yAxis : [
                                    {
                                      type : 'value'
                                    }
                                  ],
                                  series : [
                                    {
                                      name:'Sales',
                                      type:'line',
                                      data: mydata.line_r.sales,
                                      markPoint : {
                                        data : [
                                          {type : 'max', name: 'Max'},
                                          {type : 'min', name: 'Min'}
                                        ]
                                      },
                                      markLine : {
                                        data : [
                                          {type : 'average', name: 'Average'}
                                        ]
                                      }
                                    },
                                    {
                                      name:'New Users',
                                      type:'line',
                                      data: mydata.line_r.signups,
                                      markPoint : {
                                        data : [
                                          {type : 'max', name: 'Max'},
                                          {type : 'min', name: 'Min'}
                                        ]
                                      },
                                      markLine : {
                                        data : [
                                          {type : 'average', name: 'Average'}
                                        ]
                                      }
                                    }
                                  ]
                    };
                    myChart.setOption(options);
                
            }
        });
        
        
        //sales chart dp
        $('#salesgrdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#salesgrdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload graph
            $.ajax({
                url: app_url+'getResellerSales/'+$('#salesgrdp span').html(),
                success: function(res){
                    var mydata = JSON.parse(res);
                    //chart
                    var myChart = echarts.init(document.getElementById('salesgr'));
                        var options = {
                            tooltip : {
                                        trigger: 'axis'
                                      },
                                      color: ['#35b8e0','#f9c851'],
                                      legend: {
                                        data:['Sales','New Users']
                                      },
                                      calculable : true,
                                      xAxis : [
                                        {
                                          type : 'category',
                                          data :  mydata.line_r.dates 
                                        }
                                      ],
                                      yAxis : [
                                        {
                                          type : 'value'
                                        }
                                      ],
                                      series : [
                                        {
                                          name:'Sales',
                                          type:'line',
                                          data: mydata.line_r.sales,
                                          markPoint : {
                                            data : [
                                              {type : 'max', name: 'Max'},
                                              {type : 'min', name: 'Min'}
                                            ]
                                          },
                                          markLine : {
                                            data : [
                                              {type : 'average', name: 'Average'}
                                            ]
                                          }
                                        },
                                        {
                                          name:'New Users',
                                          type:'line',
                                          data: mydata.line_r.signups,
                                          markPoint : {
                                            data : [
                                              {type : 'max', name: 'Max'},
                                              {type : 'min', name: 'Min'}
                                            ]
                                          },
                                          markLine : {
                                            data : [
                                              {type : 'average', name: 'Average'}
                                            ]
                                          }
                                        }
                                      ]
                        };
                        myChart.setOption(options);

                }
            });
            
        });
        
        
        
        
        
        //top consumers dp    
         $('#topcldp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'right',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#topcldp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload figures
                     $.ajax({
                type: 'GET',
                url: app_url+'getTopConsumers/'+$('#topcldp span').html(),
                success: function(res){
                    var mydata = JSON.parse(res);
                    $("#topclctr").fadeOut(function(){
                        $(this).html(mydata.str).fadeIn(function(){
                            if(mydata.more==1 && mydata.rows==4){
                            $("#more_topcl").removeClass('hidden').attr('data-custom','4,4').html('Show More ...');
                            }else{
                                 $("#more_topcl").addClass('hidden');
                            }
                        });
                    });
                }
                });
            
        });
        //Set the initial state of the picker label
         $('#topcldp span').html(Date.today().add({
            days: -6
        }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
		
        
        // top consumers
        
        $.ajax({
            type: 'GET',
            url: app_url+'getTopConsumers/'+$('#topcldp span').html(),
            success: function(res){
                var mydata = JSON.parse(res);
                $("#topclctr").fadeOut(function(){
                    $(this).html(mydata.str).fadeIn(function(){
                        if(mydata.more==1 && mydata.rows==4){
                        $("#more_topcl").removeClass('hidden').attr('data-custom','4,4');
                        }else{
                             $("#more_topcl").addClass('hidden');
                        }
                    });
                });
            }
            });
        // show more top consumers
        $('#more_topcl').on("click",function(){
                $cllimit = $(this).attr('data-custom');
                if($cllimit!='0,4'){
                    //check to make sure all data isnnot loaded
                $(this).attr('disabled','disabled').html(SCTEXT('loading')+'....');
                $.ajax({
                    type: 'GET',
                    url: app_url+'getTopConsumers/'+$('#topcldp span').html()+'/'+$cllimit,
                    success: function(res){
                        var mydata = JSON.parse(res);
                        if(mydata.more==1){
                        $("#topclctr").append(mydata.str);
                        $('#topclctr').animate({
                            scrollTop: $('#topclctr').prop("scrollHeight")}, 500, function(){
                            $('#more_topcl').html(SCTEXT('Show More')+' ...').attr({"disabled":false,"data-custom":mydata.limit});
                        });

                        }else{

                            $('#more_topcl').html(SCTEXT('All loaded')).attr({"disabled":false,"data-custom":mydata.limit}); 
                        }
                    }
                });
                }
            })   
        
		//----------------//
        
        
        
        
        //top orders stuff
        // top orders
        $.ajax({
            type: 'GET',
            url: app_url+'getLatestOrders/'+$('#topsalesdp span').html(),
            success: function(res){
                var mydata = JSON.parse(res);
                $("#topsalesctr").fadeOut(function(){
                    $(this).html(mydata.str).fadeIn(function(){
                        if(mydata.more==1 && mydata.rows==4){
                        $("#more_sales").removeClass('hidden').attr('data-custom','4,4');
                        }else{
                             $("#more_sales").addClass('hidden');
                        }
                    });
                });
            }
            });
        // show more sales
        $('#more_sales').on("click",function(){
                $limit = $(this).attr('data-custom');
                if($limit!='0,4'){
                    //check to make sure all data isnnot loaded
                $(this).attr('disabled','disabled').html(SCTEXT('loading')+'....');
                $.ajax({
                    type: 'GET',
                    url: app_url+'getLatestOrders/'+$('#topsalesdp span').html()+'/'+$limit,
                    success: function(res){
                        var mydata = JSON.parse(res);
                        if(mydata.more==1){
                        $("#topsalesctr").append(mydata.str);
                        $('#topsalesctr').animate({
                            scrollTop: $('#topsalesctr').prop("scrollHeight")}, 500, function(){
                            $('#more_sales').html(SCTEXT('Show More')+' ...').attr({"disabled":false,"data-custom":mydata.limit});
                        });

                        }else{

                            $('#more_sales').html(SCTEXT('All loaded')).attr({"disabled":false,"data-custom":mydata.limit}); 
                        }
                    }
                });
                }
            })        
        
        //top order dp
        $('#topsalesdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'right',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#topsalesdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload sales figures
			  $.ajax({
		type: 'GET',
		url: app_url+'getLatestOrders/'+$('#topsalesdp span').html(),
		success: function(res){
            var mydata = JSON.parse(res);
			$("#topsalesctr").fadeOut(function(){
                $(this).html(mydata.str).fadeIn(function(){
                    if(mydata.more==1 && mydata.rows==4){
                    $("#more_sales").removeClass('hidden').attr('data-custom','4,4').html(SCTEXT('Show More')+' ...');
                    }else{
                        $("#more_sales").addClass('hidden');
                    }
                });
            });
        }
		});
            
        });
        //Set the initial state of the picker label
         $('#topsalesdp span').html(Date.today().add({
            days: -6
        }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
		

        //-------------//
        
        
        
        
         //recent transactions
         $.ajax({
            type: 'GET',
            url: app_url+'getRecentTransactions',
            success: function(res){
                var mydata = JSON.parse(res);
                $("#rectransbox").fadeOut(function(){
                    $(this).html(mydata.str).fadeIn();
                });
            }
            });
        
        
        //recent campaigns
         $.ajax({
            type: 'GET',
            url: app_url+'getRecentCampaigns',
            success: function(res){
                var mydata = JSON.parse(res);
                $("#recsmsbox").fadeOut(function(){
                    $(this).html(mydata.str).fadeIn();
                });
            }
            });
        
        //sms stats stuff
        //dp
         $('#smsstdp').daterangepicker({
                ranges: {
                    'Today': ['today', 'today'],
                    'Yesterday': ['yesterday', 'yesterday'],
                    'Last 7 Days': [Date.today().add({
                        days: -6
                    }), 'today'],
                    'Last 30 Days': [Date.today().add({
                        days: -29
                    }), 'today'],
                    'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                    'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                        months: -1
                    }), Date.today().moveToFirstDayOfMonth().add({
                        days: -1
                    })]
                },
                opens: 'right',
                format: 'MM/dd/yyyy',
                separator: ' to ',
                startDate: Date.today().add({
                    days: -29
                }),
                endDate: Date.today(),
                minDate: '01/01/2012',
                maxDate: '12/31/2020',
                locale: {
                    applyLabel: 'Apply',
                    clearLabel: 'Cancel',
                    customRangeLabel: 'Custom Range',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                    monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    firstDay: 1
                },
                showWeekNumbers: true,
                buttonClasses: ['btn-danger']
            },
            function (start, end) {
                $('#smsstdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
                //reload sms figures
                   $.ajax({
                            type: 'GET',
                            url: app_url+'getUserSmsActivity/'+$('#smsstdp span').html(),
                            success: function(res){
                                var mydata = JSON.parse(res);
                                var str = `<ul class="list-group"><li class="list-group-item"><span class="badge badge-info">${mydata.sent || 0}</span>${SCTEXT('Total SMS Sent')}</li><li class="list-group-item"><span class="badge badge-success">${mydata.delivered || 0}</span>${SCTEXT('SMS Delivered')}</li><li class="list-group-item"><span class="badge badge-danger">${mydata.failed || 0}</span>${SCTEXT('Failed SMS')}</li><li class="list-group-item"><span class="badge badge-purple">${mydata.used || 0}</span>${SCTEXT('Credits Used')}</li><li class="list-group-item"><span class="badge badge-pink">${mydata.refunds || 0}</span>${SCTEXT('Credits Refunded')}</li></ul>`;
                                $("#smsactctr").fadeOut(function(){$(this).html(str).fadeIn();})
                            }
                            });

            });
            //Set the initial state of the picker label
             $('#smsstdp span').html(Date.today().add({
                days: -6
            }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
        
        
         $.ajax({
             type: 'GET',
             url: app_url+'getUserSmsActivity/'+$('#smsstdp span').html(),
             success: function(res){
                        var mydata = JSON.parse(res);
                        var str = `<ul class="list-group"><li class="list-group-item"><span class="badge badge-info">${mydata.sent || 0}</span>${SCTEXT('Total SMS Sent')}</li><li class="list-group-item"><span class="badge badge-success">${mydata.delivered || 0}</span>${SCTEXT('SMS Delivered')}</li><li class="list-group-item"><span class="badge badge-danger">${mydata.failed || 0}</span>${SCTEXT('Failed SMS')}</li><li class="list-group-item"><span class="badge badge-purple">${mydata.used || 0}</span>${SCTEXT('Credits Used')}</li><li class="list-group-item"><span class="badge badge-pink">${mydata.refunds || 0}</span>${SCTEXT('Credits Refunded')}</li></ul>`;
                        $("#smsactctr").fadeOut(function(){$(this).html(str).fadeIn();})
                    }
            });
        
        //--//

        
    }
    
    
    
//32. View Account: Overview    
    
    if(curpage=='view_account'){       
        
        
        //switch account manager if admin
        if($("#u_acc_mgr").length>0){
            $("#u_acc_mgr").on("change", function(){
                var uid = $("#u_acc_mgr option:selected").val();
                bootbox.confirm({
                    message: SCTEXT("Are you sure you want to change the account manager for this user?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: 'Yes, Proceed',
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //send 
                            $.ajax({
                                url: app_url+'switchStaff',
                                type: 'post',
                                data: {user: $("#userid").val(), staff: uid},
                                success: function(res){
                                    window.location.reload();
                                }
                            })
                            }
                        }
                    }); 
            })
        }
        
        //datepicker for activity log
        if($("#uactl-dp").length>0){
            
            $('#uactl-dp').daterangepicker({
                ranges: {
                    'Today': ['today', 'today'],
                    'Yesterday': ['yesterday', 'yesterday'],
                    'Last 7 Days': [Date.today().add({
                        days: -6
                    }), 'today'],
                    'Last 30 Days': [Date.today().add({
                        days: -29
                    }), 'today'],
                    'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                    'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                        months: -1
                    }), Date.today().moveToFirstDayOfMonth().add({
                        days: -1
                    })]
                },
                opens: 'left',
                format: 'MM/dd/yyyy',
                separator: ' to ',
                startDate: Date.today().add({
                    days: -29
                }),
                endDate: Date.today(),
                minDate: '01/01/2012',
                maxDate: '12/31/2020',
                locale: {
                    applyLabel: 'Apply',
                    clearLabel: 'Cancel',
                    customRangeLabel: 'Custom Range',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                    monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    firstDay: 1
                },
                showWeekNumbers: true,
                buttonClasses: ['btn-danger']
            },
            function (start, end) {
                $('#uactl-dp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
                //reload table
                $('#t-uactlog').dataTable().api().ajax.url(app_url+"getUserActivity/"+$('#uactl-dp span').html()+'/'+$("#userid").val()).load();

            });
            
        }
        
        
         //recent transactions
         $.ajax({
            type: 'GET',
            url: app_url+'getRecentTransactions',
            data: { uid: $("#userid").val()},
            success: function(res){
                var mydata = JSON.parse(res);
                $("#rectransbox").fadeOut(function(){
                    if(mydata.str==''){
                        $(this).html(SCTEXT('No recent orders to show')).fadeIn();
                    }else{
                        $(this).html(mydata.str).fadeIn();
                    }
                    
                });
            }
            });
        
        //recent campaigns
         $.ajax({
            type: 'GET',
            url: app_url+'getRecentCampaigns',
            data: { uid: $("#userid").val()},
            success: function(res){
                var mydata = JSON.parse(res);
                $("#recsmsbox").fadeOut(function(){
                    $(this).html(mydata.str).fadeIn();
                });
            }
            });
        
        
        
        //date picker
        $('#stdp').daterangepicker({
                ranges: {
                    'Today': ['today', 'today'],
                    'Yesterday': ['yesterday', 'yesterday'],
                    'Last 7 Days': [Date.today().add({
                        days: -6
                    }), 'today'],
                    'Last 30 Days': [Date.today().add({
                        days: -29
                    }), 'today'],
                    'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                    'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                        months: -1
                    }), Date.today().moveToFirstDayOfMonth().add({
                        days: -1
                    })]
                },
                opens: 'right',
                format: 'MM/dd/yyyy',
                separator: ' to ',
                startDate: Date.today().add({
                    days: -29
                }),
                endDate: Date.today(),
                minDate: '01/01/2012',
                maxDate: '12/31/2020',
                locale: {
                    applyLabel: 'Apply',
                    clearLabel: 'Cancel',
                    customRangeLabel: 'Custom Range',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                    monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    firstDay: 1
                },
                showWeekNumbers: true,
                buttonClasses: ['btn-danger']
            },
            function (start, end) {
                $('#stdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
                //reload sms figures
                  $.ajax({
                            type: 'GET',
                            url: app_url+'getClientSmsActivity/'+$('#stdp span').html(),
                            data: {uid: $("#userid").val()},
                            success: function(res){
                                var mydata = JSON.parse(res);
                                
                                var myChart = echarts.init(document.getElementById('linesum'));
                                    var loption = {
                                        tooltip : {
                                                    trigger: 'axis'
                                                },
                                                color: ['#35b8e0','#10c469','#ff5b5b'],
                                                legend: {
                                                    data:['Sent','Delivered','Failed']
                                                },
                                                calculable : true,
                                                xAxis : [
                                                    {
                                                    type : 'category',
                                                    data :  mydata.line.dates 
                                                    }
                                                ],
                                                yAxis : [
                                                    {
                                                    type : 'value'
                                                    }
                                                ],
                                                series : [
                                                    {
                                                    name:'Sent',
                                                    type:'line',
                                                    data: mydata.line.Sent,
                                                    markPoint : {
                                                        data : [
                                                        {type : 'max', name: 'Max'},
                                                        {type : 'min', name: 'Min'}
                                                        ]
                                                    }
                                                    },
                                                    {
                                                    name:'Delivered',
                                                    type:'line',
                                                    data: mydata.line.Delivered,
                                                    markPoint : {
                                                        data : [
                                                        {type : 'max', name: 'Max'},
                                                        {type : 'min', name: 'Min'}
                                                        ]
                                                    }
                                                    },                                                       
                                                    {
                                                    name:'Failed',
                                                    type:'line',
                                                    data: mydata.line.Failed,
                                                    markPoint : {
                                                        data : [
                                                        {type : 'max', name: 'Max'},
                                                        {type : 'min', name: 'Min'}
                                                        ]
                                                    }
                                                    }
                                                ]
                                    };
                                    myChart.setOption(loption);
                                
                            }
                        })
        

            });
            //Set the initial state of the picker label
             $('#stdp span').html(Date.today().add({
                days: -9
            }).toString('MMM d, yyyy') + ' - ' + Date.today().toString('MMM d, yyyy'));
        
        
        //monthly activity and chart
        $.ajax({
            type: 'GET',
            url: app_url+'getClientSmsActivity',
            data: {uid: $("#userid").val(),mode:'init'},
            success: function(res){
                var mydata = JSON.parse(res);
                $("#msabox").fadeOut(function(){
                    $(this).html(mydata.table).fadeIn();
                });
                var myChart = echarts.init(document.getElementById('linesum'));
                    var loption = {
                        tooltip : {
                                    trigger: 'axis'
                                  },
                                  color: ['#35b8e0','#10c469','#ff5b5b'],
                                  legend: {
                                    data:['Sent','Delivered','Failed']
                                  },
                                  calculable : true,
                                  xAxis : [
                                    {
                                      type : 'category',
                                      data :  mydata.line.dates 
                                    }
                                  ],
                                  yAxis : [
                                    {
                                      type : 'value'
                                    }
                                  ],
                                  series : [
                                    {
                                      name:'Sent',
                                      type:'line',
                                      data: mydata.line.Sent,
                                      markPoint : {
                                        data : [
                                          {type : 'max', name: 'Max'},
                                          {type : 'min', name: 'Min'}
                                        ]
                                      }
                                    },
                                    {
                                      name:'Delivered',
                                      type:'line',
                                      data: mydata.line.Delivered,
                                      markPoint : {
                                        data : [
                                          {type : 'max', name: 'Max'},
                                          {type : 'min', name: 'Min'}
                                        ]
                                      }
                                    },                                                       
                                    {
                                      name:'Failed',
                                      type:'line',
                                      data: mydata.line.Failed,
                                      markPoint : {
                                        data : [
                                          {type : 'max', name: 'Max'},
                                          {type : 'min', name: 'Min'}
                                        ]
                                      }
                                    }
                                  ]
                    };
                    myChart.setOption(loption);
                
               
            }
        })
        
        
        //switch website status
        if($("#ws_toggle").length>0){
            $("#ws_toggle").on("change",function(){
                var wst = $(this).is(":checked")?1:0;
                var uid = $("#userid").val();
                
                $.ajax({
                    url: app_url+'websiteToggle',
                    method: 'post',
                    data: {uid: uid, status: wst},
                    success: function(res){
                        window.location.reload();
                        }
                    })
                
                
            });
        }
        
        
    }
    
   
    
//33. View Account: Make transaction
    
    if(curpage=='va_utrans'){
        var errcredits = 0;
        var numerr = 0;
        var d_errcredits = 0;
        var d_numerr = 0;

        //for currency based account
        $(document).on("keyup blur input","#mplanscredits", function(){
            //only numbers allowed
            if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test($(this).val()) && $(this).val()!=''){
                $(this).addClass('error-input');
                e.preventDefault();return;
            }else{
                $(this).removeClass('error-input');
            }
            let tax = $("#w_planid").attr('data-ptax');
            let taxtype = $("#w_planid").attr('data-taxtype');
            let credits = parseFloat($("#mplanscredits").val()) || 0;
            let gtotal = 0;
            let taxstr = 'including all taxes';
            if(parseFloat(tax)>0){
                gtotal = (credits + parseFloat((credits * (tax/100)))).toFixed(2);
                let taxes = [
                    {tax: 'GT', str: 'GST'},
                    {tax: 'VT', str: 'VAT'},
                    {tax: 'ST', str: 'Service Tax'},
                    {tax: 'SC', str: 'Service Charges'},
                    {tax: 'OT', str: 'Other Taxes'}
                ];
                let taxtypestr = taxes.find((item) => item.tax==taxtype);
                taxstr = `including ${tax}% ${taxtypestr.str}`;
            }else{
                gtotal = credits.toFixed(2);
            }
            $("#w_grand_total_amt").text(new Number(gtotal).toLocaleString('en-US', {minimumFractionDigits: 2}));
            $("#w_all_taxes").text(`(${taxstr})`);

        })

        //submit currency based transaction form
        $("#subcurfrm").on("click",function(){
            //validate
             
             if($("#mplanscredits").val()=='' || $("#mplanscredits").val()<=0){
                bootbox.alert(SCTEXT('Please enter a valid credit amount for this transaction.'));
                return;
                }
             
                 
             //submit form
               var dialog = bootbox.dialog({
                                 closeButton: false,
                                 message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Processing Transaction')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                             });   
                     dialog.init(function(){
                             $("#stbar").animate({width:"100%"},500)
                             setTimeout(function(){
                                 $("#w_form").attr('action',app_url+'processAccountTransaction');
                                 $("#w_form").submit();
                                 }, 200);
                             }); 
         });
        
        //submit credit transaction form
        $("#sub_cform").on("click",function(){
           //validate
            
            if($("#c_route option:selected").val()==''){
               bootbox.alert(SCTEXT('Please select a route to assign credits.'));
               return;
               }
            
            if($("#add_cre").val()==''){
                    bootbox.alert(SCTEXT('Please enter SMS credits to assign.'));
                   return;
                }

                if(numerr==1){
                    bootbox.alert(SCTEXT('Please enter only Numeric values in highlighted fields.'));
                   return;
                }

                 if(errcredits==1){
                    bootbox.alert(SCTEXT('Please do not assign more credits than your account balance.'));
                   return;
                }
            
                
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Processing Transaction')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#c_form").attr('action',app_url+'processAccountTransaction');
                                $("#c_form").submit();
                                }, 200);
                            }); 
        });
        
        
        //allot credits form
        $("#c_route").on("change", function(){
            var prc = $("#c_route option:selected").attr('data-price');
            //get sms price based on route selected
            $("#c_price").val(prc);
            
            //recalculate total cost if the credits are already entered
            if($("#add_cre").val()!=''){
                $("#add_cre").trigger("keyup");
            }
            
        });
            
            
        $(".numtxt").on("blur keyup", function(){
            //only numbers allowed
            if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test($(this).val()) && $(this).val()!=''){
                $(this).addClass('error-input');
                numerr = 1;
                e.preventDefault();return;
            }else{
                $(this).removeClass('error-input');
                numerr = 0;
            }
            var routencredits = [];
            var rdata = {id:$("#c_route option:selected").val(), credits:$("#add_cre").val(), price:$("#c_price").val()}; 
            routencredits.push(rdata);
            //calculate
             $.ajax({
                    url: app_url+'getPlanSmsPrice',
                    method: 'post',
                    data: {mode: 'utrans', plan: $("#planid").val(), routesData: JSON.stringify(routencredits), discount: 0, dtype: '', addTax: $("#c_utax").val()},
                    success: function(res){
                        var myarr = [];
                        myarr = JSON.parse(res);
                        //you have the price and credits entered
                        
                        //update the rate received from the db in case a plan is chosen
                        if($("#planid").val()!='0'){
                            $("#c_price").val(myarr.price[$("#c_route option:selected").val()].price);
                            
                        }
                        
                        var plan_cost = myarr.total_plan;
                        var ptax = myarr.plan_tax;
                        var gtotal = myarr.grand_total;
                        
                        //put plan total
                        $("#total_c_amt").text(plan_cost);
                        
                        //put tax declaration
                        $("#c_plan_taxes").text(ptax);
                        
                        //put grand total
                        $("#c_grand_total_amt").text(gtotal);
                        
                        //check error 
                        if(myarr.errcredits=='1'){
                            errcredits = 1
                            bootbox.alert(SCTEXT('Please do not assign more credits than your account balance.'));
                        }else{
                            errcredits = 0;
                        }
                        
                    }
                });
            
        });
        
        
        
         //deduct credit box
        $("#d_route").on("change", function(){
            var prc = $("#d_route option:selected").attr('data-price');
            //get sms price based on route selected
            $("#d_rtprc").text(prc);
            $("#rtavcr").text($("#d_route option:selected").attr('data-credits'));
            //reset the credit deduction number
            $("#deduct_cre").val("");
            $("#d_total_amt, #d_grand_total_amt").text("0.00");
            $("#dutax").val("");
            
        });
        // 
        //refund calculations when deducting credits
        $(".drtcredits").on("blur keyup", function(){
            //only numbers allowed
            if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test($(this).val()) && $(this).val()!=''){
                $(this).addClass('error-input');
                d_numerr = 1;
                e.preventDefault();return;
            }else{
                $(this).removeClass('error-input');
                d_numerr = 0;
            } 
            var routencredits = [];
            var rdata = {id:$("#d_route option:selected").val(), credits:$("#deduct_cre").val(), price:$("#d_rtprc").text()}; 
            routencredits.push(rdata);
            //calculate
             $.ajax({
                    url: app_url+'getPlanSmsPrice',
                    method: 'post',
                    data: {mode: 'utrans_d', plan: $("#planid").val(), routesData: JSON.stringify(routencredits), discount: 0, dtype: '', addTax: $("#dutax").val(), avcre:$("#rtavcr").text()},
                    success: function(res){
                        var myarr = [];
                        myarr = JSON.parse(res);
                        //you have the price and credits entered
                        
                        //update the rate received from the db in case a plan is chosen
                        if($("#planid").val()!='0'){
                            $("#d_rtprc").text(myarr.price[$("#d_route option:selected").val()].price);
                            
                        }
                        
                        var plan_cost = myarr.total_plan;
                        var ptax = myarr.plan_tax;
                        var gtotal = myarr.grand_total;
                        
                        //put plan total
                        $("#d_total_amt").text(plan_cost);
                        
                        //put tax declaration
                        $("#d_plan_taxes").text(ptax);
                        
                        //put grand total
                        $("#d_grand_total_amt").text(gtotal);
                        
                        //check error 
                        if(myarr.errcredits=='1'){
                            d_errcredits = 1
                            bootbox.alert(SCTEXT('Please do not deduct more credits than available in customer account.'));
                        }else{
                            d_errcredits = 0;
                        }
                        
                    }
                });
            
        });
        
        
        //submit debit transaction box
        $("#subfrm").on("click",function(){
           //validate
            
            if($("#d_route option:selected").val()==''){
               bootbox.alert(SCTEXT('Please select a route to deduct credits from.'));
               return;
               }
            
            if($("#deduct_cre").val()==''){
                    bootbox.alert(SCTEXT('Please enter SMS credits to deduct.'));
                   return;
                }

                if(d_numerr==1){
                    bootbox.alert(SCTEXT('Please enter only Numeric values in highlighted fields.'));
                   return;
                }

                 if(d_errcredits==1){
                    bootbox.alert(SCTEXT('Please do not deduct more credits than customer account balance.'));
                   return;
                }
            
                
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Processing Transaction')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#d_form").attr('action',app_url+'processAccountTransaction');
                                $("#d_form").submit();
                                }, 200);
                            }); 
        });
        
            
    }
    
    

//34. View Account: User Settings
    
    if(curpage=='va_uset'){

        //save hlr settings
        $("#save_hlrset").click(function(){
            //submit form
            var dialog = bootbox.dialog({
                closeButton: false,
                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
            });   
            dialog.init(function(){
                    $("#stbar").animate({width:"100%"},500)
                    setTimeout(function(){
                        $("#hlrsetform").attr('action',app_url+'saveUserHlrSettings');
                        $("#hlrsetform").submit();
                        }, 200);
                    }); 
        })

        //save 2-way settings for user
        $("#vmnsetsubmit").click(function(){
            //submit form
            var dialog = bootbox.dialog({
                closeButton: false,
                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
            });   
            dialog.init(function(){
                    $("#stbar").animate({width:"100%"},500)
                    setTimeout(function(){
                        $("#usrvmnsetform").attr('action',app_url+'saveUserVmnSettings');
                        $("#usrvmnsetform").submit();
                        }, 200);
                    }); 
        })

        //submit general permissions
        $("#pldbsetsubmit").click(function(){
           
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Phonebook permissions')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#pbdbsetform").attr('action',app_url+'saveUserPhonebookPermissions');
                                $("#pbdbsetform").submit();
                                }, 200);
                            }); 
        });

        //change number masking for phonebook
        var defnum = '971500301012';
        $("#maskstart,#masklen").on("change",function(){
                var mpos = $("#maskstart").val();
                var mlen = $("#masklen").val();
                var replacestr = "x".repeat(mlen);
                var newstr = substr_replace(defnum,replacestr,mpos,mlen);
                $("#egmask").html(newstr);
                $("#maskstart").attr('max',12 - parseInt(mlen));
        })

        
        //submit general permissions
         $("#upermsubmit").click(function(){
           
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving user permissions')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#upermform").attr('action',app_url+'saveUserPermissions');
                                $("#upermform").submit();
                                }, 200);
                            }); 
        });
        
         //submit special permissions
         $("#uflagbtn").click(function(){
           
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving user permissions')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#uflagform").attr('action',app_url+'saveUserSpecialFlags');
                                $("#uflagform").submit();
                                }, 200);
                            }); 
        });
        
        //submit whitelist numbers
        $("#uwconbtn").click(function(){
           
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving whitelist contacts')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#uwconform").attr('action',app_url+'saveUserWhitelist');
                                $("#uwconform").submit();
                                }, 200);
                            }); 
        });

        //smpp client management
        //toggle status
        $(document).on("change",".togstatus",function(){
            let sid = $(this).attr('data-sid');
            let rstatus = 0;
            if($(this).is(':checked')){rstatus=1;}
            $.ajax({
                url: app_url+'toggleSmppClientStatus',
                method: 'post',
                data: {id: sid, status: rstatus},
                 success: function(res){
                     bootbox.alert(res);
                 }
             })
         });
         
         //delete route
         $(document).on("click",".delsmppclient",function(){
            let aid = $(this).attr('data-aid');
              bootbox.confirm({
                     message: SCTEXT('Please make sure this account does not have SMS data associated with it. If you need to temporarily disable it, please change the status of this account by the green switch. Are you sure you want to permanently delete this SMPP client account?'),
                     buttons: {
                         cancel: {
                             label: SCTEXT('No'),
                             className: 'btn-default'
                         },
                          confirm: {
                             label: SCTEXT('Yes'),
                             className: 'btn-info'
                         }
                     },
                     callback: function (result) {
                         if(result){
                             //delete 
                             window.location = app_url+'deleteSmppClient/'+$("#userid").val()+'/'+aid;
                             }
                         }
                     }); 
         });
        
    }
    
    
    
//35. Edit Profile
    
    if(curpage=='edit_profile'){
        
        //submit company info
         $("#savecifrm").click(function(){
           //validate
            
            if($("#cname").val()==''){
               bootbox.alert(SCTEXT('Company name cannot be blank.'));
               return;
               }

                if($("#cphn").val()==''){
                    bootbox.alert(SCTEXT('Company phone number cannot be blank.'));
                   return;
                }

                 if($("#cmail").val()==''){
                    bootbox.alert(SCTEXT('Company email ID cannot be blank.'));
                   return;
                }
            
            
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving company information')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#cifrm").attr('action',app_url+'saveCompanyInfo');
                                $("#cifrm").submit();
                                }, 200);
                            }); 
        });
        
        //match passwords
        var errpass = 0;
        $("#newpass1, #newpass2").on("keyup blur",function(){
            var mode = $(this).attr('data-strength');
            var val = $(this).val();
            
            if(mode=='weak'){
                //length
                if(val.length < 6){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                }
            }
            
            if(mode=='average'){
                //length
                if(val.length < 8){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                    //alphabet letter
                    if(!/[a-zA-Z]/.test(val)){
                        errpass = 1;
                        $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one alphabet letter.'));
                    }else{
                        errpass = 0;
                        $("#pass-err").text('');
                        //numeric
                        if(!/[0-9]/.test(val)){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                        }
                        
                    }
                    
                }
            }
            
            if(mode=='strong'){
                //length
                if(val.length < 8){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                }else{
                    errpass = 0;
                    $("#pass-err").text('');
                    //uppercase alphabet
                    if(!/[A-Z]/.test(val)){
                        errpass = 1;
                        $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one uppercase letter.'));
                    }else{
                        errpass = 0;
                        $("#pass-err").text('');
                        //numeric
                        if(!/[0-9]/.test(val)){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                            //special characters
                            if(!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(val)){
                                errpass = 1;
                                $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one special character.'));
                            }else{
                                errpass = 0;
                                $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                            }
                        }
                        
                    }
                    
                }
                
                    
            }
            if(errpass==0){
                //if everything is good match both passwords
                if($('#newpass1').val()!=$('#newpass2').val()){
                    errpass = 1;
                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Passwords do not match each other. Please re-type your password'));
                }else{
                    errpass = 0;
                    $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                }
            }
        });
        
        
        //submit save password
        $("#savecpfrm").click(function(){
           //validate
            
            if($("#oldpass").val()==''){
               bootbox.alert(SCTEXT('Please enter old password.'));
               return;
               }

                if($("#newpass1").val()=='' || $("#newpass1").val()==''){
                    bootbox.alert(SCTEXT('Please enter values in all the fields.'));
                   return;
                }

                if(errpass==1){
                    bootbox.alert(SCTEXT('Some errors are found with your entry. Please rectify before submitting the form.'));
                    return;
                }
            
            
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Changing account password')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#cpfrm").attr('action',app_url+'saveUserPassword');
                                $("#cpfrm").submit();
                                }, 200);
                            }); 
        });
        
        
        
        
        
        //verify phone
        $("#vphn").click(function(){
            bootbox.confirm({
                    message: SCTEXT("We will send you a 6-digit one-time password (OTP) to your mobile number. Make sure you have saved your correct mobile number."),
                    buttons: {
                        cancel: {
                            label: SCTEXT('Cancel'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Send OTP'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //call ajax and send otp
                            $.ajax({
                                url: app_url+'verifyViaOTP/mobile',
                                success: function(res){
                                    //prompt for otp
                                    bootbox.prompt(SCTEXT("Enter the 6-digit OTP sent to your mobile number"), function(act){
                                        var box = $(this);
                                        //variable act will have the otp entered
                                        if(act){
                                            
                                            //confirm opt
                                            
                                            $.ajax({
                                                url: app_url+'confirmOTP/mobile',
                                                method: 'post',
                                                data: {otp: act},
                                                async: false,
                                                success: function(myres){
                                                    var mydata = JSON.parse(myres);
                                                    if(mydata.match_result=='no'){
                                                        if($("#otperr").length>0){
                                                            $("#otperr").html(SCTEXT("The OTP entered did not match."));
                                                            box.effect("shake");
                                                        }else{
                                                           $( "<span id='otperr' class='help-block text-danger'>"+SCTEXT('The OTP entered did not match.')+"</span>" ).insertAfter( "input.bootbox-input-text" );
                                                            box.effect("shake");
                                                        }
                                                        
                                                        
                                                    }else{
                                                        window.location.reload();
                                                    }
                                                    
                                                }
                                            })
                                            
                                            return false; //to keep bootbox open
                                            
                                        }else{
                                            if($("#otperr").length>0){
                                                $("#otperr").html(SCTEXT("OTP cannot be blank."));
                                                box.effect("shake");
                                            }else{
                                               $("<span id='otperr' class='help-block text-danger'>"+SCTEXT('OTP cannot be blank.')+"</span>").insertAfter("input.bootbox-input-text");
                                                box.effect("shake");
                                            }
                                            return false;
                                        }
                                    });
                                    
                                }
                            });
                            
                            }
                        }
                    }); 
        });
        
        //verify email
        $("#vmail").click(function(){
            bootbox.confirm({
                    message: "We will send you a 6-digit one-time password (OTP) to your email. Make sure you have saved your correct email address and check your SPAM/JUNK box if not received within a minute.",
                    buttons: {
                        cancel: {
                            label: SCTEXT('Cancel'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Send OTP'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //call ajax and send otp
                            $.ajax({
                                url: app_url+'verifyViaOTP/email',
                                success: function(res){
                                    //prompt for otp
                                    bootbox.prompt(SCTEXT("Enter the 6-digit OTP sent to your email address"), function(act){
                                        var box = $(this);
                                        //variable act will have the otp entered
                                        if(act){
                                            
                                            //confirm opt
                                            
                                            $.ajax({
                                                url: app_url+'confirmOTP/email',
                                                method: 'post',
                                                data: {otp: act},
                                                async: false,
                                                success: function(myres){
                                                    var mydata = JSON.parse(myres);
                                                    console.log(mydata.match_result);
                                                    if(mydata.match_result=='no'){
                                                        if($("#otperr").length>0){
                                                            $("#otperr").html(SCTEXT("The OTP entered did not match."));
                                                            box.effect("shake");
                                                        }else{
                                                           $( "<span id='otperr' class='help-block text-danger'>"+SCTEXT('The OTP entered did not match.')+"</span>" ).insertAfter( "input.bootbox-input-text" );
                                                            box.effect("shake");
                                                        }
                                                        
                                                        
                                                    }else{
                                                        window.location.reload();
                                                    }
                                                    
                                                }
                                            })
                                            
                                            return false; //to keep bootbox open
                                            
                                        }else{
                                            if($("#otperr").length>0){
                                                $("#otperr").html(SCTEXT("OTP cannot be blank."));
                                                box.effect("shake");
                                            }else{
                                               $("<span id='otperr' class='help-block text-danger'>"+SCTEXT('OTP cannot be blank.')+"</span>").insertAfter("input.bootbox-input-text");
                                                box.effect("shake");
                                            }
                                            return false;
                                        }
                                    });
                                    
                                }
                            });
                            
                            }
                        }
                    }); 
        });
        
        
         var erremail = 0;
        var errphone = 0;
        
        $(document).on("change","#u-img",function(){
            var ele = $(this);
            ele.next().next().html(ele.val());
        });
        
        
        //validate email
        $("#uemail").on("keyup blur",function(){
            var email = $(this).val();
            $("#v-email").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>');
            if(!echeck(email)){
                $("#v-email").html('<i class="fa fa-lg fa-times text-danger"></i>');
                erremail=1;
                emsg = SCTEXT('Invalid Email ID');
            }else{
                $("#v-email").html('<i class="fa fa-lg fa-check text-success"></i>');
                erremail=0;
                emsg = '';
                //verify
                $.ajax({
                url: app_url+'checkAvailability',
                method: 'post',
                async: false,
                data: {mode: 'email', value: email, page: 'editprofile'},
                success: function(res){
                        if(res=='FALSE'){
                            $("#v-email").html('<i class="fa fa-lg fa-times text-danger"></i>');
                            erremail=1;
                            emsg = SCTEXT('Email ID already exist. Please enter a different email ID.');
                        }else{
                            $("#v-email").html('<i class="fa fa-lg fa-check text-success"></i>');
                            erremail=0;
                            emsg = '';
                            
                        }
                    }
                });
            }
            
        });
        //validate phone
        $("#uphn").on("keyup blur",function(){
            var phn = $(this).val();
            $("#v-phn").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>');
            if(!isValidPhone(phn)){
                $("#v-phn").html('<i class="fa fa-lg fa-times text-danger"></i>');
                errphone=1;
                emsg = SCTEXT('Invalid Phone number entered.');
            }else{
                $("#v-phn").html('<i class="fa fa-lg fa-check text-success"></i>');
                errphone=0;
                emsg = '';
                //verify
                $.ajax({
                url: app_url+'checkAvailability',
                method: 'post',
                async: false,
                data: {mode: 'mobile', value: phn, page: 'editprofile'},
                success: function(res){
                        if(res=='FALSE'){
                            $("#v-phn").html('<i class="fa fa-lg fa-times text-danger"></i>');
                            errphone=1;
                            emsg = SCTEXT('Phone number already exist. Please enter a different phone number.');
                        }else{
                            $("#v-phn").html('<i class="fa fa-lg fa-check text-success"></i>');
                            errphone=0;
                            emsg = '';
                            
                        }
                    }
                });
            }
            
        });
        
        
        
        //save
        $("#saveupfrm").click(function(){
           //validate
            
            if($("#uname").val()==''){
               bootbox.alert(SCTEXT('Please enter name of the user.'));
               return;
               }

                if($("#uemail").val()=='' || $("#uphn").val()==''){
                    bootbox.alert(SCTEXT('Please enter values in all the fields.'));
                   return;
                }

                if(erremail==1 || errphone==1 ){
                    if(emsg==''){
                        bootbox.alert(SCTEXT('Some errors are found with your entry. Please rectify before submitting the form.'));
                    }else{
                        bootbox.alert(emsg);
                    }

                    return;
                }
            
            
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Profile Information')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#upfrm").attr('action',app_url+'saveUserProfile');
                                $("#upfrm").submit();
                                }, 200);
                            }); 
        });
    }
    
    
    
//36. User Settings
    
    if(curpage=='user_settings'){
        
        //submit form
        $("#saveuset").click(function(){
           
            var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving account settings')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#usfrm").attr('action',app_url+'saveUserSettings');
                                $("#usfrm").submit();
                                }, 200);
                            }); 
            
        });
        
    }
    
//37. Notifications
    
    if(curpage=='notifs'){
        
        //datepicker
        $('#altdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#altdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload table
            $('#t-alerts').dataTable().api().ajax.url(app_url+"getAllMyAlerts/"+$('#altdp span').html()).load();
            
        });
        //Set the initial state of the picker label
         $('#altdp span').html('Select Date');
        
        
    }
    
    
    
    
//38. Support Ticket Management
    
    if(curpage=='support_tickets_mgmt'){
        $('#tktmgrdp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#tktmgrdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload table
            $('#dt_suptkt_mgr').dataTable().api().ajax.url(app_url+"getAssignedTickets/"+$('#tktmgrdp span').html()).load();
            
        });
        //Set the initial state of the picker label
         $('#tktmgrdp span').html('Select Date');
    }
    
    
//39. View Ticket by Account Manager
    
    if(curpage=='view_ticket_mgr'){
        //scroll to the bottom of comment box
        $('#docremk').animate({scrollTop: $('#docremk').prop("scrollHeight")}, 500);
        
        //post comment
        $("#submitCmt").click(function(){
           //validate
            if($('#t_comment').val()==''){
                bootbox.alert(SCTEXT('Your comment cannot be blank'));
                return;
            }
            //post
            $(this).attr('disabled','disabled').html(SCTEXT('Submitting')+' ...');
            $("#cmt_form").attr('action',app_url+'postTicketComment');
            $("#cmt_form").submit();
            
        });
    }
    
    
    
//40. Add Spam Keyword
    
    if(curpage=='add_spam_kw'){
        
         //submit form
        $("#save_changes").click(function(){
            
            if($("#kw").val()==''){
                bootbox.alert(SCTEXT('Spam keyword cannot be empty. Please enter a keyword.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving new SPAM keyword')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#add_spmkw_form").attr('action',app_url+'saveSpamKeyword');
                                $("#add_spmkw_form").submit();
                                }, 100);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageSpamKeywords';
        });
        
    }
    
    
//41. System monitor
    
    if(curpage=='system_mon'){
        
        //load users
        $.ajax({
            url: app_url+'getAllUserStatus',
            success: function(res){
                var ustrar = [];
                ustrar = JSON.parse(res);
                
                $("#tab-online").html(ustrar.online);
                $("#tab-all").html(ustrar.all);
            }
        });
        
         //change temp sms status
        $(document).on("change",".togtcstatus",function(){
           var cid = $(this).attr('data-cid');
            var cstatus = 0;
           if($(this).is(':checked')){cstatus=1;}
           $.ajax({
                url: app_url+'changeCampaignStatus',
               method: 'post',
               data: {cid: cid, status: cstatus, mode: 'tc'},
                success: function(res){
                    bootbox.alert(res);
                }
            })
        });
        
        //change queued sms status
        $(document).on("change",".togqcstatus",function(){
           var cid = $(this).attr('data-cid');
            var cstatus = 0;
           if($(this).is(':checked')){cstatus=1;}
           $.ajax({
                url: app_url+'changeCampaignStatus',
               method: 'post',
               data: {cid: cid, status: cstatus, mode: 'qc'},
                success: function(res){
                    bootbox.alert(res);
                }
            })
        });
        
        //change schedule status
         $(document).on("change",".togscstatus",function(){
           var cid = $(this).attr('data-cid');
            var cstatus = 0;
           if($(this).is(':checked')){cstatus=1;}
           $.ajax({
                url: app_url+'changeCampaignStatus',
               method: 'post',
               data: {cid: cid, status: cstatus, mode: 'sch'},
                success: function(res){
                    bootbox.alert(res);
                }
            })
        });
        
        //maually send scheduled
        $(document).on("click",".mansc", function(){
            var cid = $(this).attr('data-cid');
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to send this campaign right now?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //send now
                             $.ajax({
                                    url: app_url+'sendScheduleManually',
                                    method: 'post',
                                    data: {cid: cid},
                                    success: function(res){
                                        bootbox.alert(res);
                                        //reload table
                                        $('#dt_sc').dataTable().api().ajax.url(app_url+"getAllScheduledCampaigns").load(function(jdata){
                                           $(document).find(".sswitch").each(function () {
                                                var b = $(this)
                                                    , c = b.attr("data-color")
                                                    , d = "#ffffff"
                                                    , e = "small";
                                                new Switchery(this, {
                                                    color: c
                                                    , size: e
                                                    , jackColor: d
                                                })
                                            })
                                        });
                                    }
                                });
                            }
                        }
                    }); 
        })
        
        //cancel send temp 
         $(document).on("click",".cantc", function(){
            var cid = $(this).attr('data-cid');
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to cancel this campaign right now and refund credits?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //cancel
                             $.ajax({
                                    url: app_url+'cancelTempCampaign',
                                    method: 'post',
                                    data: {cid: cid},
                                    success: function(res){
                                        bootbox.alert(res);
                                        //reload table
                                        $('#dt_tc').dataTable().api().ajax.url(app_url+"getAllTempCampaigns").load(function(jdata){
                                           $(document).find(".tswitch").each(function () {
                                                var b = $(this)
                                                    , c = b.attr("data-color")
                                                    , d = "#ffffff"
                                                    , e = "small";
                                                new Switchery(this, {
                                                    color: c
                                                    , size: e
                                                    , jackColor: d
                                                })
                                            })
                                        });
                                    }
                                });
                            }
                        }
                    }); 
        })
         
        
        //toggle status
        $(document).on("change",".togstatus",function(){
           var rid = $(this).attr('data-rid');
            var rstatus = 1;
           if($(this).is(':checked')){rstatus=0;}
           $.ajax({
                url: app_url+'changeRouteStatus',
               method: 'post',
               data: {rid: rid, status: rstatus},
                success: function(res){
                    bootbox.alert(res);
                }
            })
        });
        
        
        //drop sms
        $(document).on("click",".submit_drop",function(){
            $frm_id = $(this).attr('data-form-id');
            curele = $(this);
            bootbox.confirm(SCTEXT("Are you sure you want to DROP sms from Queue?"), 
            function(res){
                if(res){
                    curele.html('<i class="fa fa-spinner fa-spin"></i>&nbsp;'+SCTEXT('Processing'));
                    $('#'+$frm_id).attr('action',app_url+'dropQueuedBatches');
                    $('#'+$frm_id).submit();
                }

            });

        });
        
        
        //shift sms
         $(document).on("click",".submit_shift",function(){
            $frm_id = $(this).attr('data-form-id');
            curele = $(this);
            bootbox.confirm(SCTEXT("Are you sure you want to SHIFT sms from Queue?"), 
            function(res){
                if(res){
                    curele.html('<i class="fa fa-spinner fa-spin"></i>&nbsp;'+SCTEXT('Processing'));
                    $('#'+$frm_id).attr('action',app_url+'shiftQueuedBatches');
                    $('#'+$frm_id).submit();
                }

            });

        });
        
        
        //auto refresh
        setInterval(function(){
            //queued campaigns
            if($("#qc_ref").is(":checked")){
                $('#dt_qc').dataTable().api().ajax.url(app_url+"getAllQueuedCampaigns").load(function(jdata){
                   $(document).find(".qswitch").each(function () {
                        var b = $(this)
                            , c = b.attr("data-color")
                            , d = "#ffffff"
                            , e = "small";
                        new Switchery(this, {
                            color: c
                            , size: e
                            , jackColor: d
                        })
                    })
                });
            }
            //scheduled campaigns
            if($("#sc_ref").is(":checked")){
                $('#dt_sc').dataTable().api().ajax.url(app_url+"getAllScheduledCampaigns").load(function(jdata){
                   $(document).find(".sswitch").each(function () {
                        var b = $(this)
                            , c = b.attr("data-color")
                            , d = "#ffffff"
                            , e = "small";
                        new Switchery(this, {
                            color: c
                            , size: e
                            , jackColor: d
                        })
                    })
                });
            }
            
            //temp campaigns
            if($("#tc_ref").is(":checked")){
                $('#dt_tc').dataTable().api().ajax.url(app_url+"getAllTempCampaigns").load(function(jdata){
                   $(document).find(".tswitch").each(function () {
                        var b = $(this)
                            , c = b.attr("data-color")
                            , d = "#ffffff"
                            , e = "small";
                        new Switchery(this, {
                            color: c
                            , size: e
                            , jackColor: d
                        })
                    })
                });
            }
            
            //online users
            if($("#ou_ref").is(":checked")){
                $.ajax({
                    url: app_url+'getAllUserStatus',
                    success: function(res){
                        var ustrar = [];
                        ustrar = JSON.parse(res);

                        $("#tab-online").html(ustrar.online);
                        $("#tab-all").html(ustrar.all);
                    }
                });
            }
            
            
            
        }, 10000);
        
        
        
        
    }
    
    
    
//42. View Account: Route Settings
    
    if(curpage=='va_rset'){

        //for sms plans
        $("#save_changes").click(function(){
            
             //submit form
               var dialog = bootbox.dialog({
                                 closeButton: false,
                                 message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving SMS Plan Assignment')}. . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                             });   
                     dialog.init(function(){
                             $("#stbar").animate({width:"100%"},500)
                             setTimeout(function(){
                                 $("#rsetform").attr('action',app_url+'saveUserPlanAssignment');
                                 $("#rsetform").submit();
                                 }, 200);
                             }); 
         });
        
        //toggle route detail display
        $(".rtsel").on("change",function(){
            var rid = $(this).attr('data-rid');
            var dbox = "#rtdetail-"+rid;
            if($(this).is(":checked")){
                $(dbox).collapse('show');
            }else{
                $(dbox).collapse('hide');
            }
        })
        
        $("#savefrm").click(function(){
           //validate
            
            //submit form
              var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving route assignments')}. . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#rsetform").attr('action',app_url+'saveRouteAssignments');
                                $("#rsetform").submit();
                                }, 200);
                            }); 
        });
        
    }
    
    
    
    
//43. View account: user actions
    if($("#page_family").length>0){
        //we are in view account section
        $(document).on("click","a.useraction", function(){
            var act = $(this).attr('data-act');
            var uid = $("#userid").val();
            
            //upgrade account
            if(act=='upgradeacc'){
                bootbox.confirm({
                    message: SCTEXT("Are you sure you want to upgrade this account to Reseller? This action cannot be reversed."),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes, Proceed'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //convert 
                            $.ajax({
                                url: app_url+'accountActions/upgrade/'+uid,
                                method: 'get',
                                success: function(res){
                                    window.location.reload();
                                }
                            })
                            }
                        }
                    }); 
            }
            
            //change password
            if(act=='changepsw'){
                var errpass = 1;
                $("#resetPassBox").modal();
                
                $(document).on("click","#resetPassSubmit",function(){
                   if(errpass!=1){
                       //no errors
                       var pass1 = $("#upass").val();
                       var pass2 = $("#upass2").val();
                       var uid = $("#userid").val();
                       $(this).attr('disabled','disabled').css("cursor","progress");
                       $.ajax({
                          url: app_url+'passwordReset',
                           method: 'post',
                           data: {user: uid, cat: 'user', pass1: pass1, pass2: pass2},
                           success: function(){
                               window.location.reload();
                           }
                       });
                   } 
                });
                
                //match passwords
                $(document).on("keyup blur","#upass, #upass2",function(){
                    var mode = $(this).attr('data-strength');
                    var val = $(this).val();

                    if(mode=='weak'){
                        //length
                        if(val.length < 6){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                        }
                    }

                    if(mode=='average'){
                        //length
                        if(val.length < 8){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                            //alphabet letter
                            if(!/[a-zA-Z]/.test(val)){
                                errpass = 1;
                                $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one alphabet letter.'));
                            }else{
                                errpass = 0;
                                $("#pass-err").text('');
                                //numeric
                                if(!/[0-9]/.test(val)){
                                    errpass = 1;
                                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                                }else{
                                    errpass = 0;
                                    $("#pass-err").text('');
                                }

                            }

                        }
                    }

                    if(mode=='strong'){
                        //length
                        if(val.length < 8){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password too short'));
                        }else{
                            errpass = 0;
                            $("#pass-err").text('');
                            //uppercase alphabet
                            if(!/[A-Z]/.test(val)){
                                errpass = 1;
                                $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one uppercase letter.'));
                            }else{
                                errpass = 0;
                                $("#pass-err").text('');
                                //numeric
                                if(!/[0-9]/.test(val)){
                                    errpass = 1;
                                    $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one numeric character.'));
                                }else{
                                    errpass = 0;
                                    $("#pass-err").text('');
                                    //special characters
                                    if(!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(val)){
                                        errpass = 1;
                                        $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Password must have at least one special character.'));
                                    }else{
                                        errpass = 0;
                                        $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                                    }
                                }

                            }

                        }


                    }
                    if(errpass==0){
                        //if everything is good match both passwords
                        if($('#upass').val()!=$('#upass2').val()){
                            errpass = 1;
                            $("#pass-err").removeClass('text-success').addClass('text-danger').text(SCTEXT('Passwords do not match each other. Please re-type your password'));
                        }else{
                            errpass = 0;
                            $("#pass-err").removeClass('text-danger').addClass('text-success').text(SCTEXT('Password is acceptable'));
                        }
                    }
                });
        
                
                
            }
            
            
            //suspend account
            if(act=='usersus'){
                bootbox.confirm({
                    message: SCTEXT("Suspending this account will also suspend any accounts added under this user. Complete user tree for this account will be disabled. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes, Proceed'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //suspend 
                            $.ajax({
                                url: app_url+'accountActions/suspend/'+uid,
                                method: 'get',
                                success: function(res){
                                   window.location = app_url+'manageUsers';
                                }
                            })
                            }
                        }
                    }); 
            }
            
            
             //delete account
            if(act=='userdel'){
                bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this user account? This action cannot be undone. The available credits in this account will be added to your account or the corresponding reseller account. Shall we proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes, Proceed'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'accountActions/delete/'+uid,
                                method: 'get',
                                success: function(res){
                                    window.location = app_url+'manageUsers';
                                }
                            })
                            }
                        }
                    }); 
            }
            
            
        });
        
    }
    
    
    
//44. Manage suspended users
    if(curpage=='manage_iusers'){
        $(document).on("click",".del-user", function(){
            var uid = $(this).attr('data-uid');
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete this user account? This action cannot be undone. The available credits in this account will be added to your account or the corresponding reseller account. Shall we proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes, Proceed'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'accountActions/delete/'+uid,
                                method: 'get',
                                success: function(res){
                                    window.location = app_url+'manageInactiveUsers';
                                }
                            })
                            }
                        }
                    }); 
        })
        
    }
    
    
    

//45. Buy SMS
    if(curpage=='buy_sms'){
        
        //show available credits and SMS rates
        $("#routesel").on("change",function(){
            var rtele = $("#routesel option:selected");
            //a. available credits
            $("#rtavcr").html(formatInt(parseInt(rtele.attr('data-acr'))));
            //b. sms rates
            $("#smsrate").html(app_currency+' '+rtele.attr('data-crt')+' per SMS');
            $("#smscredits").trigger("keyup");
        });
        
        
        //format sms credits
        $("#smscredits").on("keyup blur",function(){
            
            var rcr = $(this).val().replace(/\s+/g, '');
            
            //only number allowed
            if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test(rcr) && rcr !=''){
                $(this).addClass('error-input');
                e.preventDefault();return;
            }else{
                $(this).removeClass('error-input');
            }
            
            
            var res = rcr.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
            $(this).val(res);
            
            if($("#ptype").length>0 && $("#ptype").val()=='0'){
                //volume based plan
                var routencredits = [];
                var pid = $("#planid").val();
                var taxtype = '';
                var total = 0;
                var remwal = 0;
                var rdata = {id:$("#routesel option:selected").val(), credits:rcr}; 
                routencredits.push(rdata);
                $.ajax({
                        url: app_url+'getPlanSmsPriceOuter',
                        method: 'post',
                        data: {plan: pid, routesData: JSON.stringify(routencredits)},
                        success: function(res){
                            var myarr = [];
                            myarr = JSON.parse(res);
                            console.log(myarr);
                            //you have the price and credits entered

                            //update the rate received from the db in case a plan is chosen
                            if(pid!='0'){
                                for (grid in myarr.price){
                                    $("#smsrate").html(app_currency+' '+myarr.price[grid].price+' per SMS');
                                    break; //run loop only once
                                }
                            }

                            
                            taxtype = myarr.plan_tax;
                            total = myarr.grand_total;
                            
                            //check if wallet credits
                            if($("#walbal").val()>0){
                                if($("#cb-1").is(":checked")){
                                    var totalpayable = total<=parseFloat($("#walbal").val())?0:total-parseFloat($("#walbal").val());
                                
                                    $("#total_amt_payable").html(totalpayable.toLocaleString());
                                    $("#all_taxes_payable").html(taxtype);
                                    remwal = total>=parseFloat($("#walbal").val())?0:($("#walbal").val()-total).toLocaleString();
                                    $("#remwal").text(app_currency+remwal);
                                }else{
                                    //customer does not wanna use wallet credits
                                    var totalpayable = total;
                                
                                    $("#total_amt_payable").html(totalpayable.toLocaleString());
                                    $("#all_taxes_payable").html(taxtype);
                                    remwal = $("#walbal").val().toLocaleString();
                                    $("#remwal").text(app_currency+remwal);
                                }
                                
                            }
                            
                            $("#grand_total_amt").html(total.toLocaleString());
                            $("#all_taxes").html(taxtype);

                        }
                    });
                
                
                
                
            }else{
                //regular route assignment
                //calculate sms cost
                
                var total = rcr*$("#routesel option:selected").attr('data-crt');
                
               
                //tax
                var taxtype = SCTEXT('including all taxes');
                switch($("#taxtype").val()) {
                    case 'VT':
                        taxtype = 'including '+$("#tax").val()+'% VAT';
                        break;
                    case 'ST':
                        taxtype = 'including '+$("#tax").val()+'% Service Tax';
                        break;
                    case 'SC':
                        taxtype = 'including '+$("#tax").val()+'% Service Charge';
                        break;
                    case 'OT':
                        taxtype = 'including '+$("#tax").val()+'% Tax';
                        break;
                    case 'GT':
                        taxtype = 'including '+$("#tax").val()+'% GST';
                        break;
                    default:
                        taxtype = SCTEXT('including all taxes');
                } 

                total += $("#tax").val()!=''?(parseFloat($("#tax").val())/100)*total:0;
                
                
                
                 //check if wallet credits
                            if($("#walbal").val()>0){
                                if($("#cb-1").is(":checked")){
                                    var totalpayable = total<=parseFloat($("#walbal").val())?0:total-parseFloat($("#walbal").val());
                                
                                    $("#total_amt_payable").html(totalpayable.toLocaleString());
                                    $("#all_taxes_payable").html(taxtype);
                                    remwal = total>=parseFloat($("#walbal").val())?0:($("#walbal").val()-total).toLocaleString();
                                    $("#remwal").text(app_currency+remwal);
                                }else{
                                    //customer does not wanna use wallet credits
                                    var totalpayable = total;
                                
                                    $("#total_amt_payable").html(totalpayable.toLocaleString());
                                    $("#all_taxes_payable").html(taxtype);
                                    remwal = $("#walbal").val().toLocaleString();
                                    $("#remwal").text(app_currency+remwal);
                                }
                                
                            }else{
                                //no wallet balance
                                var totalpayable = total;
                                $("#total_amt_payable").html(totalpayable.toLocaleString());
                            }
                
                $("#grand_total_amt").html(total.toLocaleString());
                $("#all_taxes").html('('+taxtype+')');
            }
            
            
            
            
            
        })
        
        
        //wallet deduction if applicable
        if($("#cb-1").length>0){
            $("#cb-1").on("change", function(){
                $("#smscredits").trigger("keyup");
            })
        }
        
        
        $("#routesel").change();
        
        //payment
        $("#proceedtopay").click(function(){
            
            if($("#smscredits").val()=='' || $("#smscredits").val()<=0){
                    bootbox.alert(SCTEXT('Please enter valid SMS credits to purchase.'));
                    return;
                }
            
            var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Confirming your order')} ...</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });
                        dialog.init(function(){
                                    $("#stbar").animate({width:"100%"},5000)
                                    setTimeout(function(){
                                        $("#bs_form").attr('action',app_url+'buyOrderCheckout');
                                        $("#bs_form").submit();
                                    }, 2000);
                                });
        })
    }
    
    

    
//46. Confirm purchase order
    if(curpage=='confirm_po'){
        
    }
    
    
    
//47. App Settings
    if(curpage=='app_settings'){
        
        //
        $('.nav-tabs a[href="#' + $("#activeTabId").val() + '"]').tab('show');
        
        
        //fake dlr ratios
        $(".fakedlr").each(function(){
            $(this).on("change blur keyup",function(){
                var fdele = $(this);
                //only numbers allowed
                if(!/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/.test(fdele.val()) && fdele.val()!=''){
                    fdele.val(0);
                    e.preventDefault();return;
                }
                
                var curval = fdele.val();
                var curid = fdele.attr("id");
                
                if(parseInt(curval)>=100){
                    fdele.val(100); //current box 100 percent
                    $("#dlrcut_del").val(0); //delivered zero percent
                    if(curid=='dlrcut_undel') $("#dlrcut_exp").val(0); else $("#dlrcut_undel").val(0); //remaining zero percent
                }else{
                    var total = (parseInt($("#dlrcut_undel").val()) || 0)+ (parseInt($("#dlrcut_exp").val()) || 0);
                    if(total>100){
                        bootbox.alert(SCTEXT('Total must not exceed 100%.'));
                        fdele.val(0);
                    
                    }else{
                        $("#dlrcut_del").val(100-total); //delivered should be whatever percentage left
                    }
                    
                }
                
            })
            
            
        });
        
        //save settings
        $(".save_settings").each(function(){
            $(this).on("click", function(){
                var ele = $(this);
                 var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving App Settings')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#"+ele.attr("data-form")).attr('action',app_url+'saveAppSettings');
                                $("#"+ele.attr("data-form")).submit();
                                }, 100);
                            }); 
        
            })
            
        })
        
        //main settings
        
        //date time default selection
        $("#timezone option").each(function(){
					if( $(this).val()==$("#deftz").val()){
					$(this).attr('selected','selected');	
					}
					});
        $("#timezone").trigger("change.select2");
        
        
        //date format examples
        $(".datefrmt").each(function(){
            var ele = $(this);
            ele.on("change keyup focus blur",function(){
                $.ajax({
                    url: app_url+'generateDateExample',
                    type: 'post',
                    data: {dtype:ele.val()},
                    success: function(res){
                        ele.next().html(res);
                    }
                })
            })
        })
        
    }
    
    
//48. Power Grid
    if(curpage=='power_grid'){
        
        //pause all processes
        $("#pauseallprocs").click(function(){
            bootbox.confirm({
                    message: SCTEXT("This is a very critical decision. All the background processes will be PAUSED. You will need to manually start each process again for proper functioning of the app. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'setProcessStatus',
                                method: 'post',
                                data: {
                                    mode: 'ALL'
                                },
                                success: function(res){
                                    window.location.reload(true); //true will reload with page scrolled at top
                                }
                            })
                            }
                        }
                    });
        });
        
        //process status switcher
        $(".procSwitch").on("change", function(){
            var pid = $(this).attr('data-proc');
            var st = $(this).is(':checked')?1:0;
            //ajax call
            $.ajax({
                url: app_url+'setProcessStatus',
                method: 'post',
                data: {
                    pid: pid,
                    status: st
                },
                success: function(res){
                          bootbox.alert(res);  
                        }
            })
            
        })
        
        //maintenance mode
        $("#mm-y, #mm-n").click(function(){
            var sel = $(this).val();
            if(sel=='1'){
                $("#mm-opts").removeClass('disabledBox');
            }else{
                $("#mm-opts").addClass('disabledBox');
            }
        });
        //datetime picker for mm mode
        $("#mmdp").datetimepicker({ minDate: moment(), showClose: true, icons: { close: 'fa-times-circle m-t-xs m-b-xs label-info label label-flat label-md'}, sideBySide: true, toolbarPlacement: 'bottom', format:'ddd, Do MMM YYYY HH:mm' });
        if($("#deftime").val()!='') $("#mmdp").val($("#deftime").val());
        //submit mm data
            $("#submit_mm").on("click", function(){
                var ele = $(this);
                 var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#mm_form").attr('action',app_url+'saveMiscVars');
                                $("#mm_form").submit();
                                }, 100);
                            }); 
        
            })
            
        //archive date picker
            $("#archdp").datetimepicker({ maxDate: moment(),  showClose: true, format:'ddd, Do MMM YYYY' });
        //submit archive task
            $("#submit_arch").on("click", function(){
                var ele = $(this);
                 var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Adding Archive Task')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#arch_form").attr('action',app_url+'addArchiveTask');
                                $("#arch_form").submit();
                                }, 100);
                            }); 
        
            })
            
        //cancel archive task    
            $("#cancelAT").on("click", function(){
                var tid = $(this).attr('data-tid');
                bootbox.confirm({
                    message: SCTEXT("Are you sure you want to cancel this task?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'cancelArchiveTask',
                                method: 'post',
                                data: {
                                    tid: tid
                                },
                                success: function(res){
                                    window.location.reload(true); //true will reload with page scrolled at top
                                }
                            })
                            }
                        }
                    });
            });
        
        
    }
    
//49. Watchman Log
    
    if(curpage=='watchman_log'){
        //datepicker
        $('#wml-dp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#wml-dp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload table
            $('#t-wmlog').dataTable().api().ajax.url(app_url+"getWatchmanLog/"+$('#wml-dp span').html()).load();
            
        });
        //Set the initial state of the picker label
         $('#wml-dp span').html('Select Date');
    }
    
    
//49. DB Archive Log
    
    if(curpage=='dbarchive_log'){
        //datepicker
        $('#dal-dp').daterangepicker({
            ranges: {
                'Today': ['today', 'today'],
                'Yesterday': ['yesterday', 'yesterday'],
                'Last 7 Days': [Date.today().add({
                    days: -6
                }), 'today'],
                'Last 30 Days': [Date.today().add({
                    days: -29
                }), 'today'],
                'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                    months: -1
                }), Date.today().moveToFirstDayOfMonth().add({
                    days: -1
                })]
            },
            opens: 'left',
            format: 'MM/dd/yyyy',
            separator: ' to ',
            startDate: Date.today().add({
                days: -29
            }),
            endDate: Date.today(),
            minDate: '01/01/2012',
            maxDate: '12/31/2020',
            locale: {
                applyLabel: 'Apply',
                clearLabel: 'Cancel',
                customRangeLabel: 'Custom Range',
                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                firstDay: 1
            },
            showWeekNumbers: true,
            buttonClasses: ['btn-danger']
        },
        function (start, end) {
            $('#dal-dp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
			//reload table
            $('#t-dalog').dataTable().api().ajax.url(app_url+"getDbArchiveLog/"+$('#dal-dp span').html()).load();
            
        });
        //Set the initial state of the picker label
         $('#dal-dp span').html('Select Date');
    }    
    
//50. Website Leads
    
    if(curpage=='webleads'){
        //filter results
        $("#dt_leadfilter").click(function(){
            //get selected option and reload
            $('#dt_web_leads').dataTable().api().ajax.url(app_url+"getWebsiteLeads/"+$('#leadfilter option:selected').val()).load();
            
        });
    }
    
    
//51. Security Log
    if(curpage=='security_log'){
        //datepicker
        $('#secl-dp').daterangepicker({
                ranges: {
                    'Today': ['today', 'today'],
                    'Yesterday': ['yesterday', 'yesterday'],
                    'Last 7 Days': [Date.today().add({
                        days: -6
                    }), 'today'],
                    'Last 30 Days': [Date.today().add({
                        days: -29
                    }), 'today'],
                    'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                    'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                        months: -1
                    }), Date.today().moveToFirstDayOfMonth().add({
                        days: -1
                    })]
                },
                opens: 'left',
                format: 'MM/dd/yyyy',
                separator: ' to ',
                startDate: Date.today().add({
                    days: -29
                }),
                endDate: Date.today(),
                minDate: '01/01/2012',
                maxDate: '12/31/2020',
                locale: {
                    applyLabel: 'Apply',
                    clearLabel: 'Cancel',
                    customRangeLabel: 'Custom Range',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                    monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    firstDay: 1
                },
                showWeekNumbers: true,
                buttonClasses: ['btn-danger']
            },
            function (start, end) {
                $('#secl-dp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
                //reload table
                $('#t-seclog').dataTable().api().ajax.url(app_url+"getSusActivityLog/"+$('#secl-dp span').html()).load();

            });
        
    }
    
//52. Blocked IP List
    
    if(curpage=='blocked_ip_list'){
        //datepicker
        $('#blip-dp').daterangepicker({
                ranges: {
                    'Today': ['today', 'today'],
                    'Yesterday': ['yesterday', 'yesterday'],
                    'Last 7 Days': [Date.today().add({
                        days: -6
                    }), 'today'],
                    'Last 30 Days': [Date.today().add({
                        days: -29
                    }), 'today'],
                    'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
                    'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                        months: -1
                    }), Date.today().moveToFirstDayOfMonth().add({
                        days: -1
                    })]
                },
                opens: 'left',
                format: 'MM/dd/yyyy',
                separator: ' to ',
                startDate: Date.today().add({
                    days: -29
                }),
                endDate: Date.today(),
                minDate: '01/01/2012',
                maxDate: '12/31/2020',
                locale: {
                    applyLabel: 'Apply',
                    clearLabel: 'Cancel',
                    customRangeLabel: 'Custom Range',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                    monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    firstDay: 1
                },
                showWeekNumbers: true,
                buttonClasses: ['btn-danger']
            },
            function (start, end) {
                $('#blip-dp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
                //reload table
                $('#t-blip').dataTable().api().ajax.url(app_url+"getBlockedIpList/"+$('#blip-dp span').html()).load();

            });
    }
    

//53. Phonebook database
    
    if(curpage=='manage_pbdb'){
        //toggle status
        $(document).on("change",'.pbdbstatus', function(){
            var val=0;
				if($(this).is(':checked')){
					
					val = '1';
				}
				var gid = $(this).val();
				$.ajax({
					method:'post',
					url: app_url+'setPhonebookStatus',
					data: {value:val,gid:gid}
					});
        });
        //action
        $(document).on("click",".delpbdb",function(){
            var gid = $(this).attr('data-gid');
            var gcount = $(this).attr('data-gcount');
            bootbox.confirm({
                    message: SCTEXT("Deleting this group will remove this from Phonebook list for all clients and will delete all the contacts present in this group. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location = app_url+'deletePhonebookDb/'+gid;
                            }
                        }
                    }); 
        })
    }
    
    if(curpage=='add_pbdb' || curpage=='edit_pbdb'){
        //submit
        $("#save_changes").on("click", function(){
                
                 var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Phonebook Name')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},300)
                            setTimeout(function(){
                                $("#add_pbdb_form").attr('action',app_url+'savePhonebookDb');
                                $("#add_pbdb_form").submit();
                                }, 100);
                            }); 
        
            });
        
        $("#bk").click(function(){
				window.location = app_url+'phonebook';
			});
        
    }
    
    
    if(curpage=='add_pbcontacts'){
        //submit
        $("#save_changes").click(function(){
            
            
            //check if any upload is in progress
            if($("#uprocess").val()==1){
                bootbox.alert(SCTEXT('File upload is in progress. Kindly wait for upload to finish or Cancel Upload & proceed.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Importing Contacts. This may take a while. Please wait')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#pbct_form").attr('action',app_url+'savePhonebookContacts');
                                $("#pbct_form").submit();
                                }, 50);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'viewPhonebookContacts/'+$("#pbdbid").val();
        });
    }
    
    if(curpage=='edit_pbcontact'){
        $("#save_changes").click(function(){
            
            //check if any upload is in progress
            if($("#pbcontact").val()=='' || !isValidPhone($("#pbcontact").val())){
                bootbox.alert(SCTEXT('Invalid mobile number provided. Please try again.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving Contact')} . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#edit_pbct_form").attr('action',app_url+'savePhonebookContacts');
                                $("#edit_pbct_form").submit();
                                }, 50);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'viewPhonebookContacts/'+$("#gid").val();
        });
    }
    
    
//54. Short URL
    
    if(curpage=='manage_tinyurl'){
        $(document).on("click",".del-surl",function(){
            var urlid = $(this).attr('data-urlid');
             bootbox.confirm({
                    message: SCTEXT("This action will stop redirecting this short URL. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            window.location = app_url+'deleteShortUrl/'+urlid;
                            }
                        }
                    }); 
        })
    }
    
    if(curpage=='add_tinyurl'){
        //change type
        $("#urltype").on("change", function(){
            var desc = $("#urltype option:selected").attr("data-subtext");
            $("#urltype_desc").text(desc);
        });
        
        $("#save_changes").click(function(){
            
            //check 
            if($("#redurl").val()==''){
                bootbox.alert(SCTEXT('Destination URL cannot be empty.'));
                return;
            }
                
             var dialog = bootbox.dialog({
                                closeButton: false,
                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Generating Short URL')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                            });   
                    dialog.init(function(){
                            $("#stbar").animate({width:"100%"},500)
                            setTimeout(function(){
                                $("#turl_form").attr('action',app_url+'generateShortUrl');
                                $("#turl_form").submit();
                                }, 50);
                            }); 
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageShortUrls';
        });
    }
    
//55. SSL Management
    
    if(curpage=='manage_ssl'){
        
        $(document).on("click",".removeSSL",function(){
            var domain = $(this).attr('data-dom');
            bootbox.confirm({
                    message: SCTEXT("You are removing SSL for this user. All domains associated with this SSL will no longer have secure access. Are you sure you want to proceed?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //ask for password
                            bootbox.prompt({
                                    title: SCTEXT("Please enter server root SSH password"),
                                    inputType: 'password',
                                    callback: function (pass) {
                                        if(pass){
                                           var dialog = bootbox.dialog({
                                                    message: `<p class="text-center"><i class="fa fa-large fa-spin fa-circle-o-notch"></i>&nbsp;&nbsp;${SCTEXT('Connecting to server. Please wait')} . . .</p>`,
                                                    size: 'small',
                                                    closeButton: false
                                                });
                                        //send password and perform action
                                            $.ajax({
                                                    url: app_url+'sshTestConnection',
                                                    method: 'post',
                                                    data:{
                                                        rpass: pass
                                                    },
                                                    success: function(res){

                                                        if(res=='OK'){
                                                            //--begin
                                                            var dialog = bootbox.dialog({
                                                                closeButton: false,
                                                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Removing SSL. This may take a few minutes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                                                            });   
                                                            dialog.init(function(){
                                                                $("#stbar").animate({width:"100%"},20000)
                                                                setTimeout(function(){
                                                                     window.location = app_url+'removeSSL/'+domain;
                                                                    }, 50);
                                                            });
                                                            //--end
                                                        }else{
                                                            location.reload();
                                                        }

                                                    }
                                                });
                                        }



                                    }
                                });
                            //end of ssl uninstall confirm
                            }
                        }
                    });
        })
    }
    
    if(curpage=='add_ssl'){
        
        $("#domresfil").on("change",function(){
            
            var domstr = $("#domresfil option:selected").attr("data-doms");
            var domar = domstr.split(",");
            var domstr = '';
            for (var i=0; i<domar.length;i++){
                domstr += '<div class="checkbox checkbox-success"><input name="seldoms[]" value="'+domar[i]+'" type="checkbox" id="cb-'+i+'" checked="checked"><label for="cb-'+i+'">'+domar[i]+'</label></div>'
            }
            $("#domainctr").html(domstr);
        })
        
        //submit form
        $("#save_changes").click(function(){
            
            bootbox.prompt({
                    title: SCTEXT("Please enter server root SSH password"),
                    inputType: 'password',
                    callback: function (pass) {
                        if(pass){
                           var dialog = bootbox.dialog({
                                    message: `<p class="text-center"><i class="fa fa-large fa-spin fa-circle-o-notch"></i>&nbsp;&nbsp;${SCTEXT('Connecting to server. Please wait')} . . .</p>`,
                                    size: 'small',
                                    closeButton: false
                                });
                        //send password and perform action
                            $.ajax({
                                    url: app_url+'sshTestConnection',
                                    method: 'post',
                                    data:{
                                        rpass: pass
                                    },
                                    success: function(res){
                                        
                                        if(res=='OK'){
                                            //--begin
                                            var dialog = bootbox.dialog({
                                                closeButton: false,
                                                message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Installing SSL. This may take a few minutes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                                            });   
                                            dialog.init(function(){
                                                $("#stbar").animate({width:"100%"},20000)
                                                setTimeout(function(){
                                                    $("#add_ssl_form").attr('action',app_url+'installNewSSL');
                                                    $("#add_ssl_form").submit();
                                                    }, 50);
                                            });
                                            //--end
                                        }else{
                                            location.reload();
                                        }
                                        
                                    }
                                });
                        }
                        
                             
                        
                    }
                });   
                
              
        });
        //bk
        $("#bk").click(function(){
             window.location = app_url+'manageSSL';
        });
        
    }
    
    
//------------------- 2-WAY Messaging ------------------------//

if(curpage=='inbox'){
    $("#vmnsel").on("change",function(){
        $('#dt_mosms').dataTable().api().ajax.url(app_url+"getAllIncomingSms/"+$("#vmnsel").val()+'/'+$('#inboxdp span').html()).load();
    })
    
    //date pkr dlr
    $('#inboxdp').daterangepicker({
        ranges: {
            'Today': ['today', 'today'],
            'Yesterday': ['yesterday', 'yesterday'],
            'Last 7 Days': [Date.today().add({
                days: -6
            }), 'today'],
            'Last 30 Days': [Date.today().add({
                days: -29
            }), 'today'],
            'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
            'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                months: -1
            }), Date.today().moveToFirstDayOfMonth().add({
                days: -1
            })]
        },
        opens: 'left',
        format: 'MM/dd/yyyy',
        separator: ' to ',
        startDate: Date.today().add({
            days: -29
        }),
        endDate: Date.today(),
        minDate: '01/01/2012',
        maxDate: '12/31/2020',
        locale: {
            applyLabel: 'Apply',
            clearLabel: 'Cancel',
            customRangeLabel: 'Custom Range',
            daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
            monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            firstDay: 1
        },
        showWeekNumbers: true,
        buttonClasses: ['btn-danger']
    },
    function (start, end) {
        $('#inboxdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
        //reload table
        var campaignid = $("#campsel").val() || 0;
        $('#dt_mosms').dataTable().api().ajax.url(app_url+"getAllIncomingSms/"+$("#vmnsel").val()+'/'+$('#inboxdp span').html()).load();
        
    });
    //Set the initial state of the picker label
     $('#inboxdp span').html('Select Date');

     $(document).on("click",".del-mo",function(){
        var sid = $(this).attr('data-moid');
        bootbox.confirm({
            message: SCTEXT("Are you sure you want to delete this SMS?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = app_url+'deleteIncomingSms/'+sid;
                    }
                }
            }); 
    })
}

if(curpage=='view_mo'){
    $(document).on("click",".del-mo",function(){
        var sid = $(this).attr('data-moid');
        bootbox.confirm({
            message: SCTEXT("Are you sure you want to delete this SMS?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = app_url+'deleteIncomingSms/'+sid;
                    }
                }
            }); 
    })
}

if(curpage=='manage_vmn'){
    //delete vmn
    $(document).on("click",".del-vmn",function(){
        var vid = $(this).attr('data-vmnid');
        bootbox.confirm({
            message: SCTEXT("Please make sure this VMN is not assigned to any user and no Keywords in the system are associated with this number. Are you sure you want to proceed?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = app_url+'deleteVmn/'+vid;
                    }
                }
            }); 
    })
}

if(curpage=='add_vmn' || curpage=='edit_vmn'){
    //switch vmn type explanations
    $("#vmntype").on("change",function(){
        $("#vtypestr").text($("#vmntype option:selected").attr("data-title"));
    })
    //switch sender id selector
    $("#rsmpp").on("change",function(){
        var rtele = $("#rsmpp option:selected");
        
        // sender id box type, default sender id and max allowed length
            var stype = parseInt(rtele.attr('data-stype'));
            if(stype==0){
                //approval based sender id
                $("#sidselbox").removeClass('hidden');
                $("#sidopnbox").addClass('hidden');
            }
            if(stype==1){
                //sender id not allowed
                $("#sidselbox").addClass('hidden');
                $("#sidopnbox").addClass('hidden');
            }
            if(stype==2){
                //open sender id allowed
                $("#sidselbox").addClass('hidden');
                $("#sidopnbox").removeClass('hidden');
            }
    });
    $("#rsmpp").trigger("change");
    $("#vmntype").trigger("change");
    //submit
    $("#save_changes").click(function(){
            
        //check 
        if($("#vmn").val()==''){
            bootbox.alert(SCTEXT('Virtual mobile number cannot be empty.'));
            return;
        }
            
         var dialog = bootbox.dialog({
                            closeButton: false,
                            message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                        });   
                dialog.init(function(){
                        $("#stbar").animate({width:"100%"},500)
                        setTimeout(function(){
                            $("#vmnfrm").attr('action',app_url+'saveVmn');
                            $("#vmnfrm").submit();
                            }, 50);
                        }); 
    });
    //bk
    $("#bk").click(function(){
         window.location = app_url+'manageVmn';
    });
}     

if(curpage=='manage_kw'){
    $(document).on("click",".del-kw",function(){
        var kid = $(this).attr('data-kid');
        bootbox.confirm({
            message: SCTEXT("Incoming SMS with this keyword will not be matched. Are you sure you want to proceed?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = app_url+'deleteKeyword/'+kid;
                    }
                }
            }); 
    })
}

if(curpage=='add_kw' || curpage=='edit_kw'){
    
    //submit
    $("#save_changes").click(function(){
            
        //check 
        if($("#keyword").val()==''){
            bootbox.alert(SCTEXT('Primary keyword cannot be empty.'));
            return;
        }
        if($("#fwdmob").val()!='' && isValidPhone($("#fwdmob").val())==false){
            bootbox.alert(SCTEXT('Please enter a valid mobile number with country prefix.'));
            return;
        }
            
         var dialog = bootbox.dialog({
                            closeButton: false,
                            message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                        });   
                dialog.init(function(){
                        $("#stbar").animate({width:"100%"},500)
                        setTimeout(function(){
                            $("#kwfrm").attr('action',app_url+'saveKeyword');
                            $("#kwfrm").submit();
                            }, 50);
                        }); 
    });
    //bk
    $("#bk").click(function(){
         window.location = app_url+'manageKeywords';
    });
} 

if(curpage=='manage_cmpns'){
    $(document).on("click",".del-cmpn",function(){
        var cid = $(this).attr('data-cid');
        bootbox.confirm({
            message: SCTEXT("Please save all the opt-in and opt-out data from this campaign as they will also be deleted permanently with this campaign. Are you sure you want to delete this campaign?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = app_url+'deleteCampaign/'+cid;
                    }
                }
            }); 
    })
}

if(curpage=='add_cmpn' || curpage=='edit_cmpn'){
    //switch optin availability based on keyword selection
    $("#pkeyword").on("change",function(){
        if($("#pkeyword option:selected").val()==0){
            //disable 
            $("#optset").addClass("disabledBox");
        }else{
            //enable
            $("#optset").removeClass("disabledBox");
        }
    })
    //switch sender id selector
    $("#rsmpp").on("change",function(){
        var rtele = $("#rsmpp option:selected");
        
        // sender id box type, default sender id and max allowed length
            var stype = parseInt(rtele.attr('data-stype'));
            if(stype==0){
                //approval based sender id
                $("#sidselbox").removeClass('hidden');
                $("#sidopnbox").addClass('hidden');
            }
            if(stype==1){
                //sender id not allowed
                $("#sidselbox").addClass('hidden');
                $("#sidopnbox").addClass('hidden');
            }
            if(stype==2){
                //open sender id allowed
                $("#sidselbox").addClass('hidden');
                $("#sidopnbox").removeClass('hidden');
            }
    });
    $("#rsmpp").trigger("change");
    $("#pkeyword").trigger("change");
    //submit
    $("#save_changes").click(function(){
            
        //check 
        if($("#cname").val()==''){
            bootbox.alert(SCTEXT('Campaign name cannot be empty.'));
            return;
        }
            
         var dialog = bootbox.dialog({
                            closeButton: false,
                            message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                        });   
                dialog.init(function(){
                        $("#stbar").animate({width:"100%"},500)
                        setTimeout(function(){
                            $("#cmpn_form").attr('action',app_url+'saveCampaign');
                            $("#cmpn_form").submit();
                            }, 50);
                        }); 
    });
    //bk
    $("#bk").click(function(){
         window.location = app_url+'campaigns';
    });
}

if(curpage=='cmpn_optin'){
    $(document).on("click",".del-num",function(){
        var cid = $(this).attr('data-nid');
        bootbox.confirm({
            message: SCTEXT("Are you sure you want to delete this optin number?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = app_url+'deleteOptinNumber/'+cid;
                    }
                }
            }); 
    })
}

if(curpage=='cmpn_optout'){
    $(document).on("click",".del-num",function(){
        var cid = $(this).attr('data-nid');
        bootbox.confirm({
            message: SCTEXT("Are you sure you want to delete this optout number?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = app_url+'deleteOptoutNumber/'+cid;
                    }
                }
            }); 
    })
}
    

/* -------------------- SMPP OUTBOUND API ---------------------*/

if(curpage=='add_smppclient' || curpage=='edit_smppclient'){
    let errsystemid = 0;
    let errmsg = '';
    //validate system id
    $("#smpp_sysid").on("keyup blur",function(){
        let lid = $(this).val();
        $("#v-login").html('<i class="fa fa-lg fa-circle-o-notch fa-spin"></i>');
        if(lid.indexOf(' ') >= 0 || lid.length<5){
            $("#v-login").html('<i class="fa fa-lg fa-times text-danger"></i>');
            errsystemid=1;
            errmsg = SCTEXT('Invalid System ID. Must be at least 5 characters without spaces.');
        }else{
            $("#v-login").html('<i class="fa fa-lg fa-check text-success"></i>');
            errsystemid=0;
            errmsg = '';
            //verify
            $.ajax({
            url: app_url+'checkAvailability',
            method: 'post',   
            data: {mode: 'systemid', value: lid},
            success: function(res){
                    if(res=='FALSE'){
                        $("#v-login").html('<i class="fa fa-lg fa-times text-danger"></i>');
                        errsystemid=1;
                        errmsg = SCTEXT('System ID already exists. Please enter a different System ID.');
                    }else{
                        $("#v-login").html('<i class="fa fa-lg fa-check text-success"></i>');
                        errsystemid=0;
                        errmsg = '';
                        
                    }
                }
            });
        }
        
    });

    //save changes
    $("#save_changes").click(function(){
            
        //check 
        if(errsystemid==1){
            bootbox.alert(errmsg);
            return;
        }
            
         var dialog = bootbox.dialog({
                            closeButton: false,
                            message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                        });   
                dialog.init(function(){
                        $("#stbar").animate({width:"100%"},500)
                        setTimeout(function(){
                            $("#smppclient_frm").attr('action',app_url+'saveSmppClient');
                            $("#smppclient_frm").submit();
                            }, 50);
                        }); 
    });

    //back to settings
    $("#bk").click(function(){
        window.location = `${app_url}viewUserAccountSettings/${$("#userid").val()}`;
    });
}

    
if(curpage=='smppsms'){

    //show pdu data
    $(document).on("click",".vsubmit_sm", function(){
        let pdata = $(this).attr('data-submitsm');
        if(pdata==''){
            bootbox.alert('No PDU Formed');
        }else{
            bootbox.alert(`<pre>${JSON.stringify(JSON.parse((atob(pdata))).pdu,null,"\t")}</pre>`);
        }
        
    })
    $(document).on("click",".vdel_pdu", function(){
        let delpdu = $(this).attr('data-delsm');
        let delpdures = $(this).attr('data-delsmres');
        let smtime = $(this).attr('data-smtime');
        let smrestime = $(this).attr('data-smrestime');
        if(delpdu==''){
            bootbox.alert('No Deliver_sm PDU Sent yet');
        }else{
            let pdustr = `<span class="label label-primary">DELIVER_SM sent on ${smtime}</span><br>`;
            pdustr += `<pre>${JSON.stringify(JSON.parse((atob(delpdu))),null,"\t")}`;
            if(delpdures!=''){
                pdustr += `</pre><br><span class="label label-primary">DELIVER_SM_RESP received on ${smrestime}</span><br>`;
                pdustr += `<pre>${JSON.stringify(JSON.parse((atob(delpdures))),null,"\t")}</pre>`;
            }else{
                pdustr += `</pre><br><span class="label label-danger">No Acknowledgement (DELIVER_SM_RESP) Received</span>`;
            }
            bootbox.alert(pdustr);
        }
        
    })

    //download filetered results
    $("#smppdl").on("click", () => {
        let data = {
            clientid: $("#smppdl").attr('data-sid'),
            daterange: $('#smsdp span').html()
        }
        window.open(`${app_url}globalFileDownload/smppsms/${btoa(JSON.stringify(data))}`, '_blank');
    })

    //date pkr dlr
    $('#smsdp').daterangepicker({
        ranges: {
            'Today': ['today', 'today'],
            'Yesterday': ['yesterday', 'yesterday'],
            'Last 7 Days': [Date.today().add({
                days: -6
            }), 'today'],
            'Last 30 Days': [Date.today().add({
                days: -29
            }), 'today'],
            'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
            'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                months: -1
            }), Date.today().moveToFirstDayOfMonth().add({
                days: -1
            })]
        },
        opens: 'left',
        format: 'MM/dd/yyyy',
        separator: ' to ',
        startDate: Date.today().add({
            days: -29
        }),
        endDate: Date.today(),
        minDate: '01/01/2012',
        maxDate: '12/31/2020',
        locale: {
            applyLabel: 'Apply',
            clearLabel: 'Cancel',
            customRangeLabel: 'Custom Range',
            daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
            monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            firstDay: 1
        },
        showWeekNumbers: true,
        buttonClasses: ['btn-danger']
    },
    function (start, end) {
        $('#smsdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
        //reload table
        let systemid = $("#systemid").val();
        $('#t-smppsms').dataTable().api().ajax.url(`${app_url}getSmppSmsList/${systemid}/${$('#smsdp span').html()}`).load();
        
    });
    //Set the initial state of the picker label
     $('#smsdp span').html('Select Date');
}    
    
if(curpage=='route_price'){
    $("#cvsel").on("change",function(){
        $('#dt-routes-def-price').dataTable().api().ajax.url(app_url+"getRouteDefaultPrice/"+$("#routeid").val()+'/'+$('#cvsel').val()).load();
    })
}

if(curpage=='edit_route_price'){
    //save changes
    $("#save_changes").click(function(){
        
         var dialog = bootbox.dialog({
                            closeButton: false,
                            message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                        });   
                dialog.init(function(){
                        $("#stbar").animate({width:"100%"},500)
                        setTimeout(function(){
                            $("#rprc_form").attr('action',app_url+'saveRoutePrice');
                            $("#rprc_form").submit();
                            }, 50);
                        }); 
    });

    //back to settings
    $("#bk").click(function(){
        window.location = `${app_url}gatewayCostPrice/${$("#routeid").val()}`;
    });
}

if(curpage=='upload_route_price'){
    //save changes
    $("#save_changes").click(function(){
        
         var dialog = bootbox.dialog({
                            closeButton: false,
                            message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Importing Data')} This may take few minutes. . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                        });   
                dialog.init(function(){
                        $("#stbar").animate({width:"100%"},2000)
                        setTimeout(function(){
                            $("#upload_rprc_form").attr('action',app_url+'importRoutePrice');
                            $("#upload_rprc_form").submit();
                            }, 5);
                        }); 
    });

    //back to settings
    $("#bk").click(function(){
        window.location = `${app_url}gatewayCostPrice/${$("#routeid").val()}`;
    });
}

if(curpage=='add_mplan' || curpage=='edit_mplan'){
    //save changes
    $("#save_changes").click(function(){
        
        var dialog = bootbox.dialog({
                           closeButton: false,
                           message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                       });   
               dialog.init(function(){
                       $("#stbar").animate({width:"100%"},500)
                       setTimeout(function(){
                           $("#mplanfrm").attr('action',app_url+'saveMccmncPlan');
                           $("#mplanfrm").submit();
                           }, 50);
                       }); 
   });

   //back to settings
   $("#bk").click(function(){
       window.location = `${app_url}mccmncRatePlans`;
   });
}

if(curpage=='mccmnc_plans'){
    $(document).on("click",".delmplan",function(){
        let pid = $(this).attr('data-pid');
        let ucount = $(this).attr('data-ucount');
        if(ucount!='0'){
            bootbox.alert('There are user accounts associated with this plan. Please assign them different MCC/MNC based SMS Plan before removing this plan.');
            return;
        }
        bootbox.confirm({
            message: SCTEXT("All the pricing information will also be deleted. Are you sure you want to delete this SMS Plan?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = app_url+'deleteMccmncSmsPlan/'+pid;
                    }
                }
            }); 
    })
}

if(curpage=='mplan_route_prices'){
    //reload after route selection
    $("#rsel").on("change", function(){
        let routeid = $(this).val();
        let planid = $("#planid").val();
        //reload
        window.location = `${app_url}setMccmncPricing/${planid}/${routeid}`;
    })

    //save pricing
    $(".savepricing").on("click", function(){
        let ele = $(this);
        ele.addClass('disabledBox').html('<i class="fas fa-lg fa-spin fa-circle-notch"></i>');
        let planid = ele.attr('data-planid');
        let mccmnc = ele.attr('data-mccmnc');
        let routeid = ele.attr('data-routeid');
        let costprc = ele.attr('data-rcp');
        let inputid = `${mccmnc}-planprice`;
        let price = parseFloat($(`#${inputid}`).val()) || 0;

        if(price < parseFloat(costprc)){
            bootbox.alert(`Selling price cannot be lower than cost price. Please don't sell at a loss.`);
            ele.removeClass('disabledBox').html('<i class="fa fa-large fa-check"></i>');
            return;
        }

        //save 
        $.ajax({
            url: app_url+'saveMccMncPlanPrice',
            method: 'post',
            data: {
                planid: planid,
                mccmnc: mccmnc,
                routeid: routeid,
                price: price
            },
            success: function(res){
                bootbox.alert(`Pricing Saved Successfully`);
                ele.removeClass('disabledBox').html('<i class="fa fa-large fa-check"></i>');
                return;
            }
        })
        
    })

    //remove pricing
    $(".delpricing").on("click", function(){
        let ele = $(this);
        ele.addClass('disabledBox').html('<i class="fas fa-lg fa-spin fa-circle-notch"></i>');
        let planid = ele.attr('data-planid');
        let mccmnc = ele.attr('data-mccmnc');
        let routeid = ele.attr('data-routeid');
        bootbox.confirm({
            message: SCTEXT("Are you sure you want to delete pricing for this MCC/MNC?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    $.ajax({
                        url: app_url+'removeMccMncPlanPrice',
                        method: 'post',
                        data: {
                            planid: planid,
                            mccmnc: mccmnc,
                            routeid: routeid
                        },
                        success: function(res){
                                bootbox.alert(`Pricing Removed Successfully`);
                                ele.removeClass('disabledBox').html('<i class="fa fa-large fa-trash"></i>');
                                let inputid = `${mccmnc}-planprice`;
                                $(`#${inputid}`).val('');
                                return;
                            }
                        })
                    }else{
                        ele.removeClass('disabledBox').html('<i class="fa fa-large fa-trash"></i>');
                    }
                }
            }); 
    })
}

if(curpage=='hlrset'){
    $(document).on("click",".delhlrchn",function(){
        let cid = $(this).attr('data-cid');
        bootbox.confirm({
            message: SCTEXT("Are you sure you want to delete this HLR API channel?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = `${app_url}deleteHlrApi/${cid}`;
                    }
                }
            }); 
    })
}

if(curpage=='add_hlr' || curpage=='edit_hlr'){
    $("#prsel").on("change", function(){
        let ele = $("#prsel option:selected");
        let method = ele.attr('data-method');
        if(ele.val()==''){
            $("#hlrdesc").html('Select a provider for more information');
        }else{
            let desc = `This HLR lookup API is provided by <span class="label label-success text-white">${ele.attr('data-website')}</span>. Make sure you have an account with them and provide the authentication details below.`;
            if(ele.attr('data-async')=='async'){
                desc += ` This API uses asynchronous callback to update HLR lookup. Hence reports are updated by a callback URL to our servers. Please configure following callback URL in SETTINGS section of your HLR provider's panel.<br><kbd>${app_url}hlrApiCallback/${ele.val()}/index</kbd>`;
            }
            if(method=='httpauth'){
                $("#apiparam_httpauth").removeClass('hidden');
                $("#apiparam_getpost").addClass('hidden');
            }else{
                $("#apiparam_httpauth").addClass('hidden');
                $("#apiparam_getpost").removeClass('hidden');
            }
            $("#hlrdesc").html(desc);
        }
        
    });
    $("#prsel").trigger('change');
    //save changes
    $("#save_changes").click(function(){

        if($("#prsel").val()==undefined || $("#prsel").val()==''){
            bootbox.alert('Please select a provider for HLR lookup channel.');
            return;
        }
        
        var dialog = bootbox.dialog({
                           closeButton: false,
                           message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Saving changes')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                       });   
               dialog.init(function(){
                       $("#stbar").animate({width:"100%"},500)
                       setTimeout(function(){
                           $("#hlrcfrm").attr('action',app_url+'saveHlrApi');
                           $("#hlrcfrm").submit();
                           }, 50);
                       }); 
   });

   //back to settings
   $("#bk").click(function(){
       window.location = `${app_url}manageHlr`;
   });
}
    
if(curpage=='newhlrlookup'){
    //submit
    $("#save_changes").click(function(){

        if($("#contactinput").val()==''){
            bootbox.alert('Please enter mobile numbers to perform HLR lookup.');
            return;
        }
        
        var dialog = bootbox.dialog({
                           closeButton: false,
                           message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Submitting Lookup Request')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                       });   
               dialog.init(function(){
                       $("#stbar").animate({width:"100%"},500)
                       setTimeout(function(){
                           $("#hlr_form").attr('action',app_url+'submitHlrLookup');
                           $("#hlr_form").submit();
                           }, 50);
                       }); 
   });

   //back to settings
   $("#bk").click(function(){
       window.location = `${app_url}viewHlrReports`;
   });
}

if(curpage=='hlrreports'){
    //show response
    $(document).on("click",".showHlrData", function(){
        let hdata = $(this).attr('data-rinfo');
        bootbox.alert(`<pre>${JSON.stringify(JSON.parse((atob(hdata))),null,"\t")}</pre>`);
    })
    //date filter
    $('#hlrdp').daterangepicker({
        ranges: {
            'Today': ['today', 'today'],
            'Yesterday': ['yesterday', 'yesterday'],
            'Last 7 Days': [Date.today().add({
                days: -6
            }), 'today'],
            'Last 30 Days': [Date.today().add({
                days: -29
            }), 'today'],
            'This Month': [Date.today().moveToFirstDayOfMonth(), Date.today().moveToLastDayOfMonth()],
            'Last Month': [Date.today().moveToFirstDayOfMonth().add({
                months: -1
            }), Date.today().moveToFirstDayOfMonth().add({
                days: -1
            })]
        },
        opens: 'left',
        format: 'MM/dd/yyyy',
        separator: ' to ',
        startDate: Date.today().add({
            days: -29
        }),
        endDate: Date.today(),
        minDate: '01/01/2012',
        maxDate: '12/31/2020',
        locale: {
            applyLabel: 'Apply',
            clearLabel: 'Cancel',
            customRangeLabel: 'Custom Range',
            daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
            monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            firstDay: 1
        },
        showWeekNumbers: true,
        buttonClasses: ['btn-danger']
    },
    function (start, end) {
        $('#hlrdp span').html(start.toString('MMM d, yyyy') + ' - ' + end.toString('MMM d, yyyy'));
        //reload table
        var campaignid = $("#campsel").val() || 0;
        $('#t-hlrreports').dataTable().api().ajax.url(app_url+"getHlrReports/"+$('#hlrdp span').html()).load();
        
    });
    //Set the initial state of the picker label
     $('#hlrdp span').html('Select Date');
}

if(curpage=='manage_orules'){
    $(document).on("click",".delovrl",function(){
        let rid = $(this).attr("data-rid");
        bootbox.confirm({
            message: SCTEXT("Are you sure you want to delete this Override Rule?"),
            buttons: {
                cancel: {
                    label: SCTEXT('No'),
                    className: 'btn-default'
                },
                 confirm: {
                    label: SCTEXT('Yes'),
                    className: 'btn-info'
                }
            },
            callback: function (result) {
                if(result){
                    //delete 
                    window.location = `${app_url}deleteOverrideRule/${rid}`;
                    }
                }
            }); 
    })
}

if(curpage=='add_orule' || curpage=='edit_orule'){
    $("#addtmp").click(function(){
        let tmpstr = `<div class="p-sm panel m-b-lg bg-info text-white" style="position: relative;">
        <a href="javascript:void(0);" class="plan-remove rmv_temp"><i class="fa fa-3x text-danger fa-minus-circle"></i> </a>
        <table class="table">
            <thead>
                <tr>
                    <th>Match</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <div class="input-group">
                            <span class="input-group-addon">Sender ID</span>
                            <span class="input-group-addon">
                                <select name="sendermatch[]" class="form-control input-sm">
                                    <option value="0">Any</option>
                                    <option value="equal">Equals to</option>
                                    <option value="start">Starts With</option>
                                    <option value="end">Ends With</option>
                                    <option value="has">Contains</option>
                                    <option value="nothave">Does not contain</option>
                                </select>
                            </span>
                            <span class="input-group-addon">
                                <input name="senderinput[]" type="text" class="form-control input-sm" placeholder="e.g. WEBSMS">
                            </span>
                        </div>
                    </td>
                    <td>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <select name="senderreplace[]" class="form-control input-sm">
                                    <option value="0">No Action</option>
                                    <option value="replace">Replace With</option>
                                    <option value="prepend">Add Prefix</option>
                                    <option value="append">Append Suffix</option>
                                    <option value="remove">Remove Prefix</option>
                                </select>
                            </span>
                            <span class="input-group-addon">
                                <input name="senderreplaceinput[]" type="text" class="form-control input-sm" placeholder="e.g. AUTOWEB">
                            </span>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="input-group">
                            <span class="input-group-addon">Mobile No.</span>
                            <span class="input-group-addon">
                                <select name="mobilematch[]" class="form-control input-sm">
                                    <option value="0">Any</option>
                                    <option value="equal">Equals to</option>
                                    <option value="start">Starts With</option>
                                    <option value="end">Ends With</option>
                                </select>
                            </span>
                            <span class="input-group-addon">
                                <input name="mobileinput[]" type="text" class="form-control input-sm" placeholder="e.g. 243812556677">
                            </span>
                        </div>
                    </td>
                    <td>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <select name="mobilereplace[]" class="form-control input-sm">
                                    <option value="0">No Action</option>
                                    <option value="reject">Reject Number</option>
                                    <option value="prepend">Append Prefix</option>
                                    <option value="append">Append Suffix</option>
                                    <option value="remove">Remove Prefix</option>
                                </select>
                            </span>
                            <span class="input-group-addon">
                                <input name="mobilereplaceinput[]" type="text" class="form-control input-sm" placeholder="e.g. 243">
                            </span>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="input-group">
                            <span class="input-group-addon">SMS Text</span>
                            <span class="input-group-addon">
                                <select name="textmatch[]" class="form-control input-sm">
                                    <option value="0">Any</option>
                                    <option value="equal">Equals to</option>
                                    <option value="start">Starts With</option>
                                    <option value="end">Ends With</option>
                                    <option value="has">Contains</option>
                                    <option value="nothave">Does not contain</option>
                                </select>
                            </span>
                            <span class="input-group-addon">
                                <input name="textinput[]" type="text" class="form-control input-sm" placeholder="e.g. karl">
                            </span>
                        </div>
                    </td>
                    <td>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <select name="textreplace[]" class="form-control input-sm">
                                    <option value="0">No Action</option>
                                    <option value="replace">Replace With</option>
                                    <option value="prepend">Add Prefix</option>
                                    <option value="append">Append Suffix</option>
                                    <option value="remove">Remove Prefix</option>
                                </select>
                            </span>
                            <span class="input-group-addon">
                                <input name="textreplaceinput[]" type="text" class="form-control input-sm" placeholder="e.g. k@rl">
                            </span>
                        </div>
                    </td>
                </tr>
                
            </tbody>
        </table>
    </div>`;

    $("#templatebox").append(tmpstr);

    })

    $(document).on("click",".rmv_temp", function(){
        $(this).parent().remove();
    })

    //submit form
    $("#save_changes").click(function(){

        if($("#orname").val()==''){
            bootbox.alert('Please enter name for the override rule.');
            return;
        }
        
        var dialog = bootbox.dialog({
                           closeButton: false,
                           message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Processing request')} . . . .</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
                       });   
               dialog.init(function(){
                       $("#stbar").animate({width:"100%"},500)
                       setTimeout(function(){
                           $("#add_orule_frm").attr('action',app_url+'saveOverrideRule');
                           $("#add_orule_frm").submit();
                           }, 50);
                       }); 
    });

    //back to settings
    $("#bk").click(function(){
        window.location = `${app_url}overrideRules`;
    });
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
// global scripts
   
    //load notifs
    setInterval(function(){
       loadAppAlerts();
    }, 30000);
    //notifs click redirec
    $(document).on("click",".albox", function(){
        var nid = $(this).attr('data-nid');
        var lnk = $(this).attr('data-redirect');
        window.location = app_url+'alertRedirect/'+nid+'/'+lnk;
    });
    
    $("#rlcrehdr").on("click",function(e){
        e.stopPropagation();
       $('#rlcrehdr i').addClass("fa-spin disabledBox");
        $.ajax({
            url: app_url+'reloadCreditData',
            success: function(res){
                window.location.reload(false);
            }
        })
    });
    $(".pop-over").popover({html: true});
    $(".dashboard-link").click(function(){
        window.location = app_url+'Dashboard';
    })
    
    $('[title]').each(function(){
        if($(this).hasClass("pop-over")==false){
            if($(this).prop("tagName")!='OPTION'){
                $(this).tooltip();
            }
            
        }
        
    });
    
    
});







//-------------- FUNCTIONS LIST ----------------//



function scBulkAction(action){
    //delete prefixes
    if(action=='delpre'){
        if($(".selected").length<1){
            bootbox.alert(SCTEXT('Please select at least one prefix to delete'));
            return;
        }else{
            var pids = [];
            $(".selected").each(function(){
                pids.push($(this).children().find(".pids").val());
            });
            var pstr = pids.join(",");
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete selected prefixes?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'delManyOP',
                                method: 'post',
                                data: {
                                    cid: $("#cid").val(),
                                    pids: pstr
                                },
                                success: function(res){
                                    window.location=app_url+'viewAllOP/'+$("#cid").val();
                                }
                            })
                            }
                        }
                    }); 
        }
    }
    
    //delete contacts
    if(action=='delcontacts'){
        if($(".selected").length<1){
            bootbox.alert(SCTEXT('Please select at least one contact to delete'));
            return;
        }else{
            var cids = [];
            $(".selected").each(function(){
                cids.push($(this).children().find(".cids").val());
            });
            var cstr = cids.join(",");
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to delete selected contacts?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'delManyContacts',
                                method: 'post',
                                data: {
                                    cids: cstr
                                },
                                success: function(res){
                                    window.location=app_url+'viewContacts/'+$("#groupid").val();
                                }
                            })
                            }
                        }
                    }); 
        }
    }
    
    
    //approve or reject sender ids
     if(action=='apprSid'){
        if($(".selected").length<1){
            bootbox.alert(SCTEXT('Please select at least one sender ID to approve'));
            return;
        }else{
            var sids = [];
            var usrs = [];
            $(".selected").each(function(){
                sids.push($(this).children().find(".sids").val());
                usrs.push($(this).children().find(".sids").attr("data-user"));
            });
            var sstr = sids.join(",");
            var ustr = usrs.join(",");
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to Approve selected Sender ID?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //-- 
                            $.ajax({
                                url: app_url+'approveManySids',
                                method: 'post',
                                data: {
                                    sids: sstr,
                                    users: ustr
                                },
                                success: function(res){
                                    window.location=app_url+'approveSenderIds';
                                }
                            })
                            }
                        }
                    }); 
        }
    }
    if(action=='rejcSid'){
        if($(".selected").length<1){
            bootbox.alert(SCTEXT('Please select at least one sender ID to reject'));
            return;
        }else{
            var sids = [];
            var usrs = [];
            $(".selected").each(function(){
                sids.push($(this).children().find(".sids").val());
                usrs.push($(this).children().find(".sids").attr("data-user"));
            });
            var sstr = sids.join(",");
            var ustr = usrs.join(",");
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to Reject selected Sender ID? These will be deleted from the system"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //-- 
                            $.ajax({
                                url: app_url+'rejectManySids',
                                method: 'post',
                                data: {
                                    sids: sstr,
                                    users: ustr
                                },
                                success: function(res){
                                    window.location=app_url+'approveSenderIds';
                                }
                            })
                            }
                        }
                    }); 
        }
    }
    //approve or reject templates
     if(action=='apprTemp'){
        if($(".selected").length<1){
            bootbox.alert(SCTEXT('Please select at least one template to approve'));
            return;
        }else{
            var tids = [];
            var usrs = [];
            $(".selected").each(function(){
                tids.push($(this).children().find(".tids").val());
                usrs.push($(this).children().find(".tids").attr("data-user"));
            });
            var tstr = tids.join(",");
            var ustr = usrs.join(",");
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to Approve selected templates?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //-- 
                            $.ajax({
                                url: app_url+'approveManyTemps',
                                method: 'post',
                                data: {
                                    tids: tstr,
                                    users: ustr
                                },
                                success: function(res){
                                    window.location=app_url+'approveTemplates';
                                }
                            })
                            }
                        }
                    }); 
        }
    }
    if(action=='rejcTemp'){
        if($(".selected").length<1){
            bootbox.alert(SCTEXT('Please select at least one template to reject'));
            return;
        }else{
            var tids = [];
            var usrs = [];
            $(".selected").each(function(){
                tids.push($(this).children().find(".tids").val());
                usrs.push($(this).children().find(".tids").attr("data-user"));
            });
            var tstr = tids.join(",");
            var ustr = usrs.join(",");
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to Reject selected templates?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //-- 
                            $.ajax({
                                url: app_url+'rejectManyTemps',
                                method: 'post',
                                data: {
                                    tids: tstr,
                                    users: ustr
                                },
                                success: function(res){
                                    window.location=app_url+'approveTemplates';
                                }
                            })
                            }
                        }
                    }); 
        }
    }
    
    //read alerts
    if(action=='readAlerts'){
        if($(".selected").length<1){
            bootbox.alert(SCTEXT('Please select at least one notification to mark it as READ'));
            return;
        }else{
            var nids = [];
            $(".selected").each(function(){
                nids.push($(this).children().find(".nids").val());
            });
            var nstr = nids.join(",");
            bootbox.confirm({
                    message: SCTEXT("Are you sure you want to mark selected notifications as read?"),
                    buttons: {
                        cancel: {
                            label: SCTEXT('No'),
                            className: 'btn-default'
                        },
                         confirm: {
                            label: SCTEXT('Yes'),
                            className: 'btn-info'
                        }
                    },
                    callback: function (result) {
                        if(result){
                            //delete 
                            $.ajax({
                                url: app_url+'markAlertsRead',
                                method: 'post',
                                data: {
                                    nids: nstr
                                },
                                success: function(res){
                                    window.location=app_url+'viewNotifications';
                                }
                            })
                            }
                        }
                    }); 
        }
    }
    
    
    //-eof
}

function downloadUserSmsLog(){
    var searchstr = $("#t-usmslog_filter").find("input").val();
    var expdata = { filDate: $('#sldp span').html(), senderId: $("#sidsel").val(), routeId: $("#rtsel").val(), search:searchstr};
    
    var dialog = bootbox.dialog({
        closeButton: false,
        message: `<p class="text-center" style="color: hsl(0, 0%, 0%);margin-top: 2%;word-spacing: 2px;"> ${SCTEXT('Preparing file.<br> Download will start in few minutes. This window will close automatically.')}</p><div class="progress progress-xs"><div id="stbar" class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div>`
    });
    dialog.init(function(){
        $("#stbar").animate({width:"100%"},{duration: 10000,complete: function(){bootbox.hideAll()}});
        setTimeout(function(){
             window.location = app_url+'globalFileDownload/smslog/'+encodeURIComponent(JSON.stringify(expdata));
        }, 5);
    });
   
}

function loadScText(){
    $.ajax({
        url: app_url+'getScText',
        success: function(res){
            if(res=='en'){
                localStorage.clear();
                localStorage.setItem("app_lang",app_lang);
            }else{
                //populate js array
                var transtxt = [];
                transtxt = JSON.parse(res);
                for( var word in transtxt){
                    localStorage.setItem(word, transtxt[word]);
                }
                localStorage.setItem("app_lang",app_lang);
            }
                
        }
    
    });
}

function SCTEXT(str){
        var lstr = str.toLowerCase();
        if(!localStorage.getItem(lstr) || localStorage.getItem(lstr)==''){
            return str;
        }else{
            return localStorage.getItem(lstr);
            //return sctext[$str];
        }
    } 

function createInputFile(formId, inputval, mode=''){
    
    var node = document.createElement('INPUT');
    var atype = document.createAttribute("type");
    atype.value = "hidden";
    var aname = document.createAttribute("name");
    aname.value = "uploadedFiles[]";
    var aval = document.createAttribute("value");
    aval.value = inputval;
    var aid = document.createAttribute("id");
    aid.value = inputval;
    var acls = document.createAttribute("class");
    acls.value = "uploadedFile";
    
    node.setAttributeNode(atype); 
    node.setAttributeNode(aname); 
    node.setAttributeNode(aval); 
    node.setAttributeNode(aid); 
    node.setAttributeNode(acls); 
    
   document.getElementById(formId).appendChild(node);
    
   if(mode=='sendsms'){
       //get the sheets and mobile columns
       var ext = inputval.split('.').pop();
       if(ext=='xls' || ext=='xlsx'){
           var loadele = '<div id="sheetloader" class="form-group m-v-sm text-center"><i class="fa fa-cog fa-spin fa-lg fa-fw"></i><b>'+SCTEXT('Loading Sheets and columns')+' ...<b></b></b></div>';
            $("#xlsheetcolbox").before(loadele);
       }
        
        $.ajax({
								type: 'post',
								dataType: 'json',
								url: app_url+'getSheetnColumns',
								data: {
									file: inputval
									},
								success: function(res){
									var data = res;
                                    if(ext=='xls' || ext=='xlsx'){
                                        $sheets = data.sheets;
                                        $cols = data.cols;
                                        $sheet_str = '';
                                            for(var i =0;i<$sheets.length;i++){
                                            $sheet_str += '<option value="'+$sheets[i]+'">'+$sheets[i]+'</option>';
                                            }
                                        $cols_str='';	
                                        $cols_btns = '';
                                            for(var j in $cols){
                                                if($cols[j]!=null && $cols[j]!=''){
                                                    $cols_str += '<option value="'+j+'">'+$cols[j]+'</option>';
                                                    $cols_btns += '<button data-colval="'+j+'" type="button" class="colsbtn btn btn-sm btn-default">'+$cols[j]+'</button>';
                                                }
                                            }
                                        //append strings to proper select boxed
                                        $("#sheetloader").remove();
                                        $("#xlsheet").html($sheet_str);
                                        $("#xlcol").html($cols_str);
                                        $("#xlcolbtns").html($cols_btns);
                                        $("#ufilecno").val(parseInt(data.totalrows));	
                                        $("#xlsheetcolbox").removeClass('hidden');
                                        calcContacts();
                                    }else if(ext=='csv'||ext=='CSV'){
                                        //csv
                                        $cols = data.cols;
                                         $cols_btns = '';
                                            for(var j in $cols){
                                                if($cols[j]!=null && $cols[j]!=''){
                                                    $cols_btns += '<button data-colval="'+j+'" type="button" class="colsbtn btn btn-sm btn-default">'+$cols[j]+'</button>';
                                                }
                                            }
                                        $("#xlcolbtns").html($cols_btns);
                                        $("#ufilecno").val(parseInt(data.totalrows));	
                                        calcContacts();
                                    }else{
                                        // txt
                                        $("#ufilecno").val(parseInt(data.totalrows));	
                                        $("#xlcolbtns").html('- No Columns Available -');
                                        $("#xlsheetcolbox").addClass('hidden');
                                        calcContacts();
                                    }
									
									
									}	
								});
           
           
       
   }
    
}

function deleteInputFile(inputval, mode){
    $.ajax({
        url: app_url+'deleteUploadedFile',
        method: 'POST',
        data: {
            mode: mode,
            filename: inputval
        },
        success: function(res){
            //remove element
            var element = document.getElementById(inputval);
            element.parentNode.removeChild(element);
            
            //hide sheets and cols and recount contacts if sendsms mode
            if(mode=='sendsms'){
                //hide the sheet column selector
                $("#xlsheetcolbox").addClass("hidden");
                $("#ufilecno").val(parseInt('0'));
                $("#xlcolbtns").html('- No Columns Available -');
                //count contacts
                calcContacts();
            }
        }
    });
}

function nl2br (str, is_xhtml) {   
var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';    
return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1'+ breakTag +'$2');
}

function calcTotalSessions(){
	$txs = isNaN(parseInt($("#tx_no").val()))?0:parseInt($("#tx_no").val());
	$rxs = isNaN(parseInt($("#rx_no").val()))?0:parseInt($("#rx_no").val());
	$trxs = isNaN(parseInt($("#trx_no").val()))?0:parseInt($("#trx_no").val());
	
	$ts = $txs+$rxs+$trxs;
	$("#total_sessions").val( $ts);
}

function formatInt(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function isPositiveInteger(val){
      if(val==null){return false;}
      if (val.length==0){return false;}
      for (var i = 0; i < val.length; i++) {
            var ch = val.charAt(i)
            if (ch < "0" || ch > "9") {
            return false
            }
      }
	  return true
    }


function isValidPhone(val){
      if(val==null){return false;}
      if (val.length==0){return false;}
      if (val.length>15 || val.length<8){return false;}
      for (var i = 0; i < val.length; i++) {
            var ch = val.charAt(i)
            if (ch < "0" || ch > "9" || ch=="+") {
            return false
            }
      }
	  return true
}

function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   return false
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   return false
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    return false
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    return false
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    return false
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		    return false
		 }

 		 return true					
	}
function dump(obj) {
    var out = '';
    for (var i in obj) {
        out += i + ": " + obj[i] + "\n";
    }

    alert(out);

    // or, if you wanted to avoid alerts...

    var pre = document.createElement('pre');
    pre.innerHTML = out;
    document.body.appendChild(pre)
}

function calcContacts(){
    //calculate contacts on compose sms page
    var txtcno = 0;
    var grpcno = 0;
    var filecno = 0;
    //show loader
    $("#contcountloader").removeClass('hidden');

    if($("#account_type").val()=='1'){
        let contactcost = 0;
        if($("#editsch").length>0){
            let schno = parseInt($("#totalschno").val());
            contactcost = parseFloat($("#schcontactcost").val());
            let smscnt;
            //check sms count
            if($("#txtsms").is(':checked')){
                smscnt = $("#txtcount").val();
            }else{
                smscnt = 1;
            }
            let totalcost = parseFloat(contactcost) * parseInt(smscnt);
            $("#contcountbox").html(`<b>${formatInt(schno)}</b> contact(s) X <b>${smscnt}</b> SMS = <b>${ app_currency} ${totalcost.toFixed(4)}</b> ${SCTEXT('will be charged')} <span id="contcountloader" class="hidden pull-right text-dark"><i class="fa fa-lg fa-spin fa-circle-o-notch"></i> </span>`);
        }else{
            let txtvals = $('#contactinput').val()!=undefined ? $('#contactinput').val().split("\n") : [];
            if(txtvals.length>0){
                //send contacts to ajax call and calculate total cost
                $.ajax({
                    url: `${app_url}calculateSmsCost`,
                    method: 'post',
                    data: {
                        mode: 'sendsms',
                        phones: JSON.stringify(txtvals)
                    },
                    success: function(res){
                        let data = JSON.parse(res);
                        let smscnt;
                        //check sms count
                        if($("#txtsms").is(':checked')){
                            smscnt = $("#txtcount").val();
                        }else{
                            smscnt = 1;
                        }
                        let totalcost = parseFloat(data.price) * parseInt(smscnt);
                        
                        $("#contcountbox").html(`<b>${formatInt(data.totalcontacts)}</b> contact(s) X <b>${smscnt}</b> SMS = <b>${ app_currency} ${totalcost.toFixed(4)}</b> ${SCTEXT('will be charged')} <span id="contcountloader" class="hidden pull-right text-dark"><i class="fa fa-lg fa-spin fa-circle-o-notch"></i> </span>`);
                    }
                })
            }else{
                //unable to calculate total cost
            }
        }
        
    }else{
        //credit based account. Simply calculate total contacts and sms count
        if($("#resendpb").length>0 || ($("#syspb").length>0 && $("#syspb").is(":checked"))){
            //phonebook contact selected

                //check sms count
                if($("#txtsms").is(':checked')){
                    var smscnt = $("#txtcount").val();
                }else{
                    var smscnt = 1;
                }

            if($("#resend").length>0){
                //resend phonebook campaign
                var totalno = $("#pbtotal").val();
            }else{
                
                //contact count
                var pbfrom = parseInt($("#pbfrom").val()) || 0;
                var pbto = parseInt($("#pbto").val()) || 0;

                var totalno = pbto==0?0:parseInt(pbto-pbfrom)+1;
            
            }
            
        }else{
            //my contacts
            //edit campaign contacts
            var schno = 0;
            if($("#totalschno").length>0){
                schno = parseInt($("#totalschno").val());
            }else{
                //textarea
                txtcno = parseInt($('#contactinput').val().split("\n").filter(Boolean).length) || 0;

                //contact groups
                grpcno = parseInt($("#grpsel option:selected").attr('data-count')) || 0;

                //uploaded file
                filecno = $("#ufilecno").val();
            }

            //check sms count
            if($("#txtsms").is(':checked')){
                var smscnt = $("#txtcount").val();
            }else{
                var smscnt = 1;
            }

            var totalno = txtcno+grpcno+parseInt(filecno)+schno;

        }
        $("#contcountbox").html('<b>'+formatInt(totalno)+'</b> contact(s) X <b>'+smscnt+'</b> SMS = <b>'+formatInt(totalno*smscnt)+'</b> '+SCTEXT('credits required')+' <span id="contcountloader" class="hidden pull-right text-dark"><i class="fa fa-lg fa-spin fa-circle-o-notch"></i> </span>');
    }   
    
}

function loadAppAlerts(){
    $.ajax({
        type: 'get',
        url: app_url+'getMyAlerts',
        success: function(res){
            var mydata = JSON.parse(res);
            $("#notifctr").html(mydata.str);
            if(mydata.count!='0'){ 
                //play notif sound if new notification
                if($("#notifcnt").html()=='')$('#notifAudio')[0].play();
                $("#notifcnt").html(mydata.count);
            }else{
                $("#notifcnt").html('');
            }
            
        }
    });
}

function createSwitches(switchclass="myswitch"){
    $("."+switchclass).each(function () {
        var ele = $(this);
        var elecolor = ele.attr("data-color");
        var elesize = ele.attr("data-size") || "default";
        if(!ele.attr('data-switchery')){
            var switchery = new Switchery(document.querySelector("#"+ele.attr("id")),{ color: elecolor, size: elesize, jackColor: "#ffffff"});
            }
       
        
    })
    
}


//--- Google Transliteration functions --//
//load Google transliteration
         google.load("elements", "1", {
            packages: "transliteration"
          });
         
var transliterationControl;
      function onLoad() {
        var options = {
            sourceLanguage: 'en',
            destinationLanguage: ['ar','hi','kn','ml','ta','te','mr','gu','bn','pa','ur','zh','ne','ru','fa','el','sa','sr'],
            transliterationEnabled: false,
            shortcutKey: 'ctrl+g'
        };
        // Create an instance on TransliterationControl with the required
        // options.
        transliterationControl =
          new google.elements.transliteration.TransliterationControl(options);

        // Enable transliteration in the textfields with the given ids.
        var ids = [ "text_sms_content" ];
        transliterationControl.makeTransliteratable(ids);

        // Add the STATE_CHANGED event handler to correcly maintain the state
        // of the checkbox.
        transliterationControl.addEventListener(
            google.elements.transliteration.TransliterationControl.EventType.STATE_CHANGED,
            transliterateStateChangeHandler);

        // Add the SERVER_UNREACHABLE event handler to display an error message
        // if unable to reach the server.
        transliterationControl.addEventListener(
            google.elements.transliteration.TransliterationControl.EventType.SERVER_UNREACHABLE,
            serverUnreachableHandler);

        // Add the SERVER_REACHABLE event handler to remove the error message
        // once the server becomes reachable.
        transliterationControl.addEventListener(
            google.elements.transliteration.TransliterationControl.EventType.SERVER_REACHABLE,
            serverReachableHandler);

        // Set the checkbox to the correct state.
        document.getElementById('unicodesms').checked =
          transliterationControl.isTransliterationEnabled();

        // Populate the language dropdown
        transliterationControl.showControl('translControl');
          
          
      }


      // Handler for STATE_CHANGED event which makes sure checkbox status
      // reflects the transliteration enabled or disabled status.
      function transliterateStateChangeHandler(e) {
        document.getElementById('unicodesms').checked = e.transliterationEnabled;
      }

      // Handler for checkbox's click event.  Calls toggleTransliteration to toggle
      // the transliteration state.
      function checkboxClickHandler() {
        transliterationControl.toggleTransliteration();
      }

      

      // SERVER_UNREACHABLE event handler which displays the error message.
      function serverUnreachableHandler(e) {
        document.getElementById("errorDiv").innerHTML =
            "Transliteration Server unreachable";
      }

      // SERVER_UNREACHABLE event handler which clears the error message.
      function serverReachableHandler(e) {
        document.getElementById("errorDiv").innerHTML = "";
      }


function serialize (mixedValue) {
  //      note 1: We feel the main purpose of this function should be to ease
  //      note 1: the transport of data between php & js
  //      note 1: Aiming for PHP-compatibility, we have to translate objects to arrays
  //   example 1: serialize(['Kevin', 'van', 'Zonneveld'])
  //   returns 1: 'a:3:{i:0;s:5:"Kevin";i:1;s:3:"van";i:2;s:9:"Zonneveld";}'
  //   example 2: serialize({firstName: 'Kevin', midName: 'van'})
  //   returns 2: 'a:2:{s:9:"firstName";s:5:"Kevin";s:7:"midName";s:3:"van";}'
  //   example 3: serialize( {'ü': 'ü', '四': '四', '𠜎': '𠜎'})
  //   returns 3: 'a:3:{s:2:"ü";s:2:"ü";s:3:"四";s:3:"四";s:4:"𠜎";s:4:"𠜎";}'

  var val, key, okey
  var ktype = ''
  var vals = ''
  var count = 0

  var _utf8Size = function (str) {
    return ~-encodeURI(str).split(/%..|./).length
  }

  var _getType = function (inp) {
    var match
    var key
    var cons
    var types
    var type = typeof inp

    if (type === 'object' && !inp) {
      return 'null'
    }

    if (type === 'object') {
      if (!inp.constructor) {
        return 'object'
      }
      cons = inp.constructor.toString()
      match = cons.match(/(\w+)\(/)
      if (match) {
        cons = match[1].toLowerCase()
      }
      types = ['boolean', 'number', 'string', 'array']
      for (key in types) {
        if (cons === types[key]) {
          type = types[key]
          break
        }
      }
    }
    return type
  }

  var type = _getType(mixedValue)

  switch (type) {
    case 'function':
      val = ''
      break
    case 'boolean':
      val = 'b:' + (mixedValue ? '1' : '0')
      break
    case 'number':
      val = (Math.round(mixedValue) === mixedValue ? 'i' : 'd') + ':' + mixedValue
      break
    case 'string':
      val = 's:' + _utf8Size(mixedValue) + ':"' + mixedValue + '"'
      break
    case 'array':
    case 'object':
      val = 'a'
      /*
      if (type === 'object') {
        var objname = mixedValue.constructor.toString().match(/(\w+)\(\)/);
        if (objname === undefined) {
          return;
        }
        objname[1] = serialize(objname[1]);
        val = 'O' + objname[1].substring(1, objname[1].length - 1);
      }
      */

      for (key in mixedValue) {
        if (mixedValue.hasOwnProperty(key)) {
          ktype = _getType(mixedValue[key])
          if (ktype === 'function') {
            continue
          }

          okey = (key.match(/^[0-9]+$/) ? parseInt(key, 10) : key)
          vals += serialize(okey) + serialize(mixedValue[key])
          count++
        }
      }
      val += ':' + count + ':{' + vals + '}'
      break
    case 'undefined':
    default:
      // Fall-through
      // if the JS object has a property which contains a null value,
      // the string cannot be unserialized by PHP
      val = 'N'
      break
  }
  if (type !== 'object' && type !== 'array') {
    val += ';'
  }

  return val
}

function insertAtCaret(areaId, text) {
  var txtarea = document.getElementById(areaId);
  if (!txtarea) {
    return;
  }

  var scrollPos = txtarea.scrollTop;
  var strPos = 0;
  var br = ((txtarea.selectionStart || txtarea.selectionStart == '0') ?
    "ff" : (document.selection ? "ie" : false));
  if (br == "ie") {
    txtarea.focus();
    var range = document.selection.createRange();
    range.moveStart('character', -txtarea.value.length);
    strPos = range.text.length;
  } else if (br == "ff") {
    strPos = txtarea.selectionStart;
  }

  var front = (txtarea.value).substring(0, strPos);
  var back = (txtarea.value).substring(strPos, txtarea.value.length);
  txtarea.value = front + text + back;
  strPos = strPos + text.length;
  if (br == "ie") {
    txtarea.focus();
    var ieRange = document.selection.createRange();
    ieRange.moveStart('character', -txtarea.value.length);
    ieRange.moveStart('character', strPos);
    ieRange.moveEnd('character', 0);
    ieRange.select();
  } else if (br == "ff") {
    txtarea.selectionStart = strPos;
    txtarea.selectionEnd = strPos;
    txtarea.focus();
  }

  txtarea.scrollTop = scrollPos;
}
function substr_replace (str, replace, start, length) {

    var cutstart = start < 0 ? parseInt(start) + parseInt(str.length) : parseInt(start);

    if (length <= 0) {
        length = 1;
    }

    // console.log(str.slice(0, cutstart))
    // console.log(replace)
    // console.log(str.slice(cutstart))
    var finalstr = str.slice(0, cutstart) + replace + str.slice(cutstart+parseInt(length));
    
    return finalstr;
}


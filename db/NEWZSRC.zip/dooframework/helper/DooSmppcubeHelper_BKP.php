<?php
/**
 * DooSmppcubeHelper class file.
 *
 * @author Saurav <saurabh.pandey@cubelabs.in>
 * @license http://www.doophp.com/license
 */

/* logic to send sms

        $arrContextOptions=array(
            "ssl"=>array(
                "verify_peer"=>false,
                "verify_peer_name"=>false,
            ),
        ); 

        $akobj = Doo::loadModel('ScApiKeys', true);
        $api_key = $akobj->getApiKey($user_id); //sender user id
        $smsdata['sms'] = $smstext;
        $api_url = Doo::conf()->APP_URL.'smsapi/index.php?key='.$api_key.'&campaign=0&routeid='.$route_id.'&type=text&contacts='.$mobiles_by_comma.'&senderid='.$sender_id_text.'&msg='.urlencode($smstext);
        
        $response = file_get_contents( $api_url, false, stream_context_create($arrContextOptions));

*/


/**
 * A helper class that provides common functions for app
 *
 * 
 */
class DooSmppcubeHelper {
    
    public static function pushToKannel($data){
       
        //set out parameters
        $type = unserialize($data['sms_type']);
        $data['senderid'] = urlencode($data['senderid']);
        //- DLR URL
        // e.g. http://server/app/getDLR/index.php?route_id=1&shoot_id=abcd&user_id=2&upline_id=1&umsgid=234432a45rfd&persmscount=2&personalize=1&mobile=%p&dlr=%d&vendor_dlr=%A&vmsgid=%F
         
        $dlrurl = 'https://'.Doo::conf()->admin_domain.'/getDLR/index?route_id='.$data['route_id'].'&shoot_id='.$data['sms_shoot_id'].'&user_id='.$data['user_id'].'&upline_id='.$data['upline_id'].'&umsgid='.$data['umsgid'].'&persmscount='.$data['smscount'].'&usertype='.$data['usertype']; //admin domain and ssl
         
        if($type['personalize']=='1'){
            $dlrurl .= '&personalize=1';
        }
         
        $dlrurl .= '&mobile=%p&dlr=%d&vendor_dlr=%A&vmsgid=%F';
        $dlrurl = urlencode($dlrurl); 
        
        //- contacts
        $contacts = is_array($data['contacts']) ? implode('+', array_column($data['contacts'], 'mobile')) : $data['contacts'];
        
       
        if($type['main']=='text'){
            
            $url = '/cgi-bin/sendsms?username='.Doo::conf()->username.'&password='.Doo::conf()->password.'&smsc='.$data['smsc'].'&dlr-mask=31&dlr-url='.$dlrurl.'&to='.$contacts.'&from='.$data['senderid'];
            
            if($type['flash']=='1'){
                $url .= '&mclass=0';
            }
            if($type['unicode']=='1'){
                $url .= '&charset=UTF-8&coding=2';
                $txtstr = urlencode(html_entity_decode($data['sms_text'],ENT_QUOTES,"UTF-8"));
            }else{
                $txtstr = urlencode($data['sms_text']);
            }
            $url .= '&text='.$txtstr;
                
        }elseif($type['main']=='wap'){
            
            $url = '/cgi-bin/sendsms?username='.Doo::conf()->username.'&password='.Doo::conf()->password.'&smsc='.$data['smsc'].'&dlr-mask=31&dlr-url='.$dlrurl.'&to='.$contacts.'&from='.$data['senderid'].'&mclass=1&udh=%06%05%04%0B%84%23%F0&text=%1B%06%01%AE%02%05%6A%00%45%C6%0C%03'.$data['sms_text']['wap_url'].'%00%01%03'.$data['sms_text']['wap_url'].'%00%01%01';
            
        }elseif($type['main']=='vcard'){
            
            $text  = "BEGIN:VCARD\r\n";
            $text .= "VERSION:2.1\r\n";
            $text .= "N:".$data['sms_text']['vcard_lname'].";".$data['sms_text']['vcard_fname']."\r\n";
            $text .= "TITLE:".$data['sms_text']['vcard_job']."\r\n";
            $text .= "ORG:".$data['sms_text']['vcard_comp']."\r\n"; 
            $text .= "EMAIL:".$data['sms_text']['vcard_email']."\r\n";
            $text .= "TEL;PREF:+".$data['sms_text']['vcard_tel']."\r\n";
            $text .= "END:VCARD\r\n";

            $msg = urlencode($text);

            $url = '/cgi-bin/sendsms?username='.Doo::conf()->username.'&password='.Doo::conf()->password.'&smsc='.$data['smsc'].'&dlr-mask=31&dlr-url='.$dlrurl.'&to='.$contacts.'&from='.$data['senderid'].'&udh=%06%05%04%23%F4%00%00&text='.$msg;
            
        }
        
        //submit to Gateway	
        return self::smppSubmit($url);
		
	}
	
    public static function smppSubmit($URL){
        if(Doo::conf()->demo_mode=='false'){
	       $connection = fsockopen(Doo::conf()->bearerbox_host,Doo::conf()->sendsms_port,$error_number,$error_description,60);
	       
            socket_set_blocking($connection, false);
            fputs($connection, "GET $URL HTTP/1.0\r\n\r\n");
            while(!feof($connection)){
               $myline = fgets($connection, 128);
               switch($myline){
                    case (strstr($myline, 'Content-')): break;
                    case (strstr($myline, 'HTTP/1')): break;
                    case "": break;
                    case "\r\n": break;
                    default:  break; //echo "<p>".$myline."</p>";
                }
              }
                fclose ($connection);
                return $myline;
            }else{
            return 'submitted';	
            }
	}

  
    public static function getVisitorOs(){
       $osList = array (
            /* -- WINDOWS -- */
            'Windows 10 (Windows NT 10.0)' => 'windows nt 10.0',
            'Windows 8.1 (Windows NT 6.3)' => 'windows nt 6.3',
            'Windows 8 (Windows NT 6.2)' => 'windows nt 6.2',
            'Windows 7 (Windows NT 6.1)' => 'windows nt 6.1',
            'Windows Vista (Windows NT 6.0)' => 'windows nt 6.0',
            'Windows Server 2003 (Windows NT 5.2)' => 'windows nt 5.2',
            'Windows XP (Windows NT 5.1)' => 'windows nt 5.1',
            'Windows 2000 sp1 (Windows NT 5.01)' => 'windows nt 5.01',
            'Windows 2000 (Windows NT 5.0)' => 'windows nt 5.0',
            'Windows NT 4.0' => 'windows nt 4.0',
            'Windows Me  (Windows 9x 4.9)' => 'win 9x 4.9',
            'Windows 98' => 'windows 98',
            'Windows 95' => 'windows 95',
            'Windows CE' => 'windows ce',
            'Windows (version unknown)' => 'windows',
            /* -- MAC OS X -- */
            'Mac OS X Beta (Kodiak)' => 'Mac OS X beta',
            'Mac OS X Cheetah' => 'Mac OS X 10.0',
            'Mac OS X Puma' => 'Mac OS X 10.1[^0-9]',
            'Mac OS X Jaguar' => 'Mac OS X 10.2',
            'Mac OS X Panther' => 'Mac OS X 10.3',
            'Mac OS X Tiger' => 'Mac OS X 10.4',
            'Mac OS X Leopard' => 'Mac OS X 10.5',
            'Mac OS X Snow Leopard' => 'Mac OS X 10.6',
            'Mac OS X Lion' => 'Mac OS X 10.7',
            'Mac OS X Mountain Lion' => 'Mac OS X 10.8',
            'Mac OS X Mavericks' => 'Mac OS X 10.9',
            'Mac OS X Yosemite' => 'Mac OS X 10.10',
            'Mac OS X El Capitan' => 'Mac OS X 10.11',
            'macOS Sierra' => 'Mac OS X 10.12',
            'Mac OS X (version unknown)' => 'Mac OS X',
            'Mac OS (classic)' => '(mac_powerpc)|(macintosh)',
            /* -- OTHERS -- */
            'OpenBSD' => 'openbsd',
            'SunOS' => 'sunos',
            'Ubuntu' => 'ubuntu',
            'Linux (or Linux based)' => '(linux)|(x11)',
            'QNX' => 'QNX',
            'BeOS' => 'beos',
            'OS2' => 'os/2',
            'SearchBot'=>'(nuhk)|(googlebot)|(yammybot)|(openbot)|(slurp)|(msnbot)|(ask jeeves/teoma)|(ia_archiver)'
            );

                    $useragent = htmlspecialchars($_SERVER['HTTP_USER_AGENT']);
                    $useragent = strtolower($useragent);

                    foreach($osList as $os=>$match) {
                        if (preg_match('/' . $match . '/i', $useragent)) {
                            break;  
                        } else {
                            $os = "Unknown";    
                        }
                    }
                    return $os;
    }

    public static function formatBytes($bytes, $precision = 2) { 
        $units = array('B', 'KB', 'MB', 'GB', 'TB'); 

        $bytes = max($bytes, 0); 
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
        $pow = min($pow, count($units) - 1); 

        // Uncomment one of the following alternatives
        $bytes /= pow(1024, $pow);
        // $bytes /= (1 << (10 * $pow)); 

        return round($bytes, $precision) . ' ' . $units[$pow]; 
    }  
    
    public static function sendSms($data){
        /*format
        $data['userid] is user id of sender
        $data['senderid'] is the actual from address using which sms will be sent
        $data['smstype'] usually text but could be unicode etc
        $data['smstext'] message to be sent
        $data['routeid'] id of the route to be sed for sending sms
        $data['mobiles'] comma separated mobile numbers
        */
        
        $arrContextOptions=array(
            "ssl"=>array(
                "verify_peer"=>false,
                "verify_peer_name"=>false,
            ),
        ); 

        $akobj = Doo::loadModel('ScApiKeys', true);
        $api_key = $akobj->getApiKey($data['userid']); //sender user id
        $smstext = $data['smstext'];
        $api_url = Doo::conf()->APP_URL.'smsapi/index?key='.$api_key.'&campaign=0&routeid='.$data['routeid'].'&type='.$data['smstype'].'&contacts='.$data['mobiles'].'&senderid='.$data['senderid'].'&msg='.urlencode($smstext);
        
        $response = file_get_contents( $api_url, false, stream_context_create($arrContextOptions));
        return $response;
        
    }
    
    public static function sendEmail($data){
        /*format
        $data['sendermail'] is email of sender, the from address
        $data['sendername'] is the name that will display as from
        $data['receivermail] is the TO address, the destination email
        $data['subject'] is email subject
        $data['mailbody'] is the string html that will be sent
        */
        
        Doo::loadHelper("DooPhpMailer");
        $mail = DooPhpMailer::getMailObj();
             
        $mail->setFrom($data['sendermail'], $data['sendername']);
        $mail->addAddress($data['receivermail']);
        $mail->Subject  = $data['subject'];
        $mail->isHTML(true);
        $mail->Body = $data['mailbody'];
            
        $mail->send();
    }
    
    public function getUserTree($userid){
        $ulist = array();
        $userobj = Doo::loadModel('ScUsers', true);
        $userobj->upline_id = $userid;
        $downlines = Doo::db()->find($userobj,array('select'=>'user_id,category'));
        //var_dump($downlines);die;
        if(sizeof($downlines)>0){
            foreach($downlines as $usr){
                if($usr->category=='client'){
                    array_push($ulist, $usr->user_id);
                    
                }else{
                    $newdl = $this->getUserTree($usr->user_id);
                    $ulist = array_merge($ulist,$newdl);
                }
            }
           array_push($ulist, $userid);
        }else{
            array_push($ulist, $userid);
           
        }
        return $ulist;
    }

    public static function getCountryCodes($phones){
        $ccodes = array(
                    91 => "IN",
                    1 => "US",
                    65 => "SG",
                    213 => "DZ",
                    244 => "AO",
                    229 => "BJ",
                    267 => "BW",
                    226 => "BF",
                    257 => "BI",
                    237 => "CM",
                    238 => "CV",
                    236 => "CF",
                    235 => "TD",
                    269 => "KM",
                    243 => "CD",
                    242 => "CG",
                    253 => "DJ",
                    20 => "EG",
                    240 => "GQ",
                    291 => "ER",
                    251 => "ET",
                    241 => "GA",
                    220 => "GM",
                    233 => "GH",
                    224 => "GN",
                    245 => "GW",
                    225 => "CI",
                    254 => "KE",
                    266 => "LS",
                    231 => "LR",
                    218 => "LY",
                    261 => "MG",
                    265 => "MW",
                    223 => "ML",
                    222 => "MR",
                    230 => "MU",
                    212 => "MA",
                    258 => "MZ",
                    264 => "NA",
                    227 => "NE",
                    250 => "RW",
                    290 => "SH",
                    221 => "SN",
                    248 => "SC",
                    232 => "SL",
                    252 => "SO",
                    27 => "ZA",
                    249 => "SD",
                    268 => "SZ",
                    239 => "ST",
                    255 => "TZ",
                    228 => "TG",
                    216 => "TN",
                    256 => "UG",
                    260 => "ZM",
                    263 => "ZW",
                    262 => "TF",
                    93 => "AF",
                    374 => "AM",
                    994 => "AZ",
                    973 => "BH",
                    880 => "BD",
                    975 => "BT",
                    673 => "BN",
                    855 => "KH",
                    86 => "CN",
                    995 => "GE",
                    852 => "HK",
                    62 => "ID",
                    98 => "IR",
                    964 => "IQ",
                    972 => "IL",
                    81 => "JP",
                    962 => "JO",
                    7 => "KZ",
                    965 => "KW",
                    996 => "KG",
                    856 => "LA",
                    961 => "LB",
                    853 => "MO",
                    60 => "MY",
                    960 => "MV",
                    976 => "MN",
                    95 => "MM",
                    977 => "NP",
                    850 => "KP",
                    968 => "OM",
                    92 => "PK",
                    970 => "PS",
                    63 => "PH",
                    974 => "QA",
                    966 => "SA",
                    82 => "KR",
                    94 => "LK",
                    963 => "SY",
                    886 => "TW",
                    992 => "TJ",
                    66 => "TH",
                    90 => "TR",
                    993 => "TM",
                    971 => "AE",
                    998 => "UZ",
                    84 => "VN",
                    967 => "YE",
                    355 => "AL",
                    376 => "AD",
                    43 => "AT",
                    375 => "BY",
                    32 => "BE",
                    387 => "BA",
                    359 => "BG",
                    385 => "HR",
                    357 => "CY",
                    420 => "CZ",
                    45 => "DK",
                    372 => "EE",
                    298 => "FO",
                    358 => "FI",
                    33 => "FR",
                    49 => "DE",
                    350 => "GI",
                    30 => "GR",
                    36 => "HU",
                    354 => "IS",
                    353 => "IE",
                    39 => "IT",
                    383 => "XK",
                    371 => "LV",
                    423 => "LI",
                    370 => "LT",
                    352 => "LU",
                    389 => "MK",
                    356 => "MT",
                    373 => "MD",
                    377 => "MC",
                    382 => "ME",
                    31 => "NL",
                    47 => "NO",
                    48 => "PL",
                    351 => "PT",
                    40 => "RO",
                    79 => "RU",
                    378 => "SM",
                    381 => "RS",
                    421 => "SK",
                    386 => "SI",
                    34 => "ES",
                    46 => "SE",
                    41 => "CH",
                    380 => "UA",
                    44 => "GB",
                    297 => "AW",
                    501 => "BZ",
                    599 => "BQ",
                    506 => "CR",
                    53 => "CU",
                    503 => "SV",
                    299 => "GL",
                    502 => "GT",
                    509 => "HT",
                    504 => "HN",
                    596 => "MQ",
                    52 => "MX",
                    505 => "NI",
                    507 => "PA",
                    590 => "BL",
                    508 => "PM",
                    54 => "AR",
                    591 => "BO",
                    55 => "BR",
                    56 => "CL",
                    57 => "CO",
                    593 => "EC",
                    500 => "FK",
                    594 => "GF",
                    595 => "PY",
                    51 => "PE",
                    597 => "SR",
                    598 => "UY",
                    58 => "VE",
                    61 => "AU",
                    682 => "CK",
                    670 => "TL",
                    679 => "FJ",
                    689 => "PF",
                    686 => "KI",
                    692 => "MH",
                    691 => "FM",
                    674 => "NR",
                    687 => "NC",
                    64 => "NZ",
                    683 => "NU",
                    672 => "NF",
                    680 => "PW",
                    675 => "PG",
                    685 => "WS",
                    677 => "SB",
                    690 => "TK",
                    676 => "TO",
                    688 => "TV",
                    678 => "VU",
                    681 => "WF",
                    234 => "NG" 
        );
        
        krsort( $ccodes );
        
        foreach( $phones as $pn )
        {
            foreach( $ccodes as $key=>$value )
            {
                if ( substr( $pn, 0, strlen( $key ) ) == $key )
                {
                    // match
                    $country[$pn] = $value;
                    break;
                }
            }
        }
        
        return $country;
    }
    public static function getCountryIso($msisdn){
        $ccodes = array(
                    91 => "IN",
                    1 => "US",
                    65 => "SG",
                    213 => "DZ",
                    244 => "AO",
                    229 => "BJ",
                    267 => "BW",
                    226 => "BF",
                    257 => "BI",
                    237 => "CM",
                    238 => "CV",
                    236 => "CF",
                    235 => "TD",
                    269 => "KM",
                    243 => "CD",
                    242 => "CG",
                    253 => "DJ",
                    20 => "EG",
                    240 => "GQ",
                    291 => "ER",
                    251 => "ET",
                    241 => "GA",
                    220 => "GM",
                    233 => "GH",
                    224 => "GN",
                    245 => "GW",
                    225 => "CI",
                    254 => "KE",
                    266 => "LS",
                    231 => "LR",
                    218 => "LY",
                    261 => "MG",
                    265 => "MW",
                    223 => "ML",
                    222 => "MR",
                    230 => "MU",
                    212 => "MA",
                    258 => "MZ",
                    264 => "NA",
                    227 => "NE",
                    250 => "RW",
                    290 => "SH",
                    221 => "SN",
                    248 => "SC",
                    232 => "SL",
                    252 => "SO",
                    27 => "ZA",
                    249 => "SD",
                    268 => "SZ",
                    239 => "ST",
                    255 => "TZ",
                    228 => "TG",
                    216 => "TN",
                    256 => "UG",
                    260 => "ZM",
                    263 => "ZW",
                    262 => "TF",
                    93 => "AF",
                    374 => "AM",
                    994 => "AZ",
                    973 => "BH",
                    880 => "BD",
                    975 => "BT",
                    673 => "BN",
                    855 => "KH",
                    86 => "CN",
                    995 => "GE",
                    852 => "HK",
                    62 => "ID",
                    98 => "IR",
                    964 => "IQ",
                    972 => "IL",
                    81 => "JP",
                    962 => "JO",
                    7 => "KZ",
                    965 => "KW",
                    996 => "KG",
                    856 => "LA",
                    961 => "LB",
                    853 => "MO",
                    60 => "MY",
                    960 => "MV",
                    976 => "MN",
                    95 => "MM",
                    977 => "NP",
                    850 => "KP",
                    968 => "OM",
                    92 => "PK",
                    970 => "PS",
                    63 => "PH",
                    974 => "QA",
                    966 => "SA",
                    82 => "KR",
                    94 => "LK",
                    963 => "SY",
                    886 => "TW",
                    992 => "TJ",
                    66 => "TH",
                    90 => "TR",
                    993 => "TM",
                    971 => "AE",
                    998 => "UZ",
                    84 => "VN",
                    967 => "YE",
                    355 => "AL",
                    376 => "AD",
                    43 => "AT",
                    375 => "BY",
                    32 => "BE",
                    387 => "BA",
                    359 => "BG",
                    385 => "HR",
                    357 => "CY",
                    420 => "CZ",
                    45 => "DK",
                    372 => "EE",
                    298 => "FO",
                    358 => "FI",
                    33 => "FR",
                    49 => "DE",
                    350 => "GI",
                    30 => "GR",
                    36 => "HU",
                    354 => "IS",
                    353 => "IE",
                    39 => "IT",
                    383 => "XK",
                    371 => "LV",
                    423 => "LI",
                    370 => "LT",
                    352 => "LU",
                    389 => "MK",
                    356 => "MT",
                    373 => "MD",
                    377 => "MC",
                    382 => "ME",
                    31 => "NL",
                    47 => "NO",
                    48 => "PL",
                    351 => "PT",
                    40 => "RO",
                    79 => "RU",
                    378 => "SM",
                    381 => "RS",
                    421 => "SK",
                    386 => "SI",
                    34 => "ES",
                    46 => "SE",
                    41 => "CH",
                    380 => "UA",
                    44 => "GB",
                    297 => "AW",
                    501 => "BZ",
                    599 => "BQ",
                    506 => "CR",
                    53 => "CU",
                    503 => "SV",
                    299 => "GL",
                    502 => "GT",
                    509 => "HT",
                    504 => "HN",
                    596 => "MQ",
                    52 => "MX",
                    505 => "NI",
                    507 => "PA",
                    590 => "BL",
                    508 => "PM",
                    54 => "AR",
                    591 => "BO",
                    55 => "BR",
                    56 => "CL",
                    57 => "CO",
                    593 => "EC",
                    500 => "FK",
                    594 => "GF",
                    595 => "PY",
                    51 => "PE",
                    597 => "SR",
                    598 => "UY",
                    58 => "VE",
                    61 => "AU",
                    682 => "CK",
                    670 => "TL",
                    679 => "FJ",
                    689 => "PF",
                    686 => "KI",
                    692 => "MH",
                    691 => "FM",
                    674 => "NR",
                    687 => "NC",
                    64 => "NZ",
                    683 => "NU",
                    672 => "NF",
                    680 => "PW",
                    675 => "PG",
                    685 => "WS",
                    677 => "SB",
                    690 => "TK",
                    676 => "TO",
                    688 => "TV",
                    678 => "VU",
                    681 => "WF",
                    234 => "NG" 
        );
        
        krsort( $ccodes );

        $iso = '';
        
        foreach( $ccodes as $key=>$value )
            {
                if ( substr( $msisdn, 0, strlen( $key ) ) == $key )
                {
                    // match
                    $iso = $value;
                    break;
                }
            }
        
        return $iso;
    }

/*
Takes in all contacts and outputs arrays of contacts as associative array with details like dynamic text, sms count etc
*/

    public function sortContacts($data, $params){
        //tasks outside the loop
        $replaceurl = 0;
        $dupcount = 0;
        $totalsubmitted = 0;
        $totalsmscount = 0; //total number of contacts * persmscount, this would be credits required for credit based account
        $dynamicsmstotal = 0; //dynamic sms: now the length of the sms is going to be different because for each contact the sms text is changing
        $dynurls = array();
        $finalcontacts = array();
        $uploadcontacts = array();
        $invalidcontacts = array();
        $blmatchedcontacts = array();
        $uniquecontacts = array();
        $dlrfilcontacts = array();
        $droppedcontacts = array();
        $fakedlrcontacts_del = array();
        $fakedlrcontacts_undel = array();
        $fakedlrcontacts_exp = array();
        $routewisecontacts = array(); // this is for currency based account
        $currencybasecost = 0; // this is the total cost of all the sms for currency based account
        Doo::loadHelper('DooTextHelper');
        Doo::loadHelper('DooFile');
        $fhobj = new DooFile;
        //check if dynamic url is present
        //check if personalize
        $pos = strpos($params["smstext"], Doo::conf()->tinyurl);
        if($params['smstype']['personalize']==1 && $pos !== false){
            $urlidf = substr($params["smstext"], $pos + strlen(Doo::conf()->tinyurl) + 1, 6);
            $turlobj = Doo::loadModel('ScShortUrlsMaster',true);
            $turlobj->url_idf = $urlidf;
            $urldata = Doo::db()->find($turlobj,array('select'=>'id,type','limit'=>1));

            if(intval($urldata->type)!=0){
                $replaceurl = 1;
            }
        }

        if($data['phonebookFlag']==1){
            $phonebooknums = $this->getPhonebookContacts($data, $params);
            foreach($phonebooknums as $phn){
                $mdata = array();
                //1. duplicate check
                if($data['duplicateFlag']==1){
                    if(in_array($phn->mobile, $uniquecontacts)){
                        $dupcount++;
                        continue;
                    }
                    array_push($uniquecontacts, $phn->mobile);
                }

                if($params['account_type']==1){
                    $mobile = intval($phn->mobile);
                    $mdata['mobile'] = $mobile;
                    $mdata['text'] = '';
                    $mdata['smslen'] = 0; //counted later
                    $mdata['smscount'] = 0; //counted later
                    //currency based user, get mccmnc and route and per sms cost
                    //2. Get country ISO based on prefix
                    $iso = DooSmppcubeHelper::getCountryIso($mobile);
                    if($iso==''){
                        //invalid number
                        array_push($invalidcontacts, $mdata);
                        continue;
                    }else{
                        //3. Based on ISO get coverage data for valid length and operator prefix length. Extract operator prefix from this
                        //get coverage details like prefix and NSN prefix length
                        $cvmap = function($c)use($iso) {return $c->country_code == $iso;};
                        $cvfilter = array_filter($params['coverages'], $cvmap); 
                        $k = key($cvfilter);
                        //4. Based on operator prefix get MCCMNC code
                        $pfx = substr($mobile, strlen($params['coverages'][$k]->prefix)-1, intval($params['coverages'][$k]->network_idn_pre_len));
                        $pmap = function($p)use($pfx) {return $p->prefix == $pfx;}; 
                        $pfxfilobj = array_filter($params['prefixes'], $pmap); 
                        $pk = key($pfxfilobj);
            
                        //5. get price for the mcc mnc according to this plan
                        $mccmnc = $params['prefixes'][$pk]->mccmnc;
                        $mnmap = function($m)use($mccmnc) {return $m->mccmnc == $mccmnc;}; 
                        $mplanfilter = array_filter($params['smsplan']['pricing'], $mnmap); 
                        $mk = key($mplanfilter);
                        if($mccmnc=='0' || !$mccmnc){
                            //no mccmnc matched, use default route pricing
                            $routeid = $params['smsplan']['routesniso'][intval($params['coverages'][$k]->prefix)];
                            $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                            $routefilobj = array_filter($params['routes'], $rmap); 
                            $rk = key($routefilobj);
                            $persmsprice = $params['routes'][$rk]->default_selling_price;
                            $mdata['routeid'] = $routeid;
                        }else{
                            $persmsprice = floatval($params['smsplan']['pricing'][$mk]->price);
                            $routeid = $params['smsplan']['pricing'][$mk]->route_id;
                            //get route info
                            $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                            $routefilobj = array_filter($params['routes'], $rmap); 
                            $rk = key($routefilobj);
                        }
                        $mdata['smscost'] = $persmsprice;
                        $mdata['routeid'] = $routeid;
                        $mdata['mccmnc'] = $mccmnc;
                        //3. Replace URL if applicable
                        if($replaceurl==1){
                            $uid = $params['userid'];
                            $turl = $this->generateUrlIdf($uid, 7);
                            $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                            //prepare the sql string
                            $durl = array();
                            $durl['parent_url_id'] = $urldata->id;
                            $durl['url_idf'] = $turl;
                            $durl['sms_shoot_id'] = $params['shootid'];
                            $durl['mobile'] = $mobile;
                            array_push($dynurls,$durl);
                        }else{
                            $dyn_text = $params['smstext'];
                        }
                        $mdata['mobile'] = $mobile;
                        $mdata['text'] = $dyn_text;
                        //get sms cost based on sms count
                        $creditruleid = $params['routes'][$rk]->credit_rule;
                        $ccmap = function($cc)use($creditruleid) {return $cc->id == $creditruleid;}; 
                        $ccfilobj = array_filter($params['countrules'], $ccmap); 
                        $cck = key($ccfilobj);
                        $normal_ccrule = unserialize($params['countrules'][$cck]->normal_sms_rule);
                        $unicode_ccrule = unserialize($params['countrules'][$cck]->unicode_rule);
                        $spcl_rule = unserialize($params['countrules'][$cck]->special_chars_rule);
                        $spcl_ccrule = $spcl_rule['counts'];
                        $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $dyn_text);
                        $mdata['smslen'] = $countdata['length'];
                        $mdata['smscount'] = $countdata['count'];
                        $smscost = $mdata['smscost'] * intval($countdata['count']);
                        $mdata['smscost'] = $smscost;
                        if(intval($routeid)!=0){
                            //6. Invalid check
                            if($data['invalidFlag']==1){
                                if(!DooTextHelper::verifyFormData('mobile',$mobile,explode(",",$params['coverages'][$k]->valid_lengths))){
                                    array_push($invalidcontacts, $mdata);
                                    continue;
                                }
                            }
                            //7. Blacklist filter
                            if($params['routes'][$rk]->blacklist_ids!=''){
                                $dbs = explode(",",$params['routes'][$rk]->blacklist_ids);
                                foreach($dbs as $db){
                                    if($this->checkBlacklistMatch($db, $mobile)){
                                        array_push($blmatchedcontacts, $mdata);
                                        continue;
                                    }
                                }
                            }
                        }else{
                            //unable to match any routes consider this invalid
                            array_push($invalidcontacts, $mdata);
                            continue;
                        }
                        
                        //7. Save data in array so the final contacts as grouped based on route id
                        if(!is_array($routewisecontacts[$routeid]['mobiles'])) $routewisecontacts[$routeid]['mobiles'] = array();
                        $currencybasecost += $persmsprice;
                        $routewisecontacts[$routeid]['costperroute'] = floatval($routewisecontacts[$routeid]['costperroute']) + $smscost;
                        $routewisecontacts[$routeid]['smpp'] = $params['routes'][$rk]->smpp_id;
                        array_push($routewisecontacts[$routeid]['mobiles'], $mdata);
                    }
                }else{
                    //credit based account
                    //2. Add country prefix if applicable
                    if($params['routedata']->add_pre!='0'){
                        $mobile = strlen($phn->mobile) < max($params['validlengths']) ? intval($params['countryPrefix'].$phn->mobile) :  intval($phn->mobile);
                    }else{
                        $mobile = intval($phn->mobile);
                    }
                    //3. Replace URL if applicable
                    if($replaceurl==1){
                        $uid = $params['userid'];
                        $turl = $this->generateUrlIdf($uid, 7);
                        $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                        //prepare the sql string
                        $durl = array();
                        $durl['parent_url_id'] = $urldata->id;
                        $durl['url_idf'] = $turl;
                        $durl['sms_shoot_id'] = $params['shootid'];
                        $durl['mobile'] = $mobile;
                        array_push($dynurls,$durl);
                    }else{
                        $dyn_text = $params['smstext'];
                    }
                    $mdata['mobile'] = $mobile;
                    $mdata['text'] = $dyn_text;
                    $mdata['smslen'] = 0; //counted later
                    $mdata['smscount'] = 0; //counted later

                    //4. get dynamic sms text and sms count
                    if($params['smstype']['personalize']==1){
                        $countdata = $this->getSmsCount(array('specialrule'=>$params['specialcountRule'], 'unicoderule'=>$params['unicodecountRule'], 'normalrule'=>$params['normalcountRule'], 'smstype'=>$params['smstype']), $dyn_text);
                        $mdata['smslen'] = $countdata['length'];
                        $mdata['smscount'] = $countdata['count'];
                    }
                    //5. invalid check
                    if($data['invalidFlag']==1){
                        if(!DooTextHelper::verifyFormData('mobile',$phn->mobile,$params['validlengths'])){
                            array_push($invalidcontacts, $mdata);
                            continue;
                        }
                    }
                    //6. Check and remove blacklist
                    if($params['routedata']->blacklist_ids!=''){
                        $dbs = explode(",",$params['routedata']->blacklist_ids);
                        foreach($dbs as $db){
                            if($this->checkBlacklistMatch($db, $mobile)){
                                array_push($blmatchedcontacts, $mdata);
                                continue;
                            }
                        }
                    }
                    $dynamicsmstotal += $mdata['smscount'];
                    array_push($finalcontacts, $mdata);
                }
            }
            //perform after loop tasks
            if(sizeof($dynurls)>0){
                $dynturlobj = Doo::loadModel('ScShortUrlsMsisdnMap', true);
                $dynturlobj->addData($dynurls);
            }
            
        }else{
            //contacts supplied by user
            //loop through each mode of contact supply and perform above 4 tasks for each mode
            //read text input only if non-dynamic sms
            if($params['smstype']['personalize']!=1){
                if(sizeof($data['inputbox'])>0){
                    foreach($data['inputbox'] as $txtcel){
                        $mdata = array();
                        $mobile = intval($txtcel);
                        if($mobile!=0){
                            $totalsubmitted++;
                            //1. duplicate check
                            if($data['duplicateFlag']==1){
                                if(in_array($mobile, $uniquecontacts)){
                                    $dupcount++;
                                    continue;
                                }
                                array_push($uniquecontacts, $mobile);
                            }
                            
                            $mdata['mobile'] = $mobile;
                            $mdata['text'] = '';
                            $mdata['smslen'] = 0; //counted later
                            $mdata['smscount'] = 0; //counted later
                            
                            if($params['account_type']==1){
                                //currency based user, get mccmnc and route and per sms cost
                                //2. Get country ISO based on prefix
                                $iso = DooSmppcubeHelper::getCountryIso($mobile);
                                if($iso==''){
                                    //invalid number
                                    array_push($invalidcontacts, $mdata);
                                    continue;
                                }else{
                                    //3. Based on ISO get coverage data for valid length and operator prefix length. Extract operator prefix from this
                                    //get coverage details like prefix and NSN prefix length
                                    $cvmap = function($c)use($iso) {return $c->country_code == $iso;};
                                    $cvfilter = array_filter($params['coverages'], $cvmap); 
                                    $k = key($cvfilter);
                                    //4. Based on operator prefix get MCCMNC code
                                    $pfx = substr($mobile, strlen($params['coverages'][$k]->prefix)-1, intval($params['coverages'][$k]->network_idn_pre_len));
                                    $pmap = function($p)use($pfx) {return $p->prefix == $pfx;}; 
                                    $pfxfilobj = array_filter($params['prefixes'], $pmap); 
                                    $pk = key($pfxfilobj);
                        
                                    //5. get price for the mcc mnc according to this plan
                                    $mccmnc = $params['prefixes'][$pk]->mccmnc;
                                    $mnmap = function($m)use($mccmnc) {return $m->mccmnc == $mccmnc;}; 
                                    $mplanfilter = array_filter($params['smsplan']['pricing'], $mnmap); 
                                    $mk = key($mplanfilter);
                                    if($mccmnc=='0' || !$mccmnc){
                                        //no mccmnc matched, use default route pricing
                                        $routeid = $params['smsplan']['routesniso'][intval($params['coverages'][$k]->prefix)];
                                        $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                        $routefilobj = array_filter($params['routes'], $rmap); 
                                        $rk = key($routefilobj);
                                        $persmsprice = $params['routes'][$rk]->default_selling_price;
                                        $mdata['routeid'] = $routeid;
                                    }else{
                                        $persmsprice = floatval($params['smsplan']['pricing'][$mk]->price);
                                        $routeid = $params['smsplan']['pricing'][$mk]->route_id;
                                        //get route info
                                        $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                        $routefilobj = array_filter($params['routes'], $rmap); 
                                        $rk = key($routefilobj);
                                    }
                                    $mdata['smscost'] = $persmsprice;
                                    $mdata['routeid'] = $routeid;
                                    $mdata['mccmnc'] = $mccmnc;
                                    //get sms cost based on sms count
                                    $creditruleid = $params['routes'][$rk]->credit_rule;
                                    $ccmap = function($cc)use($creditruleid) {return $cc->id == $creditruleid;}; 
                                    $ccfilobj = array_filter($params['countrules'], $ccmap); 
                                    $cck = key($ccfilobj);
                                    $normal_ccrule = unserialize($params['countrules'][$cck]->normal_sms_rule);
                                    $unicode_ccrule = unserialize($params['countrules'][$cck]->unicode_rule);
                                    $spcl_rule = unserialize($params['countrules'][$cck]->special_chars_rule);
                                    $spcl_ccrule = $spcl_rule['counts'];
                                    $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $dyn_text);
                                    $mdata['smslen'] = $countdata['length'];
                                    $mdata['smscount'] = $countdata['count'];
                                    $smscost = $mdata['smscost'] * intval($countdata['count']);
                                    $mdata['smscost'] = $smscost;
                                    if(intval($routeid)!=0){
                                        //6. Invalid check
                                        if($data['invalidFlag']==1){
                                            if(!DooTextHelper::verifyFormData('mobile',$mobile,explode(",",$params['coverages'][$k]->valid_lengths))){
                                                array_push($invalidcontacts, $mdata);
                                                continue;
                                            }
                                        }
                                        //7. Blacklist filter
                                        if($params['routes'][$rk]->blacklist_ids!=''){
                                            $dbs = explode(",",$params['routes'][$rk]->blacklist_ids);
                                            foreach($dbs as $db){
                                                if($this->checkBlacklistMatch($db, $mobile)){
                                                    array_push($blmatchedcontacts, $mdata);
                                                    continue;
                                                }
                                            }
                                        }
                                    }else{
                                        //unable to match any routes consider this invalid
                                        array_push($invalidcontacts, $mdata);
                                        continue;
                                    }
                                    
                                    //7. Save data in array so the final contacts as grouped based on route id
                                    if(!is_array($routewisecontacts[$routeid]['mobiles'])) $routewisecontacts[$routeid]['mobiles'] = array();
                                    $currencybasecost += $persmsprice;
                                    $routewisecontacts[$routeid]['costperroute'] = floatval($routewisecontacts[$routeid]['costperroute']) + $smscost;
                                    $routewisecontacts[$routeid]['smpp'] = $params['routes'][$rk]->smpp_id;
                                    array_push($routewisecontacts[$routeid]['mobiles'], $mdata);
                                }

                            }else{
                                //credit based system, proceed as usual
                                //2. Add country prefix if applicable
                                if($params['routedata']->add_pre!='0'){
                                    $mobile = strlen($mobile) < max($params['validlengths']) ? intval($params['countryPrefix'].$mobile) :  $mobile;
                                }
                                //3. invalid check
                                if($data['invalidFlag']==1){
                                    if(!DooTextHelper::verifyFormData('mobile',$mobile,$params['validlengths'])){
                                        array_push($invalidcontacts, $mdata);
                                        continue;
                                    }
                                }
                                //4. Check and remove blacklist
                                if($params['routedata']->blacklist_ids!=''){
                                    $dbs = explode(",",$params['routedata']->blacklist_ids);
                                    foreach($dbs as $db){
                                        if($this->checkBlacklistMatch($db, $mobile)){
                                            array_push($blmatchedcontacts, $mdata);
                                            continue;
                                        }
                                    }
                                }
                                $dynamicsmstotal += $mdata['smscount'];
                                array_push($finalcontacts, $mdata);
                            }

                            
                        }
                    }
                }
            }
            //read contact group data for both dynamic and non dynamic sms
            if(sizeof($data['groupdata'])>0){
                $grp_ids = $params['smstype']['personalize']==1 ? intval($data['groupdata'][0]) : implode(",",$data['groupdata']);
                $ucobj = Doo::loadModel('ScUserContacts', true);
                $group_contacts = $ucobj->getGroupsContact($grp_ids);

                foreach ($group_contacts as $grpdata){
                    $totalsubmitted++;
                    $mdata = array();
                    $grpcel = intval(trim($grpdata->mobile));
                    //1. duplicate check
                    if($data['duplicateFlag']==1){
                        if(in_array($grpcel, $uniquecontacts)){
                            $dupcount++;
                            continue;
                        }
                        array_push($uniquecontacts, $grpcel);
                    }

                    if($params['account_type']==1){
                        //currency based user, get mccmnc and route and per sms cost
                        //2. Get country ISO based on prefix
                        $mobile = $grpcel;
                        $iso = DooSmppcubeHelper::getCountryIso($mobile);
                        $mdata['mobile'] = $mobile;
                        $mdata['text'] = $params['smstext'];
                        if($iso==''){
                            //invalid number
                            array_push($invalidcontacts, $mdata);
                            continue;
                        }else{
                            //3. Based on ISO get coverage data for valid length and operator prefix length. Extract operator prefix from this
                            //get coverage details like prefix and NSN prefix length
                            $cvmap = function($c)use($iso) {return $c->country_code == $iso;};
                            $cvfilter = array_filter($params['coverages'], $cvmap); 
                            $k = key($cvfilter);
                            //4. Based on operator prefix get MCCMNC code
                            $pfx = substr($mobile, strlen($params['coverages'][$k]->prefix)-1, intval($params['coverages'][$k]->network_idn_pre_len));
                            $pmap = function($p)use($pfx) {return $p->prefix == $pfx;}; 
                            $pfxfilobj = array_filter($params['prefixes'], $pmap); 
                            $pk = key($pfxfilobj);
                
                            //5. get price for the mcc mnc according to this plan
                            $mccmnc = $params['prefixes'][$pk]->mccmnc;
                            $mnmap = function($m)use($mccmnc) {return $m->mccmnc == $mccmnc;}; 
                            $mplanfilter = array_filter($params['smsplan']['pricing'], $mnmap); 
                            $mk = key($mplanfilter);
                            if($mccmnc=='0' || !$mccmnc){
                                //no mccmnc matched, use default route pricing
                                $routeid = $params['smsplan']['routesniso'][intval($params['coverages'][$k]->prefix)];
                                $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                $routefilobj = array_filter($params['routes'], $rmap); 
                                $rk = key($routefilobj);
                                $persmsprice = $params['routes'][$rk]->default_selling_price;
                                $mdata['routeid'] = $routeid;
                            }else{
                                $persmsprice = floatval($params['smsplan']['pricing'][$mk]->price);
                                $routeid = $params['smsplan']['pricing'][$mk]->route_id;
                                //get route info
                                $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                $routefilobj = array_filter($params['routes'], $rmap); 
                                $rk = key($routefilobj);
                            }
                            $mdata['smscost'] = $persmsprice;
                            $mdata['routeid'] = $routeid;
                            $mdata['mccmnc'] = $mccmnc;

                            //3. Replace URL if applicable
                            if($replaceurl==1){
                                $uid = $params['userid'];
                                $turl = $this->generateUrlIdf($uid, 7);
                                $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                                //prepare the sql string
                                $durl = array();
                                $durl['parent_url_id'] = $urldata->id;
                                $durl['url_idf'] = $turl;
                                $durl['sms_shoot_id'] = $params['shootid'];
                                $durl['mobile'] = $mobile;
                                array_push($dynurls,$durl);
                            }else{
                                $dyn_text = $params['smstext'];
                            }
                            $mdata['mobile'] = $mobile;
                            $mdata['text'] = $dyn_text;

                            //4. Get dynamic SMS if applicable
                            //get credit rule data
                            $creditruleid = $params['routes'][$rk]->credit_rule;
                            $ccmap = function($cc)use($creditruleid) {return $cc->id == $creditruleid;}; 
                            $ccfilobj = array_filter($params['countrules'], $ccmap); 
                            $cck = key($ccfilobj);
                            $normal_ccrule = unserialize($params['countrules'][$cck]->normal_sms_rule);
                            $unicode_ccrule = unserialize($params['countrules'][$cck]->unicode_rule);
                            $spcl_rule = unserialize($params['countrules'][$cck]->special_chars_rule);
                            $spcl_ccrule = $spcl_rule['counts'];
                            if($params['smstype']['personalize']==1){
                                $dyn_a = str_replace("#A#", $mobile, $dyn_text);
                                $dyn_b = str_replace("#B#", $grpdata->name, $dyn_a);
                                $dyn_c = str_replace("#C#", $grpdata->varC, $dyn_b);
                                $dyn_d = str_replace("#D#", $grpdata->varD, $dyn_c);
                                $dyn_e = str_replace("#E#", $grpdata->varE, $dyn_d);
                                $dyn_f = str_replace("#F#", $grpdata->varF, $dyn_e);
                                $finaltext = str_replace("#G#", $grpdata->varG, $dyn_f);
                                $mdata['text'] = $finaltext;
                                $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $finaltext);
                                $mdata['smslen'] = $countdata['length'];
                                $mdata['smscount'] = $countdata['count'];
                                $smscost = $mdata['smscost']* intval($countdata['count']);
                            }else{
                                $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $finaltext);
                                $mdata['smslen'] = $countdata['length'];
                                $mdata['smscount'] = $countdata['count'];
                                $smscost = $mdata['smscost']* intval($countdata['count']);
                            }
                            $mdata['smscost'] = $smscost;
                            if(intval($routeid)!=0){
                                //6. Invalid check
                                if($data['invalidFlag']==1){
                                    if(!DooTextHelper::verifyFormData('mobile',$mobile,explode(",",$params['coverages'][$k]->valid_lengths))){
                                        array_push($invalidcontacts, $mdata);
                                        continue;
                                    }
                                }
                                //7. Blacklist filter
                                if($params['routes'][$rk]->blacklist_ids!=''){
                                    $dbs = explode(",",$params['routes'][$rk]->blacklist_ids);
                                    foreach($dbs as $db){
                                        if($this->checkBlacklistMatch($db, $mobile)){
                                            array_push($blmatchedcontacts, $mdata);
                                            continue;
                                        }
                                    }
                                }
                            }else{
                                //unable to match any routes consider this invalid
                                array_push($invalidcontacts, $mdata);
                                continue;
                            }
                            
                            //7. Save data in array so the final contacts as grouped based on route id
                            if(!is_array($routewisecontacts[$routeid]['mobiles'])) $routewisecontacts[$routeid]['mobiles'] = array();
                            $currencybasecost += $smscost;
                            $routewisecontacts[$routeid]['costperroute'] = floatval($routewisecontacts[$routeid]['costperroute']) + $smscost;
                            $routewisecontacts[$routeid]['smpp'] = $params['routes'][$rk]->smpp_id;
                            array_push($routewisecontacts[$routeid]['mobiles'], $mdata);
                        }

                    }else{
                        //credit based account
                        //2. Add country prefix if applicable
                        if($params['routedata']->add_pre!='0'){
                            $mobile = strlen($grpcel) < max($params['validlengths']) ? intval($params['countryPrefix'].$grpcel) :  $grpcel;
                        }else{
                            $mobile = $grpcel;
                        }
                        //3. Replace URL if applicable
                        if($replaceurl==1){
                            $uid = $params['userid'];
                            $turl = $this->generateUrlIdf($uid, 7);
                            $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                            //prepare the sql string
                            $durl = array();
                            $durl['parent_url_id'] = $urldata->id;
                            $durl['url_idf'] = $turl;
                            $durl['sms_shoot_id'] = $params['shootid'];
                            $durl['mobile'] = $mobile;
                            array_push($dynurls,$durl);
                        }else{
                            $dyn_text = $params['smstext'];
                        }
                        $mdata['mobile'] = $mobile;
                        $mdata['text'] = $dyn_text;
                        $mdata['smslen'] = 0; //counted later
                        $mdata['smscount'] = 0; //counted later

                        //4. Get dynamic SMS if applicable
                        if($params['smstype']['personalize']==1){
                            $dyn_a = str_replace("#A#", $mobile, $dyn_text);
                            $dyn_b = str_replace("#B#", $grpdata->name, $dyn_a);
                            $dyn_c = str_replace("#C#", $grpdata->varC, $dyn_b);
                            $dyn_d = str_replace("#D#", $grpdata->varD, $dyn_c);
                            $dyn_e = str_replace("#E#", $grpdata->varE, $dyn_d);
                            $dyn_f = str_replace("#F#", $grpdata->varF, $dyn_e);
                            $finaltext = str_replace("#G#", $grpdata->varG, $dyn_f);
                            $mdata['text'] = $finaltext;
                            $countdata = $this->getSmsCount(array('specialrule'=>$params['specialcountRule'], 'unicoderule'=>$params['unicodecountRule'], 'normalrule'=>$params['normalcountRule'], 'smstype'=>$params['smstype']), $finaltext);
                            $mdata['smslen'] = $countdata['length'];
                            $mdata['smscount'] = $countdata['count'];
                        }
                        //5. invalid check
                        if($data['invalidFlag']==1){
                            if(!DooTextHelper::verifyFormData('mobile',$mobile,$params['validlengths'])){
                                array_push($invalidcontacts, $mdata);
                                continue;
                            }
                        }
                        
                        //6. Check and remove blacklist
                        if($params['routedata']->blacklist_ids!=''){
                            $dbs = explode(",",$params['routedata']->blacklist_ids);
                            foreach($dbs as $db){
                                if($this->checkBlacklistMatch($db, $mobile)){
                                    array_push($blmatchedcontacts, $mdata);
                                    continue;
                                }
                            }
                        }
                        $dynamicsmstotal += $mdata['smscount'];
                        array_push($finalcontacts, $mdata);
                    }
                    
                }
            }
            //read supplied file and read data for each file type
            if($data['filedata']['name']!=''){
                $filepath = Doo::conf()->global_upload_dir.$data['filedata']['name'];
                $ext = strtolower($fhobj->getFileExtensionFromPath($filepath,true));

                Doo::loadHelper('PHPExcel');
                $filetype = PHPExcel_IOFactory::identify($filepath);
                $objReader = PHPExcel_IOFactory::createReader($filetype);
                $xlobj = $objReader->load($filepath);
                //Only one of the following cases will be true as file can only be one type
                //LOOP THROUGH EXCEL FILE
                if($ext=='xls'||$ext=='xlsx'){
                    $sheet = $xlobj->getSheetByName($data['filedata']['sheet']);
                    $highestrow =  $sheet->getHighestRow();
                    for($i=2; $i<=$highestrow; $i++){
                        $mdata = array();
                        $mobile = floatval(trim($sheet->getCell($data['filedata']['column'].$i)->getValue()));
                        if($mobile!=0){
                            $totalsubmitted++;
                            //1. duplicate check
                            if($data['duplicateFlag']==1){
                                if(in_array($mobile, $uniquecontacts)){
                                    $dupcount++;
                                    continue;
                                }
                                array_push($uniquecontacts, $mobile);
                            }

                            if($params['account_type']==1){
                                //currency based user, get mccmnc and route and per sms cost
                                //2. Get country ISO based on prefix
                                $iso = DooSmppcubeHelper::getCountryIso($mobile);
                                $mdata['mobile'] = $mobile;
                                $mdata['text'] = $params['smstext'];
                                if($iso==''){
                                    //invalid number
                                    array_push($invalidcontacts, $mdata);
                                    continue;
                                }else{
                                    //3. Based on ISO get coverage data for valid length and operator prefix length. Extract operator prefix from this
                                    //get coverage details like prefix and NSN prefix length
                                    $cvmap = function($c)use($iso) {return $c->country_code == $iso;};
                                    $cvfilter = array_filter($params['coverages'], $cvmap); 
                                    $k = key($cvfilter);
                                    //4. Based on operator prefix get MCCMNC code
                                    $pfx = substr($mobile, strlen($params['coverages'][$k]->prefix)-1, intval($params['coverages'][$k]->network_idn_pre_len));
                                    $pmap = function($p)use($pfx) {return $p->prefix == $pfx;}; 
                                    $pfxfilobj = array_filter($params['prefixes'], $pmap); 
                                    $pk = key($pfxfilobj);
                        
                                    //5. get price for the mcc mnc according to this plan
                                    $mccmnc = $params['prefixes'][$pk]->mccmnc;
                                    $mnmap = function($m)use($mccmnc) {return $m->mccmnc == $mccmnc;}; 
                                    $mplanfilter = array_filter($params['smsplan']['pricing'], $mnmap); 
                                    $mk = key($mplanfilter);
                                    if($mccmnc=='0' || !$mccmnc){
                                        //no mccmnc matched, use default route pricing
                                        $routeid = $params['smsplan']['routesniso'][intval($params['coverages'][$k]->prefix)];
                                        $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                        $routefilobj = array_filter($params['routes'], $rmap); 
                                        $rk = key($routefilobj);
                                        $persmsprice = $params['routes'][$rk]->default_selling_price;
                                        $mdata['routeid'] = $routeid;
                                    }else{
                                        $persmsprice = floatval($params['smsplan']['pricing'][$mk]->price);
                                        $routeid = $params['smsplan']['pricing'][$mk]->route_id;
                                        //get route info
                                        $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                        $routefilobj = array_filter($params['routes'], $rmap); 
                                        $rk = key($routefilobj);
                                    }
                                    $mdata['smscost'] = $persmsprice;
                                    $mdata['routeid'] = $routeid;
                                    $mdata['mccmnc'] = $mccmnc;

                                    //3. Replace URL if applicable
                                    if($replaceurl==1){
                                        $uid = $params['userid'];
                                        $turl = $this->generateUrlIdf($uid, 7);
                                        $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                                        //prepare the sql string
                                        $durl = array();
                                        $durl['parent_url_id'] = $urldata->id;
                                        $durl['url_idf'] = $turl;
                                        $durl['sms_shoot_id'] = $params['shootid'];
                                        $durl['mobile'] = $mobile;
                                        array_push($dynurls,$durl);
                                    }else{
                                        $dyn_text = $params['smstext'];
                                    }
                                    $mdata['mobile'] = $mobile;
                                    $mdata['text'] = $dyn_text;

                                    //4. Get dynamic SMS if applicable
                                    //get credit rule data
                                    $creditruleid = $params['routes'][$rk]->credit_rule;
                                    $ccmap = function($cc)use($creditruleid) {return $cc->id == $creditruleid;}; 
                                    $ccfilobj = array_filter($params['countrules'], $ccmap); 
                                    $cck = key($ccfilobj);
                                    $normal_ccrule = unserialize($params['countrules'][$cck]->normal_sms_rule);
                                    $unicode_ccrule = unserialize($params['countrules'][$cck]->unicode_rule);
                                    $spcl_rule = unserialize($params['countrules'][$cck]->special_chars_rule);
                                    $spcl_ccrule = $spcl_rule['counts'];
                                    if($params['smstype']['personalize']==1){
                                        $dyn_a = str_replace('#A#',$sheet->getCell('A'.$i)->getValue(),$dyn_text);
                                        $dyn_b = str_replace('#B#',$sheet->getCell('B'.$i)->getValue(),$dyn_a);
                                        $dyn_c = str_replace('#C#',$sheet->getCell('C'.$i)->getValue(),$dyn_b);
                                        $dyn_d = str_replace('#D#',$sheet->getCell('D'.$i)->getValue(),$dyn_c);
                                        $dyn_e = str_replace('#E#',$sheet->getCell('E'.$i)->getValue(),$dyn_d);
                                        $dyn_f = str_replace('#F#',$sheet->getCell('F'.$i)->getValue(),$dyn_e);
                                        $dyn_g = str_replace('#G#',$sheet->getCell('G'.$i)->getValue(),$dyn_f);
                                        $dyn_h = str_replace('#H#',$sheet->getCell('H'.$i)->getValue(),$dyn_g);
                                        $dyn_i = str_replace('#I#',$sheet->getCell('I'.$i)->getValue(),$dyn_h);
                                        $dyn_j = str_replace('#J#',$sheet->getCell('J'.$i)->getValue(),$dyn_i);
                                        $finaltext = str_replace('#K#',$sheet->getCell('K'.$i)->getValue(),$dyn_j);
                                        $mdata['text'] = $finaltext;
                                        $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $finaltext);
                                        $mdata['smslen'] = $countdata['length'];
                                        $mdata['smscount'] = $countdata['count'];
                                        $smscost = $mdata['smscost']* intval($countdata['count']);
                                    }else{
                                        $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $dyn_text);
                                        $mdata['smslen'] = $countdata['length'];
                                        $mdata['smscount'] = $countdata['count'];
                                        $smscost = $mdata['smscost']* intval($countdata['count']);
                                    }
                                    $mdata['smscost'] = $smscost;
                                    if(intval($routeid)!=0){
                                        //6. Invalid check
                                        if($data['invalidFlag']==1){
                                            if(!DooTextHelper::verifyFormData('mobile',$mobile,explode(",",$params['coverages'][$k]->valid_lengths))){
                                                array_push($invalidcontacts, $mdata);
                                                continue;
                                            }
                                        }
                                        //7. Blacklist filter
                                        if($params['routes'][$rk]->blacklist_ids!=''){
                                            $dbs = explode(",",$params['routes'][$rk]->blacklist_ids);
                                            foreach($dbs as $db){
                                                if($this->checkBlacklistMatch($db, $mobile)){
                                                    array_push($blmatchedcontacts, $mdata);
                                                    continue;
                                                }
                                            }
                                        }
                                    }else{
                                        //unable to match any routes consider this invalid
                                        array_push($invalidcontacts, $mdata);
                                        continue;
                                    }
                                    
                                    //7. Save data in array so the final contacts as grouped based on route id
                                    if(!is_array($routewisecontacts[$routeid]['mobiles'])) $routewisecontacts[$routeid]['mobiles'] = array();
                                    $currencybasecost += $smscost;
                                    $routewisecontacts[$routeid]['costperroute'] = floatval($routewisecontacts[$routeid]['costperroute']) + $smscost;
                                    $routewisecontacts[$routeid]['smpp'] = $params['routes'][$rk]->smpp_id;
                                    array_push($routewisecontacts[$routeid]['mobiles'], $mdata);
                                }
                            }else{
                                //credit based account
                                //2. Add country prefix if applicable
                                if($params['routedata']->add_pre!='0'){
                                    $mobile = strlen($mobile) < max($params['validlengths']) ? intval($params['countryPrefix'].$mobile) :  $mobile;
                                }
                                //3. Replace URL if applicable
                                if($replaceurl==1){
                                    $uid = $params['userid'];
                                    $turl = $this->generateUrlIdf($uid, 7);
                                    $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                                    //prepare the sql string
                                    $durl = array();
                                    $durl['parent_url_id'] = $urldata->id;
                                    $durl['url_idf'] = $turl;
                                    $durl['sms_shoot_id'] = $params['shootid'];
                                    $durl['mobile'] = $mobile;
                                    array_push($dynurls,$durl);
                                }else{
                                    $dyn_text = $params['smstext'];
                                }
                                $mdata['mobile'] = $mobile;
                                $mdata['text'] = $dyn_text;
                                $mdata['smslen'] = 0; //counted later
                                $mdata['smscount'] = 0; //counted later

                                //4. Get dynamic SMS if applicable
                                if($params['smstype']['personalize']==1){
                                    $dyn_a = str_replace('#A#',$sheet->getCell('A'.$i)->getValue(),$dyn_text);
                                    $dyn_b = str_replace('#B#',$sheet->getCell('B'.$i)->getValue(),$dyn_a);
                                    $dyn_c = str_replace('#C#',$sheet->getCell('C'.$i)->getValue(),$dyn_b);
                                    $dyn_d = str_replace('#D#',$sheet->getCell('D'.$i)->getValue(),$dyn_c);
                                    $dyn_e = str_replace('#E#',$sheet->getCell('E'.$i)->getValue(),$dyn_d);
                                    $dyn_f = str_replace('#F#',$sheet->getCell('F'.$i)->getValue(),$dyn_e);
                                    $dyn_g = str_replace('#G#',$sheet->getCell('G'.$i)->getValue(),$dyn_f);
                                    $dyn_h = str_replace('#H#',$sheet->getCell('H'.$i)->getValue(),$dyn_g);
                                    $dyn_i = str_replace('#I#',$sheet->getCell('I'.$i)->getValue(),$dyn_h);
                                    $dyn_j = str_replace('#J#',$sheet->getCell('J'.$i)->getValue(),$dyn_i);
                                    $finaltext = str_replace('#K#',$sheet->getCell('K'.$i)->getValue(),$dyn_j);
                                    $mdata['text'] = $finaltext;
                                    $countdata = $this->getSmsCount(array('specialrule'=>$params['specialcountRule'], 'unicoderule'=>$params['unicodecountRule'], 'normalrule'=>$params['normalcountRule'], 'smstype'=>$params['smstype']), $finaltext);
                                    $mdata['smslen'] = $countdata['length'];
                                    $mdata['smscount'] = $countdata['count'];
                                }
                                //5. invalid check
                                if($data['invalidFlag']==1){
                                    if(!DooTextHelper::verifyFormData('mobile',$mobile,$params['validlengths'])){
                                        array_push($invalidcontacts, $mdata);
                                        continue;
                                    }
                                }
                                //6. Check and remove blacklist
                                if($params['routedata']->blacklist_ids!=''){
                                    $dbs = explode(",",$params['routedata']->blacklist_ids);
                                    foreach($dbs as $db){
                                        if($this->checkBlacklistMatch($db, $mobile)){
                                            array_push($blmatchedcontacts, $mdata);
                                            continue;
                                        }
                                    }
                                }
                                $dynamicsmstotal += $mdata['smscount'];
                                array_push($finalcontacts, $mdata);
                            }

                        }
                    }
                }
                //LOOP THROGH CSV FILE
                if($filetype=='CSV' && $ext=='csv'){
                    $fh = fopen($filepath, 'r');
                    $fdata = fgetcsv($fh,0,"\r\n");
                    foreach($fdata as $csvstr){
                        $mdata = array();
                        $csvar = explode(",",$csvstr);
                        $mobile = floatval(trim($csvar[0]));
                        if($mobile!=0){
                            $totalsubmitted++;
                            //1. duplicate check
                            if($data['duplicateFlag']==1){
                                if(in_array($mobile, $uniquecontacts)){
                                    $dupcount++;
                                    continue;
                                }
                                array_push($uniquecontacts, $mobile);
                            }

                            if($params['account_type']==1){
                                //currency based user, get mccmnc and route and per sms cost
                                //2. Get country ISO based on prefix
                                $iso = DooSmppcubeHelper::getCountryIso($mobile);
                                $mdata['mobile'] = $mobile;
                                $mdata['text'] = $params['smstext'];
                                if($iso==''){
                                    //invalid number
                                    array_push($invalidcontacts, $mdata);
                                    continue;
                                }else{
                                    //3. Based on ISO get coverage data for valid length and operator prefix length. Extract operator prefix from this
                                    //get coverage details like prefix and NSN prefix length
                                    $cvmap = function($c)use($iso) {return $c->country_code == $iso;};
                                    $cvfilter = array_filter($params['coverages'], $cvmap); 
                                    $k = key($cvfilter);
                                    //4. Based on operator prefix get MCCMNC code
                                    $pfx = substr($mobile, strlen($params['coverages'][$k]->prefix)-1, intval($params['coverages'][$k]->network_idn_pre_len));
                                    $pmap = function($p)use($pfx) {return $p->prefix == $pfx;}; 
                                    $pfxfilobj = array_filter($params['prefixes'], $pmap); 
                                    $pk = key($pfxfilobj);
                        
                                    //5. get price for the mcc mnc according to this plan
                                    $mccmnc = $params['prefixes'][$pk]->mccmnc;
                                    $mnmap = function($m)use($mccmnc) {return $m->mccmnc == $mccmnc;}; 
                                    $mplanfilter = array_filter($params['smsplan']['pricing'], $mnmap); 
                                    $mk = key($mplanfilter);
                                    if($mccmnc=='0' || !$mccmnc){
                                        //no mccmnc matched, use default route pricing
                                        $routeid = $params['smsplan']['routesniso'][intval($params['coverages'][$k]->prefix)];
                                        $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                        $routefilobj = array_filter($params['routes'], $rmap); 
                                        $rk = key($routefilobj);
                                        $persmsprice = $params['routes'][$rk]->default_selling_price;
                                        $mdata['routeid'] = $routeid;
                                    }else{
                                        $persmsprice = floatval($params['smsplan']['pricing'][$mk]->price);
                                        $routeid = $params['smsplan']['pricing'][$mk]->route_id;
                                        //get route info
                                        $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                        $routefilobj = array_filter($params['routes'], $rmap); 
                                        $rk = key($routefilobj);
                                    }
                                    $mdata['smscost'] = $persmsprice;
                                    $mdata['routeid'] = $routeid;
                                    $mdata['mccmnc'] = $mccmnc;

                                    //3. Replace URL if applicable
                                    if($replaceurl==1){
                                        $uid = $params['userid'];
                                        $turl = $this->generateUrlIdf($uid, 7);
                                        $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                                        //prepare the sql string
                                        $durl = array();
                                        $durl['parent_url_id'] = $urldata->id;
                                        $durl['url_idf'] = $turl;
                                        $durl['sms_shoot_id'] = $params['shootid'];
                                        $durl['mobile'] = $mobile;
                                        array_push($dynurls,$durl);
                                    }else{
                                        $dyn_text = $params['smstext'];
                                    }
                                    $mdata['mobile'] = $mobile;
                                    $mdata['text'] = $dyn_text;

                                    //4. Get dynamic SMS if applicable
                                    //get credit rule data
                                    $creditruleid = $params['routes'][$rk]->credit_rule;
                                    $ccmap = function($cc)use($creditruleid) {return $cc->id == $creditruleid;}; 
                                    $ccfilobj = array_filter($params['countrules'], $ccmap); 
                                    $cck = key($ccfilobj);
                                    $normal_ccrule = unserialize($params['countrules'][$cck]->normal_sms_rule);
                                    $unicode_ccrule = unserialize($params['countrules'][$cck]->unicode_rule);
                                    $spcl_rule = unserialize($params['countrules'][$cck]->special_chars_rule);
                                    $spcl_ccrule = $spcl_rule['counts'];
                                    if($params['smstype']['personalize']==1){
                                        $dyn_a = str_replace("#A#",$mobile,$dyn_text);
                                        $dyn_b = str_replace("#B#",$csvar[1],$dyn_a);
                                        $dyn_c = str_replace("#C#",$csvar[2],$dyn_b);
                                        $dyn_d = str_replace("#D#",$csvar[3],$dyn_c);
                                        $dyn_e = str_replace("#E#",$csvar[4],$dyn_d);
                                        $dyn_f = str_replace("#F#",$csvar[5],$dyn_e);
                                        $finaltext = str_replace("#G#",$csvar[6],$dyn_f);
                                        $mdata['text'] = $finaltext;
                                        $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $finaltext);
                                        $mdata['smslen'] = $countdata['length'];
                                        $mdata['smscount'] = $countdata['count'];
                                        $smscost = $mdata['smscost']* intval($countdata['count']);
                                    }else{
                                        $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $dyn_text);
                                        $mdata['smslen'] = $countdata['length'];
                                        $mdata['smscount'] = $countdata['count'];
                                        $smscost = $mdata['smscost'] * intval($countdata['count']);
                                    }
                                    $mdata['smscost'] = $smscost;
                                    if(intval($routeid)!=0){
                                        //6. Invalid check
                                        if($data['invalidFlag']==1){
                                            if(!DooTextHelper::verifyFormData('mobile',$mobile,explode(",",$params['coverages'][$k]->valid_lengths))){
                                                array_push($invalidcontacts, $mdata);
                                                continue;
                                            }
                                        }
                                        //7. Blacklist filter
                                        if($params['routes'][$rk]->blacklist_ids!=''){
                                            $dbs = explode(",",$params['routes'][$rk]->blacklist_ids);
                                            foreach($dbs as $db){
                                                if($this->checkBlacklistMatch($db, $mobile)){
                                                    array_push($blmatchedcontacts, $mdata);
                                                    continue;
                                                }
                                            }
                                        }
                                    }else{
                                        //unable to match any routes consider this invalid
                                        array_push($invalidcontacts, $mdata);
                                        continue;
                                    }
                                    
                                    //7. Save data in array so the final contacts as grouped based on route id
                                    if(!is_array($routewisecontacts[$routeid]['mobiles'])) $routewisecontacts[$routeid]['mobiles'] = array();
                                    $currencybasecost += $smscost;
                                    $routewisecontacts[$routeid]['costperroute'] = floatval($routewisecontacts[$routeid]['costperroute']) + $smscost;
                                    $routewisecontacts[$routeid]['smpp'] = $params['routes'][$rk]->smpp_id;
                                    array_push($routewisecontacts[$routeid]['mobiles'], $mdata);
                                }

                            }else{
                                //credit based account
                                //2. Add country prefix if applicable
                                if($params['routedata']->add_pre!='0'){
                                    $mobile = strlen($mobile) < max($params['validlengths']) ? intval($params['countryPrefix'].$mobile) :  $mobile;
                                }
                                //3. Replace URL if applicable
                                if($replaceurl==1){
                                    $uid = $params['userid'];
                                    $turl = $this->generateUrlIdf($uid, 7);
                                    $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                                    //prepare the sql string
                                    $durl = array();
                                    $durl['parent_url_id'] = $urldata->id;
                                    $durl['url_idf'] = $turl;
                                    $durl['sms_shoot_id'] = $params['shootid'];
                                    $durl['mobile'] = $mobile;
                                    array_push($dynurls,$durl);
                                }else{
                                    $dyn_text = $params['smstext'];
                                }
                                $mdata['mobile'] = $mobile;
                                $mdata['text'] = $dyn_text;
                                $mdata['smslen'] = 0; //counted later
                                $mdata['smscount'] = 0; //counted later

                                //5. Get dynamic SMS if applicable
                                if($params['smstype']['personalize']==1){
                                    $dyn_a = str_replace("#A#",$mobile,$dyn_text);
                                    $dyn_b = str_replace("#B#",$csvar[1],$dyn_a);
                                    $dyn_c = str_replace("#C#",$csvar[2],$dyn_b);
                                    $dyn_d = str_replace("#D#",$csvar[3],$dyn_c);
                                    $dyn_e = str_replace("#E#",$csvar[4],$dyn_d);
                                    $dyn_f = str_replace("#F#",$csvar[5],$dyn_e);
                                    $finaltext = str_replace("#G#",$csvar[6],$dyn_f);
                                    $mdata['text'] = $finaltext;
                                    $countdata = $this->getSmsCount(array('specialrule'=>$params['specialcountRule'], 'unicoderule'=>$params['unicodecountRule'], 'normalrule'=>$params['normalcountRule'], 'smstype'=>$params['smstype']), $finaltext);
                                    $mdata['smslen'] = $countdata['length'];
                                    $mdata['smscount'] = $countdata['count'];
                                }

                                //3. invalid check
                                if($data['invalidFlag']==1){
                                    if(!DooTextHelper::verifyFormData('mobile',$mobile,$params['validlengths'])){
                                        array_push($invalidcontacts, $mdata);
                                        continue;
                                    }
                                }

                                //4. Check and remove blacklist
                                if($params['routedata']->blacklist_ids!=''){
                                    $dbs = explode(",",$params['routedata']->blacklist_ids);
                                    foreach($dbs as $db){
                                        if($this->checkBlacklistMatch($db, $mobile)){
                                            array_push($blmatchedcontacts, $mdata);
                                            continue;
                                        }
                                    }
                                }
                                $dynamicsmstotal += $mdata['smscount'];
                                array_push($finalcontacts, $mdata);
                            }   

                        }
                    }
                }
                //LOOP THROUGH TXT FILE
                if($filetype=='CSV' && $ext=='txt'){
                    $file_h = fopen($filepath, "r");
                    while(!feof($file_h)){
                        $mdata = array();
                        $mobile = floatval(trim(fgets($file_h)));
                        if($mobile!=0){
                            $totalsubmitted++;
                            //1. duplicate check
                            if($data['duplicateFlag']==1){
                                if(in_array($mobile, $uniquecontacts)){
                                    $dupcount++;
                                    continue;
                                }
                                array_push($uniquecontacts, $mobile);
                            }

                            if($params['account_type']==1){
                                //currency based user, get mccmnc and route and per sms cost
                                //2. Get country ISO based on prefix
                                $iso = DooSmppcubeHelper::getCountryIso($mobile);
                                $mdata['mobile'] = $mobile;
                                $mdata['text'] = $params['smstext'];
                                if($iso==''){
                                    //invalid number
                                    array_push($invalidcontacts, $mdata);
                                    continue;
                                }else{
                                    //3. Based on ISO get coverage data for valid length and operator prefix length. Extract operator prefix from this
                                    //get coverage details like prefix and NSN prefix length
                                    $cvmap = function($c)use($iso) {return $c->country_code == $iso;};
                                    $cvfilter = array_filter($params['coverages'], $cvmap); 
                                    $k = key($cvfilter);
                                    //4. Based on operator prefix get MCCMNC code
                                    $pfx = substr($mobile, strlen($params['coverages'][$k]->prefix)-1, intval($params['coverages'][$k]->network_idn_pre_len));
                                    $pmap = function($p)use($pfx) {return $p->prefix == $pfx;}; 
                                    $pfxfilobj = array_filter($params['prefixes'], $pmap); 
                                    $pk = key($pfxfilobj);
                        
                                    //5. get price for the mcc mnc according to this plan
                                    $mccmnc = $params['prefixes'][$pk]->mccmnc;
                                    $mnmap = function($m)use($mccmnc) {return $m->mccmnc == $mccmnc;}; 
                                    $mplanfilter = array_filter($params['smsplan']['pricing'], $mnmap); 
                                    $mk = key($mplanfilter);
                                    if($mccmnc=='0' || !$mccmnc){
                                        //no mccmnc matched, use default route pricing
                                        $routeid = $params['smsplan']['routesniso'][intval($params['coverages'][$k]->prefix)];
                                        $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                        $routefilobj = array_filter($params['routes'], $rmap); 
                                        $rk = key($routefilobj);
                                        $persmsprice = $params['routes'][$rk]->default_selling_price;
                                        $mdata['routeid'] = $routeid;
                                    }else{
                                        $persmsprice = floatval($params['smsplan']['pricing'][$mk]->price);
                                        $routeid = $params['smsplan']['pricing'][$mk]->route_id;
                                        //get route info
                                        $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                        $routefilobj = array_filter($params['routes'], $rmap); 
                                        $rk = key($routefilobj);
                                    }
                                    $mdata['smscost'] = $persmsprice;
                                    $mdata['routeid'] = $routeid;
                                    $mdata['mccmnc'] = $mccmnc;

                                    //3. Replace URL if applicable
                                    if($replaceurl==1){
                                        $uid = $params['userid'];
                                        $turl = $this->generateUrlIdf($uid, 7);
                                        $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                                        //prepare the sql string
                                        $durl = array();
                                        $durl['parent_url_id'] = $urldata->id;
                                        $durl['url_idf'] = $turl;
                                        $durl['sms_shoot_id'] = $params['shootid'];
                                        $durl['mobile'] = $mobile;
                                        array_push($dynurls,$durl);
                                    }else{
                                        $dyn_text = $params['smstext'];
                                    }
                                    $mdata['mobile'] = $mobile;
                                    $mdata['text'] = $dyn_text;

                                    //4. Get dynamic SMS if applicable
                                    //get credit rule data
                                    $creditruleid = $params['routes'][$rk]->credit_rule;
                                    $ccmap = function($cc)use($creditruleid) {return $cc->id == $creditruleid;}; 
                                    $ccfilobj = array_filter($params['countrules'], $ccmap); 
                                    $cck = key($ccfilobj);
                                    $normal_ccrule = unserialize($params['countrules'][$cck]->normal_sms_rule);
                                    $unicode_ccrule = unserialize($params['countrules'][$cck]->unicode_rule);
                                    $spcl_rule = unserialize($params['countrules'][$cck]->special_chars_rule);
                                    $spcl_ccrule = $spcl_rule['counts'];
                                    $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $dyn_text);
                                    $mdata['smslen'] = $countdata['length'];
                                    $mdata['smscount'] = $countdata['count'];
                                    $smscost = $mdata['smscost']* intval($countdata['count']);
                                    
                                    $mdata['smscost'] = $smscost;
                                    if(intval($routeid)!=0){
                                        //6. Invalid check
                                        if($data['invalidFlag']==1){
                                            if(!DooTextHelper::verifyFormData('mobile',$mobile,explode(",",$params['coverages'][$k]->valid_lengths))){
                                                array_push($invalidcontacts, $mdata);
                                                continue;
                                            }
                                        }
                                        //7. Blacklist filter
                                        if($params['routes'][$rk]->blacklist_ids!=''){
                                            $dbs = explode(",",$params['routes'][$rk]->blacklist_ids);
                                            foreach($dbs as $db){
                                                if($this->checkBlacklistMatch($db, $mobile)){
                                                    array_push($blmatchedcontacts, $mdata);
                                                    continue;
                                                }
                                            }
                                        }
                                    }else{
                                        //unable to match any routes consider this invalid
                                        array_push($invalidcontacts, $mdata);
                                        continue;
                                    }
                                    
                                    //7. Save data in array so the final contacts as grouped based on route id
                                    if(!is_array($routewisecontacts[$routeid]['mobiles'])) $routewisecontacts[$routeid]['mobiles'] = array();
                                    $currencybasecost += $smscost;
                                    $routewisecontacts[$routeid]['costperroute'] = floatval($routewisecontacts[$routeid]['costperroute']) + $smscost;
                                    $routewisecontacts[$routeid]['smpp'] = $params['routes'][$rk]->smpp_id;
                                    array_push($routewisecontacts[$routeid]['mobiles'], $mdata);
                                }
                            }else{
                                //credit based account
                                //2. Add country prefix if applicable
                                if($params['routedata']->add_pre!='0'){
                                    $mobile = strlen($mobile) < max($params['validlengths']) ? intval($params['countryPrefix'].$mobile) :  $mobile;
                                }
                                //3. Replace URL if applicable
                                if($replaceurl==1){
                                    $uid = $params['userid'];
                                    $turl = $this->generateUrlIdf($uid, 7);
                                    $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                                    //prepare the sql string
                                    $durl = array();
                                    $durl['parent_url_id'] = $urldata->id;
                                    $durl['url_idf'] = $turl;
                                    $durl['sms_shoot_id'] = $params['shootid'];
                                    $durl['mobile'] = $mobile;
                                    array_push($dynurls,$durl);
                                }else{
                                    $dyn_text = $params['smstext'];
                                }
                                $mdata['mobile'] = $mobile;
                                $mdata['text'] = $dyn_text;
                                $mdata['smslen'] = 0; //counted later
                                $mdata['smscount'] = 0; //counted later

                                //4. get dynamic sms text and sms count
                                if($params['smstype']['personalize']==1){
                                    $countdata = $this->getSmsCount(array('specialrule'=>$params['specialcountRule'], 'unicoderule'=>$params['unicodecountRule'], 'normalrule'=>$params['normalcountRule'], 'smstype'=>$params['smstype']), $dyn_text);
                                    $mdata['smslen'] = $countdata['length'];
                                    $mdata['smscount'] = $countdata['count'];
                                }

                                //5. invalid check
                                if($data['invalidFlag']==1){
                                    if(!DooTextHelper::verifyFormData('mobile',$mobile,$params['validlengths'])){
                                        array_push($invalidcontacts, $mdata);
                                        continue;
                                    }
                                }
                                //6. Check and remove blacklist
                                if($params['routedata']->blacklist_ids!=''){
                                    $dbs = explode(",",$params['routedata']->blacklist_ids);
                                    foreach($dbs as $db){
                                        if($this->checkBlacklistMatch($db, $mobile)){
                                            array_push($blmatchedcontacts, $mdata);
                                            continue;
                                        }
                                    }
                                }
                                $dynamicsmstotal += $mdata['smscount'];
                                array_push($finalcontacts, $mdata);
                            }

                            
                        }
                    }
                }
            }
            //read contacts supplied via api
            if(sizeof($data['apicontacts'])>0){
                foreach($data['apicontacts'] as $cell){
                    $mdata = array();
                    $mobile = floatval(trim($cell));
                    if($mobile!=0){
                        $totalsubmitted++;
                        //1. duplicate check
                        if($data['duplicateFlag']==1){
                            if(in_array($mobile, $uniquecontacts)){
                                $dupcount++;
                                continue;
                            }
                            array_push($uniquecontacts, $mobile);
                        }

                        if($params['account_type']==1){
                            //currency based user, get mccmnc and route and per sms cost
                            //2. Get country ISO based on prefix
                            $iso = DooSmppcubeHelper::getCountryIso($mobile);
                            $mdata['mobile'] = $mobile;
                            $mdata['text'] = $params['smstext'];
                            if($iso==''){
                                //invalid number
                                array_push($invalidcontacts, $mdata);
                                continue;
                            }else{
                                //3. Based on ISO get coverage data for valid length and operator prefix length. Extract operator prefix from this
                                //get coverage details like prefix and NSN prefix length
                                $cvmap = function($c)use($iso) {return $c->country_code == $iso;};
                                $cvfilter = array_filter($params['coverages'], $cvmap); 
                                $k = key($cvfilter);
                                //4. Based on operator prefix get MCCMNC code
                                $pfx = substr($mobile, strlen($params['coverages'][$k]->prefix)-1, intval($params['coverages'][$k]->network_idn_pre_len));
                                $pmap = function($p)use($pfx) {return $p->prefix == $pfx;}; 
                                $pfxfilobj = array_filter($params['prefixes'], $pmap); 
                                $pk = key($pfxfilobj);
                    
                                //5. get price for the mcc mnc according to this plan
                                $mccmnc = $params['prefixes'][$pk]->mccmnc;
                                $mnmap = function($m)use($mccmnc) {return $m->mccmnc == $mccmnc;}; 
                                $mplanfilter = array_filter($params['smsplan']['pricing'], $mnmap); 
                                $mk = key($mplanfilter);
                                if($mccmnc=='0' || !$mccmnc){
                                    //no mccmnc matched, use default route pricing
                                    $routeid = $params['smsplan']['routesniso'][intval($params['coverages'][$k]->prefix)];
                                    $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                    $routefilobj = array_filter($params['routes'], $rmap); 
                                    $rk = key($routefilobj);
                                    $persmsprice = $params['routes'][$rk]->default_selling_price;
                                    $mdata['routeid'] = $routeid;
                                }else{
                                    $persmsprice = floatval($params['smsplan']['pricing'][$mk]->price);
                                    $routeid = $params['smsplan']['pricing'][$mk]->route_id;
                                    //get route info
                                    $rmap = function($r)use($routeid) {return $r->id == $routeid;}; 
                                    $routefilobj = array_filter($params['routes'], $rmap); 
                                    $rk = key($routefilobj);
                                }
                                $mdata['smscost'] = $persmsprice;
                                $mdata['routeid'] = $routeid;
                                $mdata['mccmnc'] = $mccmnc;

                                //3. Replace URL if applicable
                                if($replaceurl==1){
                                    $uid = $params['userid'];
                                    $turl = $this->generateUrlIdf($uid, 7);
                                    $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                                    //prepare the sql string
                                    $durl = array();
                                    $durl['parent_url_id'] = $urldata->id;
                                    $durl['url_idf'] = $turl;
                                    $durl['sms_shoot_id'] = $params['shootid'];
                                    $durl['mobile'] = $mobile;
                                    array_push($dynurls,$durl);
                                }else{
                                    $dyn_text = $params['smstext'];
                                }
                                $mdata['mobile'] = $mobile;
                                $mdata['text'] = $dyn_text;

                                //4. Get dynamic SMS if applicable
                                //get credit rule data
                                $creditruleid = $params['routes'][$rk]->credit_rule;
                                $ccmap = function($cc)use($creditruleid) {return $cc->id == $creditruleid;}; 
                                $ccfilobj = array_filter($params['countrules'], $ccmap); 
                                $cck = key($ccfilobj);
                                $normal_ccrule = unserialize($params['countrules'][$cck]->normal_sms_rule);
                                $unicode_ccrule = unserialize($params['countrules'][$cck]->unicode_rule);
                                $spcl_rule = unserialize($params['countrules'][$cck]->special_chars_rule);
                                $spcl_ccrule = $spcl_rule['counts'];
                                $countdata = $this->getSmsCount(array('specialrule'=>$spcl_ccrule, 'unicoderule'=>$unicode_ccrule, 'normalrule'=>$normal_ccrule, 'smstype'=>$params['smstype']), $dyn_text);
                                $mdata['smslen'] = $countdata['length'];
                                $mdata['smscount'] = $countdata['count'];
                                $smscost = $mdata['smscost']* intval($countdata['count']);
                                
                                $mdata['smscost'] = $smscost;
                                if(intval($routeid)!=0){
                                    //6. Invalid check
                                    if($data['invalidFlag']==1){
                                        if(!DooTextHelper::verifyFormData('mobile',$mobile,explode(",",$params['coverages'][$k]->valid_lengths))){
                                            array_push($invalidcontacts, $mdata);
                                            continue;
                                        }
                                    }
                                    //7. Blacklist filter
                                    if($params['routes'][$rk]->blacklist_ids!=''){
                                        $dbs = explode(",",$params['routes'][$rk]->blacklist_ids);
                                        foreach($dbs as $db){
                                            if($this->checkBlacklistMatch($db, $mobile)){
                                                array_push($blmatchedcontacts, $mdata);
                                                continue;
                                            }
                                        }
                                    }
                                }else{
                                    //unable to match any routes consider this invalid
                                    array_push($invalidcontacts, $mdata);
                                    continue;
                                }
                                
                                //7. Save data in array so the final contacts as grouped based on route id
                                if(!is_array($routewisecontacts[$routeid]['mobiles'])) $routewisecontacts[$routeid]['mobiles'] = array();
                                $currencybasecost += $smscost;
                                $routewisecontacts[$routeid]['costperroute'] = floatval($routewisecontacts[$routeid]['costperroute']) + $smscost;
                                $routewisecontacts[$routeid]['smpp'] = $params['routes'][$rk]->smpp_id;
                                array_push($routewisecontacts[$routeid]['mobiles'], $mdata);
                            }
                        }else{
                            //credit based account
                            //2. Add country prefix if applicable
                            if($params['routedata']->add_pre!='0'){
                                $mobile = strlen($mobile) < max($params['validlengths']) ? intval($params['countryPrefix'].$mobile) :  $mobile;
                            }
                            //3. Replace URL if applicable
                            if($replaceurl==1){
                                $uid = $params['userid'];
                                $turl = $this->generateUrlIdf($uid, 7);
                                $dyn_text = str_replace($urlidf, $turl, $params['smstext']);
                                //prepare the sql string
                                $durl = array();
                                $durl['parent_url_id'] = $urldata->id;
                                $durl['url_idf'] = $turl;
                                $durl['sms_shoot_id'] = $params['shootid'];
                                $durl['mobile'] = $mobile;
                                array_push($dynurls,$durl);
                            }else{
                                $dyn_text = $params['smstext'];
                            }
                            $mdata['mobile'] = $mobile;
                            $mdata['text'] = $dyn_text;
                            $mdata['smslen'] = 0; //counted later
                            $mdata['smscount'] = 0; //counted later

                            //4. get dynamic sms text and sms count
                            if($params['smstype']['personalize']==1){
                                $countdata = $this->getSmsCount(array('specialrule'=>$params['specialcountRule'], 'unicoderule'=>$params['unicodecountRule'], 'normalrule'=>$params['normalcountRule'], 'smstype'=>$params['smstype']), $dyn_text);
                                $mdata['smslen'] = $countdata['length'];
                                $mdata['smscount'] = $countdata['count'];
                            }

                            //5. invalid check
                            if($data['invalidFlag']==1){
                                if(!DooTextHelper::verifyFormData('mobile',$mobile,$params['validlengths'])){
                                    array_push($invalidcontacts, $mdata);
                                    continue;
                                }
                            }
                            //6. Check and remove blacklist
                            if($params['routedata']->blacklist_ids!=''){
                                $dbs = explode(",",$params['routedata']->blacklist_ids);
                                foreach($dbs as $db){
                                    if($this->checkBlacklistMatch($db, $mobile)){
                                        array_push($blmatchedcontacts, $mdata);
                                        continue;
                                    }
                                }
                            }
                            $dynamicsmstotal += $mdata['smscount'];
                            array_push($finalcontacts, $mdata);
                        }

                        
                    }
                }
            }
            //save dynamic URLS for the case of custom contacts supplied by user
            if(sizeof($dynurls)>0){
                $dynturlobj = Doo::loadModel('ScShortUrlsMsisdnMap', true);
                $dynturlobj->addData($dynurls);
            }
        }
        //all contacts have been read now
        if($params['account_type']==1){
            //currency based counting
            //foreach route repeat the process for dlr cutting batch processing and so on
            $returndata = array();
            $returndata['routewisecontacts'] = $routewisecontacts;
            $returndata['invalidcontacts'] = $invalidcontacts;
            $returndata['blmatchedcontacts'] = $blmatchedcontacts;
            $returndata['totaldropped'] = 0; // dlr cutting for currency based is done in clientcontroller
            $returndata['totalsmscost'] = $currencybasecost;
            $returndata['totalsubmitted'] = $totalsubmitted;
            $returndata['duplicatesremoved'] = $dupcount;
            $returndata['persmscount'] = 0;

            return $returndata;
        }else{
            //credit based account
            $totalcontacts = sizeof($finalcontacts);
            //add to whitelist of a small sms shoot
            if($totalcontacts<15){
                Doo::loadModel('ScUsersWhitelist');
                $objwl = new ScUsersWhitelist;
                $objwl->user_id = $params['userid'];
                $rswl = Doo::db()->find($objwl,array('limit'=>1));
                $wlnoar = array();
                foreach($finalcontacts as $cdata){
                    array_push($wlnoar,$cdata['mobile']);
                }
                if(!$rswl){
                    //insert
                    $objwl->mobiles = implode(",",$wlnoar);
                    Doo::db()->insert($objwl);
                }else{
                    //to ensure duplicates are not there
                    $wl_arry = explode(",",$rswl->mobiles.','.implode(",",$wlnoar));
                    $wl_arry = array_unique($wl_arry);
                    $objwl->id = $rswl->id;
                    $objwl->mobiles = implode(",",$wl_arry);
                    Doo::db()->update($objwl);
                }
            }
            //apply DLR cutting and create real batch vs dropped batch
            $totalcontacts = sizeof($finalcontacts);
            if($totalcontacts>Doo::conf()->dlr_per_threshold){
                if($params['delvper']!=100 && $params['usergroup']!='admin'){
                    //apply dlr cut
                    //check and keep whitelist number out of dlr cutting
                    $wlobj = Doo::loadModel('ScUsersWhitelist', true);
                    $wlobj->user_id = $params['userid'];
                    $wlcontacts = Doo::db()->find($wlobj,array('select'=>'mobiles','limit'=>1))->mobiles;
                    if($wlcontacts){
                        //whitelist contacts are present, filter them out before applying cutting
                        $wlcontacts = explode(",", $wlcontacts);
                        //create 2d array of whitelist numbers
                        $wlcontacts_ar = array();
                        foreach($wlcontacts as $clno){
                            $tar['mobile'] = $clno;
                            array_push($wlcontacts_ar, $tar);
                        }
                        $nowhitelistcontacts = array_udiff($finalcontacts, $wlcontacts_ar, function($a,$b){ return $a['mobile'] - $b['mobile'];});// this is list without any whitelist numbers
                        $wlpresentcontacts = array_diff_assoc($finalcontacts,$nowhitelistcontacts); //this is list of whitelist nums present in the current shoot
                        //apply dlr cut on contacts array without any whitelist
                        $sms_to_cut = $totalcontacts - intval( ($params['delvper']/100) * $totalcontacts);
                        if(sizeof($nowhitelistcontacts)>0){
                            if($sms_to_cut>sizeof($nowhitelistcontacts)){
                                $sms_to_cut = sizeof($nowhitelistcontacts);
                            }

                            $randm_keys = array_rand($nowhitelistcontacts,$sms_to_cut);

                            foreach ($randm_keys as $key){
                                $droppedcontacts[$key] = $nowhitelistcontacts[$key];	
                            }

                            //get the numbers which will be sent to server
                            $dlrfilcontacts = array_diff_assoc($nowhitelistcontacts, $droppedcontacts);

                            //merge the whitelist number with numbers going to go to smpp
                            $dlrfilcontacts = $wlpresentcontacts + $dlrfilcontacts;
                    
                        }else{
                            //all contacts are white list: no dlr cutting
                            $dlrfilcontacts = $finalcontacts;
                        }
                            
                    }else{
                        //no whitelist to filter
                        $sms_to_cut = $totalcontacts - intval( ($params['delvper']/100) * $totalcontacts);
                        $randm_keys = array_rand($finalcontacts,$sms_to_cut);
                        foreach ($randm_keys as $key){
                            $droppedcontacts[$key] = $finalcontacts[$key];	
                        }
                        //get the numbers which will be sent to server
                        $dlrfilcontacts = array_diff_assoc($finalcontacts, $droppedcontacts);
                    }
                    //end of dlr cut
                }else{
                    $dlrfilcontacts = $finalcontacts;
                }
            }else{
                $dlrfilcontacts = $finalcontacts;
            }
            //save dropped contacts according to fake dlr ratios
            $totaldropped = sizeof($droppedcontacts);
            if($totaldropped>0){
                $smstofakedel = intval((Doo::conf()->fakedlr_del/100)*$totaldropped);
                $smstofakeundel = intval((Doo::conf()->fakedlr_undel/100)*$totaldropped);
                $smstofakeexp = $totaldropped - ($smstofakedel+$smstofakeundel);
                
                //split dropped contacts according to fake dlr ratios
                $fakedlrcontacts = array();
                $fakedlrcontacts = $droppedcontacts;
                $fakedlrcontacts_del = array_slice($fakedlrcontacts, 0, $smstofakedel);
                $fakedlrcontacts_undel = array_slice($fakedlrcontacts, ($smstofakedel+1), $smstofakeundel);
                $fakedlrcontacts_exp = array_slice($fakedlrcontacts, ($smstofakeundel+1), $smstofakeexp);                  
            }

            //count sms text
            $persmscount = 0;
            if($params['smstype']['main']=='text' && $params['smstype']['personalize']!=1){
                $countdata = $this->getSmsCount(array('specialrule'=>$params['specialcountRule'], 'unicoderule'=>$params['unicodecountRule'], 'normalrule'=>$params['normalcountRule'], 'smstype'=>$params['smstype']), $params['smstext']);
                $totalsmscount = $totalcontacts * $countdata['count'];
                $persmscount = $countdata['count'];
            }elseif($params['smstype']['main']=='text' && $params['smstype']['personalize']==1){
                $totalsmscount = $dynamicsmstotal;
                $persmscount = $finalcontacts[0]['smscount'];
            }elseif($params['smstype']['main']!='text'){
                $totalsmscount = $totalcontacts;
                $persmscount = 1;
            }
            //return data
            $returndata = array();
            $returndata['dlrfilcontacts'] = $finalcontacts;
            $returndata['invalidcontacts'] = $invalidcontacts;
            $returndata['blmatchedcontacts'] = $blmatchedcontacts;
            $returndata['totaldropped'] = $totaldropped;
            $returndata['droppedcontacts'] = $droppedcontacts;
            $returndata['fakedlr_del'] = $fakedlrcontacts_del;
            $returndata['fakedlr_undel'] = $fakedlrcontacts_undel;
            $returndata['fakedlr_exp'] = $fakedlrcontacts_exp;
            $returndata['totalsmscredits'] = $totalsmscount;
            $returndata['duplicatesremoved'] = $dupcount;
            $returndata['persmscount'] = $persmscount;

            return $returndata;

        }
        
    }

    private function getPhonebookContacts($data){
        $startlimit = $data['phonebook']['start'];
        $numrows = $data['phonebook']['end'];
        $pbcobj = Doo::loadModel('ScPhonebookContacts', true);
        $pbcobj->group_id = $data['phonebook']['group'];
        $limit = ($startlimit.', '.$numrows);
        return Doo::db()->find($pbcobj,array('select'=>'mobile','limit'=>$limit));
    }

    private function checkBlacklistMatch($db, $mobile){
        //get the mobile column and classname
        $bliobj = Doo::loadModel('ScBlacklistIndex', true);
        $bliobj->id = $db;
        $bldata = Doo::db()->find($bliobj,array('select'=>'table_name,mobile_column','limit'=>1),2);
        
        $classname = '';
            $temptbl = $bldata->table_name;
            for($i=0;$i<strlen($temptbl);$i++) {
                if($i==0) {
                    $classname .= strtoupper($temptbl[0]);
                }
                else if($temptbl[$i]=='_' || $temptbl[$i]=='-' || $temptbl[$i]=='.' ) {
                    $classname .= strtoupper( $temptbl[ ($i+1) ] );
                    $arr = str_split($temptbl);
                    array_splice($arr, $i, 1);
                    $temptbl = implode('', $arr);
                }else {
                    $classname .= $temptbl[$i];
                }
            }
        //lookup
        $lookupobj = Doo::loadModel($classname, true);
        $lookupobj->{$bldata->mobile_column} = $mobile;
        $opt['select'] = 'id';
        $opt['limit'] = 1;
        return Doo::db()->find($lookupobj,$opt,2)->id;
    }

    private function generateUrlIdf($uid, $len=6){
        
        $seed = time() . mt_rand() . $uid;
        $turl = substr(md5($seed),intval(0-$len),$len);
            
        //check if already exists
        if($len==6){
            //regular link request
            $obj = Doo::loadModel('ScShortUrlsMaster', true);
            $obj->url_idf = $turl;
            $tid = Doo::db()->find($obj,array('select'=>'id','limit'=>1));
            if($tid->id){
                //already exists regenerate
                $this->generateUrlIdf($uid);
            }else{
                return $turl;
            }
        }else{
            //request for personalized link
            $obj = Doo::loadModel('ScShortUrlsMsisdnMap', true);
            $obj->url_idf = $turl;
            $tid = Doo::db()->find($obj,array('select'=>'id','limit'=>1));
            if($tid->id){
                //already exists regenerate
                $this->generateUrlIdf($uid,7);
            }else{
                return $turl;
            }
        }
        
    }

    private function getSmsCount($data, $text){
        $totaloccurences = 0;
        $totalspcladd = 0;
        $totalspclchargroups = sizeof($data['specialrule']);
        $rawsmslength = mb_strlen(trim($text),'UTF-8');
        //check special characters
        for($i=1;$i<=$totalspclchargroups;$i++){
            if($i>1){
                //it means according to this credit count rule, there are some special characters which will be counted as more than 1 character
                $spclchars = str_replace("clb","]",implode("",$data['specialrule'][$i]));
                //$spclchars = $spcl_ccrule[$i].join().replace(/,/g,"").replace(/clb/g,"]").replace(/\\/g, '\\/');
                //check out occurences
                $occurrences = preg_match_all('/['.preg_quote($spclchars).']/',$text);
                $totaloccurences += $occurrences;
                $totalspcladd += $occurrences*$i;
            }
        }
        $totallength = ($rawsmslength-$totaloccurences)+$totalspcladd;
        $smscount = 1;
        if($data['smstype']['main']!='text'){
            //wap and vcard
            return array('length'=>$totallength, 'count'=>$smscount);
        }else{
            //text sms
            if($data['smstype']['unicode']==1){
                //use unicode rule
                for($j=1;$j<=5;$j++){
                    if($totallength>=$data['unicoderule'][$j]['from'] && $totallength<=$data['unicoderule'][$j]['to']){
                        //matched
                        $smscount = $j;
                        break;
                    }
                    if($totallength>$data['unicoderule'][5]['to']){
                        //simply calculate the per sms factor
                        $persms = ceil($data['unicoderule'][5]['to']/5);
                        $smscount = ceil($totallength/$persms);
                    }
                }
            }else{
                //use normal sms rule
                for($j=1;$j<=5;$j++){
                    if($totallength>=$data['normalrule'][$j]['from'] && $totallength<=$data['normalrule'][$j]['to']){
                        //matched
                        $smscount = $j;
                        break;
                    }
                    if($totallength>$data['normalrule'][5]['to']){
                        //simply calculate the per sms factor
                        $persms = ceil($data['normalrule'][5]['to']/5);
                        $smscount = ceil($totallength/$persms);
                    }
                }
            }
            //return total sms count and length of sms
            return array('length'=>$totallength, 'count'=>$smscount);
        }
    }

/*
Functions for bulk inserting and processing of SMS data
*/
    public function storeSpamData($data, $params){
        $action = Doo::conf()->spam_action;
        $response = array();
        if($action=='NOTIFY'){
            //simply notify 
            $response['message'] = 'Spam keywords were detected in SMS text. Please try again.';
            $response['deductcredits'] = 0; //dont deduct credits
            return $response;
        }elseif($action=='NOTIFY_DEDUCT'){
            //prepare and save data
            $spmobj = Doo::loadModel('ScSpamCampaigns', true);
            $spmobj->sms_shoot_id = $params['shootid'];
            $spmobj->user_id = $params['userid'];
            $spmobj->route_id = $params['account_type']==1 ? $params['smsplan']['id'] : $params['routedata']->id;
            $spmobj->sender_id = $params['senderid'];
            $spmobj->contacts = $params['account_type']==1 ? serialize($data['routewisecontacts']) : serialize($data['dlrfilcontacts']);
            $spmobj->dropped_contacts = serialize(array('DEL'=>$data['fakedlr_del'], 'UNDEL'=>$data['fakedlr_undel'], 'EXP'=>$data['fakedlr_exp']));
            $spmobj->invalid_contacts = serialize($data['invalidcontacts']);
            $spmobj->blacklist_contacts = serialize($data['blmatchedcontacts']);
            $spmobj->duplicates_removed = $data['duplicatesremoved'];
            $spmobj->smscount = $data['persmscount'];
            $spmobj->cc_rule = $params['account_type']==1 ? 0 : $params['routedata']->credit_rule;
            $spmobj->credits_charged = $params['account_type']==1 ? $data['totalsmscost'] : $data['totalsmscredits'];
            $spmobj->pushed_via = $params['pushedvia'];
            $spmobj->count = $params['account_type']==1 ? $data['totalsubmitted'] : sizeof($data['dlrfilcontacts'])+sizeof($data['invalidcontacts'])+sizeof($data['blmatchedcontacts'])+sizeof($data['droppedcontacts'])+$data['duplicatesremoved'];
            $spmobj->sms_type = serialize($params['smstype']);
            $spmobj->sms_text = $params['savetext'];
            $spmobj->keywords_match = serialize($data['spamdata']);
            $spmobj->submission_time = date(Doo::conf()->date_format_db);
            $spmobj->schedule_data = serialize(array('schedule'=>$data['schflag'],'time'=>$data['actualschtime']));
            $spmobj->status = 1;
            Doo::db()->insert($spmobj);
            
            //deduct credits
            if($params['usergroup']!='admin'){
                $response['deductcredits'] = 1;
            }
            $response['message'] = 'SPAM content was detected in your campaign. Your campaign is held for approval from Admin. You will be notified of the result.';
            //return
            return $response;
        }
    }

    public function storeTempData($data, $params){
        $tmpobj = Doo::loadModel('ScTempCampaigns', true);
        $tmpobj->sms_shoot_id = $params['shootid'];
        $tmpobj->user_id = $params['userid'];
        $tmpobj->route_id = $params['routedata']->id;
        $tmpobj->sender_id = $params['senderid'];
        $tmpobj->contacts = serialize($data['dlrfilcontacts']);
        $tmpobj->dropped_contacts = serialize(array('DEL'=>$data['fakedlr_del'], 'UNDEL'=>$data['fakedlr_undel'], 'EXP'=>$data['fakedlr_exp']));
        $tmpobj->invalid_contacts = serialize($data['invalidcontacts']);
        $tmpobj->blacklist_contacts = serialize($data['blmatchedcontacts']);
        $tmpobj->duplicates_removed = $data['duplicatesremoved'];
        $tmpobj->smscount = $data['persmscount'];
        $tmpobj->cc_rule = $params['routedata']->credit_rule;
        $tmpobj->credits_charged = $data['totalsmscredits'];
        $tmpobj->pushed_via = $params['pushedvia'];
        $tmpobj->count = sizeof($data['dlrfilcontacts'])+sizeof($data['invalidcontacts'])+sizeof($data['blmatchedcontacts'])+$data['totaldropped']+$data['duplicatesremoved'];
        $tmpobj->sms_type = serialize($params['smstype']);
        $tmpobj->sms_text = $params['savetext'];
        $tmpobj->submission_time = date(Doo::conf()->date_format_db);
        $tmpobj->schedule_data = serialize(array('schedule'=>$data['schflag'],'time'=>$data['actualschtime']));
        $tmpobj->status = 1;
        
        Doo::db()->insert($tmpobj);
    }

    public function saveScheduleSms($data, $params, $smsbatch, $queue=array()){
        Doo::loadModel('ScScheduledCampaigns');
        $schobj = new ScScheduledCampaigns;
        
        $schobj->sms_shoot_id = $params['shootid'];
        $schobj->user_id = $params['userid'];
        $schobj->route_id = $params['account_type']==1 ? $params['smsplan']['id'] : $params['routedata']->id;
        $schobj->sender_id = $params['senderid'];
        $schobj->contacts = serialize($smsbatch);
        $schobj->dropped_contacts = serialize(array('DEL'=>$data['fakedlr_del'], 'UNDEL'=>$data['fakedlr_undel'], 'EXP'=>$data['fakedlr_exp']));
        $schobj->invalid_contacts = serialize($data['invalidcontacts']);
        $schobj->blacklist_contacts = serialize($data['blmatchedcontacts']);
        $schobj->smscount = $data['persmscount'];
        $schobj->pushed_via = $params['pushedvia'];
        $schobj->count = sizeof($smsbatch)+sizeof($data['invalidcontacts'])+sizeof($data['blmatchedcontacts'])+sizeof($data['droppedcontacts']);
        $schobj->sms_type = serialize($params['smstype']);
        $schobj->sms_text = $params['savetext'];
        $schobj->submission_time = date(Doo::conf()->date_format_db);
        $schobj->schedule_time = $data['actualschtime'];
        $schobj->status = 1;
        Doo::db()->insert($schobj);

        if(sizeof($queue)>0){
            $schqueue = array();
            foreach($queue as $batch){
                $tmpschar = array();
                $tmpschar['sms_shoot_id'] = $params['shootid'];
                $tmpschar['user_id'] = $params['userid'];
                $tmpschar['route_id'] = $params['routedata']->id;
                $tmpschar['sender_id'] = $params['senderid'];
                $tmpschar['contacts'] = serialize($batch);  
                $tmpschar['pushed_via'] = $params['pushedvia'];
                $tmpschar['count'] = sizeof($batch); 
                $tmpschar['smscount'] = $data['persmscount'];
                $tmpschar['sms_type'] = serialize($params['smstype']); 
                $tmpschar['sms_text'] = $params['savetext']; 
                $tmpschar['submission_time'] = date(Doo::conf()->date_format_db);  
                $tmpschar['schedule_time'] = $data['actualschtime'];
                $tmpschar['status'] = 1;  
                array_push($schqueue, $tmpschar);
            }
            if(sizeof($schqueue)>0)$schobj->addScheduledQueue($schqueue);
        }
    }

    public function submitInitialCampaign($data, $params, $smsbatch, $queue=array()){
        $sentobj = Doo::loadModel('ScSentSms', true);
        $savefirstbatch = array();
        foreach($smsbatch as $mdata){
            $mobile = $mdata['mobile'];
            if($params['smstype']['personalize']==1){
                $smstext = $mdata['text'];
                $umsgid = uniqid(rand());
                $smscount = $mdata['smscount'];
                //send to kannel
                $dynsms = array();
                $dynsms['sms_shoot_id'] = $params['shootid'];  
                $dynsms['route_id'] = $params['account_type']==1 ? $params['batchrouteid'] : $params['routedata']->id;
                $dynsms['user_id'] = $params['userid'];
                $dynsms['upline_id'] = $params['uplineid'];
                $dynsms['umsgid'] = $umsgid;
                $dynsms['smscount'] = $mdata['smscount']; 
                $dynsms['smsc'] = $params['smsc'];
                $dynsms['senderid'] = $params['senderstr'];
                $dynsms['contacts'] = $mobile;
                $dynsms['sms_type'] = serialize($params['smstype']);
                $dynsms['sms_text'] = $smstext;
                $dynsms['usertype'] = $params['account_type']==1 ? 1 : 0;
                DooSmppcubeHelper::pushToKannel($dynsms);
            }else{
                $smstext = ''; //sms for non dynamic is $params['savetext'] but we store empty string in send sms table for non dynamic sms to save db space
                $smscount = $params['account_type']==1 ? $mdata['smscount'] : $data['persmscount'];
                $umsgid = '';
            }
            
            $tmpar = array();
            $tmpar['sms_shoot_id'] = $params['shootid'];  
            $tmpar['user_id'] = $params['userid'];
            $tmpar['route_id'] = $params['account_type']==1 ? $params['batchrouteid'] : $params['routedata']->id;
            $tmpar['sender_id'] = $params['senderid'];
            $tmpar['mobile'] = $mobile;   
            $tmpar['sms_type'] = serialize($params['smstype']);
            $tmpar['sms_text'] = $smstext;  
            $tmpar['sms_count'] = $smscount;  
            $tmpar['submission_time'] = date(Doo::conf()->date_format_db);  
            $tmpar['sending_time'] = date(Doo::conf()->date_format_db);  
            $tmpar['umsgid'] = $umsgid;
            $tmpar['mccmnc'] = $mdata['mccmnc'];
            $tmpar['price'] = $mdata['smscost'];
            $tmpar['status'] = 1; 
            array_push($savefirstbatch, $tmpar);
        }
        //save in DB
        if(sizeof($savefirstbatch)>0) $sentobj->saveSentSMS($savefirstbatch);
        //send to kannel if non dynamic sms
        if($params['smstype']['personalize']!=1){
            $kansms = array();
            $kansms['sms_shoot_id'] = $params['shootid'];  
            $kansms['route_id'] = $params['account_type']==1 ? $params['batchrouteid'] : $params['routedata']->id;
            $kansms['user_id'] = $params['userid'];
            $kansms['upline_id'] = $params['uplineid'];
            $kansms['smscount'] = $data['persmscount'];
            $kansms['smsc'] = $params['smsc'];
            $kansms['senderid'] = $params['senderstr'];
            $kansms['contacts'] = $smsbatch;
            $kansms['sms_type'] = serialize($params['smstype']);
            $kansms['sms_text'] = $params['smstext'];
            $dynsms['usertype'] = $params['account_type']==1 ? 1 : 0;
            DooSmppcubeHelper::pushToKannel($kansms);
        }
        //save in queue
        if(sizeof($queue)>0){
            $qobj = Doo::loadModel('ScQueuedCampaigns', true);
            $savequeue = array();
            foreach($queue as $batch){
                $tmpschar = array();
                $tmpschar['sms_shoot_id'] = $params['shootid'];  
                $tmpschar['user_id'] = $params['userid'];
                $tmpschar['route_id'] = $params['account_type']==1 ? intval($params['batchrouteid']) : $params['routedata']->id;
                $tmpschar['sender_id'] = $params['senderid'];
                $tmpschar['contacts'] = serialize($batch);  
                $tmpschar['pushed_via'] = $params['pushedvia'];  
                $tmpschar['count'] = sizeof($batch); 
                $tmpschar['smscount'] = $data['persmscount'];
                $tmpschar['sms_type'] = serialize($params['smstype']);
                $tmpschar['sms_text'] = $params['savetext'];  
                $tmpschar['submission_time'] = date(Doo::conf()->date_format_db);
                $tmpschar['status'] = 1;  
                array_push($savequeue, $tmpschar);
            }
            if(sizeof($savequeue)>0)$qobj->addQueueItem($savequeue);
        }
    }

    public function saveSmsBatch($data, $params, $smsbatch){
        $sentobj = Doo::loadModel('ScSentSms', true);
        $savebatch = array();
        if(sizeof($smsbatch)>0){
            foreach($smsbatch as $mdata){
                if($params['smstype']['personalize']==1){
                    $smstext = $mdata['text'];
                    $smscount = $mdata['smscount'];
                }else{
                    $smstext = ''; //sms for non dynamic is $params['savetext'] but we store empty string in send sms table for non dynamic sms to save db space
                    $smscount = $data['persmscount'];
                }
                $tmpar = array();
                $tmpar['sms_shoot_id'] = $params['shootid'];  
                $tmpar['user_id'] = $params['userid'];  
                $tmpar['route_id'] = $params['account_type']==1? intval($mdata['routeid']) : $params['routedata']->id;
                $tmpar['sender_id'] = $params['senderid'];
                $tmpar['mobile'] = $mdata['mobile'];   
                $tmpar['sms_type'] = serialize($params['smstype']);
                $tmpar['sms_text'] = $smstext;  
                $tmpar['sms_count'] = $smscount;  
                $tmpar['submission_time'] = date(Doo::conf()->date_format_db);  
                $tmpar['sending_time'] = date(Doo::conf()->date_format_db);  
                $tmpar['mccmnc'] = $mdata['mccmnc'];
                $tmpar['price'] = $mdata['smscost'];
                $tmpar['status'] = $params['smsstatus'];    
                $tmpar['dlr'] = $params['dlrcode'];     
                $tmpar['vendor_dlr'] = $params['dlrvendorcode']; 
                
                array_push($savebatch, $tmpar);
            }
            //echo sizeof($saveblbatch).' - blacklist batch<br>';
            if(sizeof($savebatch)>0) $sentobj->saveSentSMS($savebatch);
        }
        
    }

    public function storeSummaryData($data, $params){
        //create entry in sms summary table
        $sumobj = Doo::loadModel('ScSmsSummary',true);
        $sumobj->campaign_id = $params['campaignid'];
        $sumobj->sms_shoot_id = $params['shootid'];
        $sumobj->user_id = $params['userid'];
        $sumobj->route_id = $params['account_type']==1 ? $params['smsplan']['id'] : $params['routedata']->id;
        $sumobj->sender_id = $params['senderid'];
        $sumobj->contacts = $params['account_type']==1 ? $data['totalsubmitted'] : sizeof($data['dlrfilcontacts']);
        $sumobj->dropped_contacts = $data['totaldropped'];
        $sumobj->invalid_contacts = sizeof($data['invalidcontacts']);
        $sumobj->blacklist_contacts = sizeof($data['blmatchedcontacts']);
        $sumobj->duplicates_removed = $data['duplicatesremoved'];
        $sumobj->smscount = $data['persmscount'];
        $sumobj->cc_rule = $params['account_type']==1 ? : $params['routedata']->credit_rule;
        $sumobj->credits_charged = $params['account_type']==1 ? $data['totalsmscost'] : $data['totalsmscredits'];
        $sumobj->pushed_via = $params['pushedvia'];
        $sumobj->count = $params['account_type']==1 ? $data['totalsubmitted'] : sizeof($data['dlrfilcontacts'])+sizeof($data['invalidcontacts'])+sizeof($data['blmatchedcontacts'])+sizeof($data['droppedcontacts'])+$data['duplicatesremoved'];
        $sumobj->sms_type = serialize($params['smstype']);
        $sumobj->sms_text = $params['savetext'];
        $sumobj->submission_time = date(Doo::conf()->date_format_db);
        $sumobj->schedule_data = serialize(array('schedule'=>$data['schflag'],'time'=>$data['actualschtime']));
        $sumobj->hide_mobile = $params['phonebookflag'];
        $sumobj->status = $params['summarystatus'];
        $sumobj->platform_data = serialize($params['osdata']);
        Doo::db()->insert($sumobj);

        //log platform and user details
        if($params['summarystatus']==3){
            $actData['activity_type'] = 'SPAM CAMPAIGN';
            $actData['activity'] = Doo::conf()->spam_campaign_alert.'|| CAMPAIGN-ID: '.$params['shootid'];  
            $ulobj = Doo::loadModel('ScLogsUserActivity', true);
            $ulobj->addLog($params['userid'], $actData);
            
            //notify admin
            $alobj = Doo::loadModel('ScUserNotifications', true);
            $alobj->addAlert(1,'danger',Doo::conf()->spam_campaign_alert,'manageSpam');
        }

        if($params['summarystatus']==2){
            $actData['activity_type'] = 'SEND CAMPAIGN';
            $actData['activity'] = Doo::conf()->temp_campaign_hold.'|| CAMPAIGN ID:'.$params['shootid'];  
            $ulobj = Doo::loadModel('ScLogsUserActivity', true);
            $ulobj->addLog($params['userid'], $actData,1);

            //notify admin of the fact that kannel or smpp might be down
            $alobj = Doo::loadModel('ScUserNotifications', true);
            $alobj->addAlert(1,'danger',Doo::conf()->temp_campaign_hold,'systemMonitor');
        }
        
        if($params['summarystatus']==1){
            $actData['activity_type'] = 'SMS CAMPAIGN';
            $actData['activity'] = Doo::conf()->sms_campaign_scheduled.'|| CAMPAIGN ID:'.$params['shootid'];  
            $ulobj = Doo::loadModel('ScLogsUserActivity', true);
            $ulobj->addLog($params['userid'], $actData);
        }

        if($params['summarystatus']==0){
            $actData['activity_type'] = 'SMS CAMPAIGN';
            $actData['activity'] = Doo::conf()->sms_campaign_sent.'|| CAMPAIGN ID:'.$params['shootid']; 
            $ulobj = Doo::loadModel('ScLogsUserActivity', true);
            $ulobj->addLog($params['userid'], $actData);
        }

    }

    public function deductUserCredits($data, $params){
        //deduct credits
        $creobj = Doo::loadModel('ScUsersCreditData', true);
        $newavcredits = $creobj->doCreditTrans('debit', $params['userid'], $params['routedata']->id, $data['totalsmscredits']);
        //log credit activity
        $lcobj = Doo::loadModel('ScLogsCredits', true);
        $lcobj->user_id = $params['userid'];
        $lcobj->timestamp = date(Doo::conf()->date_format_db);
        $lcobj->amount = '-'.$data['totalsmscredits'];
        $lcobj->route_id = $params['routedata']->id;
        $lcobj->credits_before = $params['creditdata']->credits;
        $lcobj->credits_after = $newavcredits;
        $lcobj->reference = 'Send Campaign';
        $lcobj->comments = 'SMS campaign was sent. Details are:|| <a href="'.Doo::conf()->APP_URL.'showDLR/'.$params['shootid'].'/'.$params['userid'].'">Link</a> TOTAL: '. (sizeof($data['dlrfilcontacts'])+sizeof($data['invalidcontacts'])+sizeof($data['blmatchedcontacts'])+$data['totaldropped']+$data['duplicatesremoved']).' SMS.';
        Doo::db()->insert($lcobj);

        return $newavcredits;
    }
/*
API responses
*/
    public function getApiResponse($mode, $reason, $data=array()){
        $output = array();
        if($reason=='maintenance'){
            $output['result'] = 'error';
            $output['message'] = 'APP is in Maintenance Mode. SENDSMS not Allowed';
        }
        if($reason=='invalidkey'){
            $output['result'] = 'error';
            $output['message'] = 'INVALID API KEY';
        }
        if($reason=='apidisable'){
            $output['result'] = 'error';
            $output['message'] = 'API ACCESS IS DISABLED BY ADMINISTRATOR';
        }
        if($reason=='invalidroute'){
            $output['result'] = 'error';
            $output['message'] = 'ROUTE ID SUPPLIED WAS INVALID';
        }
        if($reason=='invalidsender'){
            $output['result'] = 'error';
            if($data['reason']=='len'){
                $output['message'] = 'MAXIMUM ALLOWED LENGTH OF '.intval($data['maxlen']).' FOR SENDER ID EXCEEDED.';
            }else{
                $output['message'] = 'INVALID SENDER ID SUPPLIED';
            }
        }
        if($reason=='invalidtemplate'){
            $output['result'] = 'error';
            $output['message'] = 'SMS TEMPLATE MISMATCH. ROUTE ALLOWS APPROVED SMS TEMPLATES ONLY';
        }
        if($reason=='invalidtime'){
            $output['result'] = 'error';
            $output['message'] = 'INVALID SCHEDULE TIME. CANNOT SCHEDULE CAMPAIGN IN THE PAST';
        }
        if($reason=='timemismatch'){
            $output['result'] = 'error';
            $output['message'] = 'ROUTE HAS TIMING RESTRICTIONS. CANNOT SUBMIT CAMPAIGN AT THE MOMENT';
        }
        if($reason=='schtimemismatch'){
            $output['result'] = 'error';
            $output['message'] = 'ROUTE HAS TIMING RESTRICTIONS. CANNOT SCHEDULE CAMPAIGN FOR THE SUPPLIED TIME';
        }
        if($reason=='lowcredits'){
            $output['result'] = 'error';
            $output['message'] = 'INSUFFICIENT CREDITS OR VALIDTY EXPIRED';
        }
        if($reason=='spamcampaign'){
            if($data['mode']=='notify'){
                $output['result'] = 'error';
                $output['message'] = 'SPAM KEYWORDS WERE DETECTED IN THE SMS TEXT. PLEASE TRY AGAIN';
            }else{
                $output['result'] = 'success';
                $output['message'] = 'SPAM CONTENT DETECTED. CAMPAIGN HELD FOR APPROVAL';
                $output['sms_shoot_id'] = $data['shootid'];
            }
        }
        if($reason=='submitted'){
            $output['result'] = 'success';
            $output['message'] = 'SMS SUBMITTED SUCCESSFULLY';
            $output['sms_shoot_id'] = $data['shootid'];
        }
        return $mode=='http' ? DooSmppcubeHelper::getApiJsonOutput($output) : DooSmppcubeHelper::getApiXmlOutput($output);
    }

    private static function getApiJsonOutput($data){
        return json_encode($data);die;
    }

    private static function getApiXmlOutput($data){
        $xmlstr = '<?xml version="1.0" encoding="UTF-8"?>';
        if($data['result']=='error'){
            $xmlstr .= '
                    <Message_resp>
                        <result>error</result>
                        <message>'.$data['message'].'</message>
                    </Message_resp>';
        }
        if($data['result']=='success'){
            $xmlstr .= '
                    <Message_resp>
                        <result>success</result>
                        <message>'.$data['message'].'</message>
                        <sms_shoot_id>'.$data['sms_shoot_id'].'</sms_shoot_id>
                    </Message_resp>';
        }
        return $xmlstr;
    }
   

}
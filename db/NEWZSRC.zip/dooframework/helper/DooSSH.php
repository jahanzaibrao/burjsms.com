<?php 
set_include_path(dirname(__FILE__).'/phpseclib');
include('phpseclib/Net/SSH2.php');
?>